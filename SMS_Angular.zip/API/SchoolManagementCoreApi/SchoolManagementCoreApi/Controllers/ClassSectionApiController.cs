﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/ClassSectionApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ClassSectionApiController : ControllerBase
    {
        private IClassSectionRepository _repository;
        public ClassSectionApiController( IClassSectionRepository repo)
        {
            _repository = repo;
        }

        [HttpGet("GetAllClasses")]
        public ActionResult GetAllClasses()
        {
            var cls = _repository.GetAllClasses();
            return Ok(cls);
        }


        [HttpGet("GetAllSectionsForSpecificClass/{id}")]
        public ActionResult GetAllSectionsForSpecificClass(int id)
        {
            var s = _repository.GetAllSectionsForSpecificClass(id);
            return Ok(s);
        }

        [HttpGet("GetAllSectionsForSpecificClassIU/{id}")]
        public ActionResult GetAllSectionsForSpecificClassIU(int id)
        {
            var s = _repository.GetAllSectionsForSpecificClassIU(id);
            return Ok(s);
        }

        [HttpGet("GetClassSection")]
        public async Task<ActionResult> Get()
        {
            var cls = await _repository.Get();
            return Ok(cls);
        }

        [HttpGet("GetClassSectionById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var cls = await _repository.Get(id);
            return Ok(cls);
        }


        [HttpPost("AssignClass")]
        public async Task<ActionResult> Post(ClassSection cls)
        {
            await _repository.Post(cls);
            return Ok(cls);
        }

        [HttpPut("UpdateClassSection")]
        public async Task<ActionResult> Put(ClassSection cls)
        {

            await _repository.Put(cls);
            return Ok();
        }

        [HttpDelete("DeleteClassSectionById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
