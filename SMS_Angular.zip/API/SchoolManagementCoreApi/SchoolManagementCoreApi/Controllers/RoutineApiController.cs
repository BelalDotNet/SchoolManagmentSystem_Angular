﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/RoutineApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class RoutineApiController : ControllerBase
    {
        private IRoutineRepository _repository;
        public RoutineApiController(IRoutineRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetRoutines")]
        public async Task<ActionResult> Get()
        {
            var routines = await _repository.Get();
            return Ok(routines);
        }

        [HttpGet("GetRoutineById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var routine = await _repository.Get(id);
            return Ok(routine);
        }


        [HttpPost("InsertRoutine")]
        public async Task<ActionResult> Post(Routine routine)
        {
            await _repository.Post(routine);
            return Ok(routine);
        }

        [HttpPut("UpdateRoutine")]
        public async Task<ActionResult> Put(Routine routine)
        {

            await _repository.Put(routine);
            return Ok();
        }

        [HttpDelete("DeleteRoutineById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
