﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/SubjectTeacherApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class SubjectTeacherApiController : ControllerBase
    {
        private ISubjectTeacherRepository _repository;
        public SubjectTeacherApiController(ISubjectTeacherRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetSubjectTeacher")]
        public async Task<ActionResult> Get()
        {
            var subjects = await _repository.Get();
            return Ok(subjects);
        }

        [HttpGet("GetSubjectTeacherById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var subject = await _repository.Get(id);
            return Ok(subject);
        }


        [HttpPost("InsertSubjectTeacher")]
        public async Task<ActionResult> Post(SubjectTeacher subject)
        {
            await _repository.Post(subject);
            return Ok(subject);
        }

        [HttpPut("UpdateSubjectTeacher")]
        public async Task<ActionResult> Put(SubjectTeacher subject)
        {
            await _repository.Put(subject);
            return Ok();
        }

        [HttpDelete("DeleteSubjectTeacherById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
