﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/ExamApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ExamApiController : ControllerBase
    {
        private IExamRepository _repository;
        public ExamApiController(IExamRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetExams")]
        public async Task<ActionResult> Get()
        {
            var exams = await _repository.Get();
            return Ok(exams);
        }

        [HttpGet("GetExamById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var exam = await _repository.Get(id);
            return Ok(exam);
        }


        [HttpPost("InsertExam")]
        public async Task<ActionResult> Post(Exam exam)
        {
            await _repository.Post(exam);
            return Ok(exam);
        }

        [HttpPut("UpdateExam")]
        public async Task<ActionResult> Put(Exam exam)
        {

            await _repository.Put(exam);
            return Ok();
        }

        [HttpDelete("DeleteExamById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
