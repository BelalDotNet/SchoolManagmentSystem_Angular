﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/NoticeApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class NoticeApiController : ControllerBase
    {
        INoticeRepository _repository;
        public NoticeApiController(INoticeRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetNotices")]
        public async Task<ActionResult> Get()
        {
            var notices = await _repository.Get();
            return Ok(notices);
        }

        [HttpGet("GetNoticeById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost("InsertNotice")]
        public async Task<ActionResult> Post(Notice notice)
        {
            await _repository.Post(notice);
            return Ok(notice);
        }

        [HttpPut("UpdateNotice")]
        public async Task<ActionResult> Put(Notice notice)
        {
            await _repository.Put(notice);
            return Ok();

        }

        [HttpDelete("DeleteNoticeById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
