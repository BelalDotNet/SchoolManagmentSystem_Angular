﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/AssignTeacherToClassApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class AssignTeacherToClassApiController : ControllerBase
    {
        ISchoolRepository<AssignTeacherToClass> _repository;
        public AssignTeacherToClassApiController(ISchoolRepository<AssignTeacherToClass> repo)
        {
            _repository = repo;
        }


        [HttpGet("GetAssignTeacherToClass")]
        public async Task<ActionResult> Get()
        {
            var teachers = await _repository.Get();
            return Ok(teachers);
        }

        [HttpGet("GetAssignTeacherToClassById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost("InsertAssignTeacherToClass")]
        public async Task<ActionResult> Post(AssignTeacherToClass teacher)
        {
            await _repository.Post(teacher);
            return Ok(teacher);
        }

        [HttpPut("UpdateAssignTeacherToClass")]
        public async Task<ActionResult> Put(AssignTeacherToClass teacher)
        {
            await _repository.Put(teacher);
            return Ok();

        }

        [HttpDelete("DeleteAssignTeacherToClassById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
