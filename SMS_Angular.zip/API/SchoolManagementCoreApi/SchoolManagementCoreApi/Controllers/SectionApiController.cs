﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/SectionApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class SectionApiController : ControllerBase
    {
        ISchoolRepository<Section> _repository;
        SectionRepository r;
        public SectionApiController(ISchoolRepository<Section> repo, SectionRepository sectionRepository)
        {
            _repository = repo;
            r = sectionRepository;
        }


        [HttpGet("GetSections")]
        public async Task<ActionResult> Get()
        {
            var sec = await _repository.Get();
            return Ok(sec);
        }

        [HttpGet("GetSectionForSpecificClass/{id}")]
        public ActionResult GetSectionForSpecificClass(int id)
        {
            var sections = r.GetSectionForSpecificClass(id);
            return Ok(sections);
        }



        [HttpGet("GetSectionById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost("InsertSection")]
        public async Task<ActionResult> Post(Section section)
        {
            await _repository.Post(section);
            return Ok(section);
        }

        [HttpPut("UpdateSection")]
        public async Task<ActionResult> Put(Section section)
        {
            await _repository.Put(section);
            return Ok();

        }

        [HttpDelete("DeleteSection/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
