﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/SubjectApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class SubjectApiController : ControllerBase
    {
        private ISubjectRepository _repository;
        public SubjectApiController(ISubjectRepository repo)
        {
            _repository = repo;
        }

                                                
        [HttpGet("GetSubjects")]
        public async Task<ActionResult> Get()
        {
            var subjects = await _repository.Get();
            return Ok(subjects);
        }

        [HttpGet("GetSubjectById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var subject = await _repository.Get(id);
            return Ok(subject);
        }


        [HttpPost("InsertSubject")]
        public async Task<ActionResult> Post(Subject subject)
        {
            await _repository.Post(subject);
            return Ok(subject);
        }

        [HttpPut("UpdateSubject")]
        public async Task<ActionResult> Put(Subject subject)
        {

            await _repository.Put(subject);
            return Ok();
        }

        [HttpDelete("DeleteSubjectById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
