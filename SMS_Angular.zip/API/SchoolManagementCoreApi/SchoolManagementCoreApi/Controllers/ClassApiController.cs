﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/ClassApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ClassApiController : ControllerBase
    {
        
        IClassRepository _repository;
        public ClassApiController(IClassRepository repo)
        {
            _repository = repo;
            
        }


        [HttpGet("GetClasses")]
        public async Task<ActionResult> Get()
        {
            var cls = await _repository.Get();
            return Ok(cls);
        }

       


        [HttpGet("GetClassById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var sClass = await _repository.Get(id);
            return Ok(sClass);
        }


        [HttpPost("InsertClass")]
        public async Task<ActionResult> Post(SClass cls)
        {
            await _repository.Post(cls);
            return Ok(cls);
        }

        [HttpPut("UpdateClass")]
        public async Task<ActionResult> Put(SClass cls)
        {
            
            await _repository.Put(cls);
            return Ok();
        }

        [HttpDelete("DeleteClassById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
