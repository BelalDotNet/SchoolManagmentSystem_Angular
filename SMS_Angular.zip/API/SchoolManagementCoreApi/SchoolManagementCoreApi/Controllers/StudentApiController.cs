﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/StudentApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class StudentApiController : ControllerBase
    {
        ISchoolRepository<Student> _repository;
        StudentRepository r;
        public StudentApiController(ISchoolRepository<Student> repo, StudentRepository studentRepository)
        {
            _repository = repo;
            r = studentRepository;
        }


        [HttpGet("GetStudents")]
        public async Task<ActionResult> Get()
        {
            var sec = await _repository.Get();
            return Ok(sec);
        }

        [HttpGet("GetClasses")]
        public ActionResult GetClasses()
        {
            var c = r.GetClasses();
            return Ok(c);
        }

        [HttpGet("GetParents")]
        public ActionResult GetParents()
        {
            var c = r.GetParents();
            return Ok(c);
        }

        [HttpGet("GetSections/{classid}")]
        public ActionResult GetSections(int classid)
        {
            var cs = r.GetSections(classid);
            return Ok(cs);
        }

        [HttpGet("GetDataForEdit/{id}")]
        public ActionResult GetDataForEdit(int id)
        {
            var s = r.GetDataForEdit(id);
            return Ok(s);
        }

        [HttpGet("GetStudentForSpecificClass/{id}/{secid}")]
        public ActionResult GetStudentForSpecificClass(int id, int secid)
        {
            var st = r.GetStudentForSpecificClass(id, secid);
            return Ok(st);
        }


        [HttpGet("GetStudentById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }

        //[HttpPost]
        //[Route("InsertStudent")]
        //public ActionResult InsertStudent(UserStudentVM model)
        //{
        //    try
        //    {
        //        r.InsertStudent(model);
        //        return Ok();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        [HttpPost]
        public async Task<ActionResult> Post(Student student)
        {
            await _repository.Post(student);
            return Ok(student);
        }

        [HttpPut("UpdateStudent")]
        public async Task<ActionResult> Put(Student student)
        {
            await _repository.Put(student);
            return Ok();

        }

        [HttpDelete("DeleteStudent/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
