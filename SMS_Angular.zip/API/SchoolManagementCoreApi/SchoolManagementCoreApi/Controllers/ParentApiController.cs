﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.DAL.Infrastructure;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagementCoreApi.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("api/ParentApi")]
    [ApiController]
    public class ParentApiController : ControllerBase
    {
        IParentRepository _repository;

        public ParentApiController(IParentRepository repo)
        {
            _repository = repo;

        }

        [HttpGet("GetParents")]
        public async Task<ActionResult> Get()
        {
            var parents = await _repository.Get();
            return Ok(parents);
        }

        [HttpGet("GetParentsIdAndName")]
        public ActionResult GetParentsIdAndName()
        {
            var parents = _repository.GetParentsIdAndName();
            return Ok(parents);
        }

        [HttpGet("GetParentById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }

        [HttpPost("InsertParent")]
        public async Task<ActionResult> Post(Parent parent)
        {
            await _repository.Post(parent);
            return Ok(parent);
        }

        [HttpPut("UpdateParent")]
        public async Task<ActionResult> Put(Parent parent)
        {
            await _repository.Put(parent);
            return Ok();

        }


        [HttpDelete("DeleteParent/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
