﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/AssignStudentToClassApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class AssignStudentToClassApiController : ControllerBase
    {
        IAssignStudentToClassRepository _repository;
        public AssignStudentToClassApiController(IAssignStudentToClassRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetAssignStudentToClasses")]
        public async Task<ActionResult> Get()
        {
            var sec = await _repository.Get();
            return Ok(sec);
        }

        [HttpGet("GetAssignStudentToClassById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost("InsertAssignStudentToClass")]
        public async Task<ActionResult> Post(AssignStudentToClass student)
        {
            await _repository.Post(student);
            return Ok(student);
        }

        [HttpPut("UpdateAssignStudentToClass")]
        public async Task<ActionResult> Put( AssignStudentToClass student)
        {
            await _repository.Put(student);
            return Ok();

        }

        [HttpDelete("DeleteAssignStudentToClass/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
