﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using SchoolManagementCoreApi.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;


namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/MarkApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class MarkApiController : ControllerBase
    {
        private IMarkRepository _repository;
        public MarkApiController(IMarkRepository _mark)
        {
            _repository = _mark;
        }


        [HttpGet("GetMarks")]
        public async Task<ActionResult> Get()
        {
            var marks = await _repository.Get();
            return Ok(marks);
        }

        [HttpGet("GetMarkById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var mark = await _repository.Get(id);
            return Ok(mark);
        }

        [HttpGet("GetInfoOfSpecificRoll")]

        public ActionResult GetInfoOfSpecificRoll(MarkEditVM model)
        {
            var info = _repository.GetMarkByStudentRoll(model);
            return Ok(info);
        }

        [HttpPost("InsertMark")]
        public ActionResult PostMark(List<Mark> marks)
        {
            var postMark = _repository.PostMark(marks);
            return Ok(postMark);
        }


        [HttpPost]
        public async Task<ActionResult> Post(Mark mark)
        {
            await _repository.Post(mark);
            return Ok(mark);
        }

        [HttpPut("UpdateMark")]
        public async Task<ActionResult> Put(Mark mark)
        {

            await _repository.Put(mark);
            return Ok();
        }

        [HttpDelete("DeleteMarkById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }

        [HttpGet("GetExams")]
        public ActionResult GetExams()
        {
            var c = _repository.GetExams();
            return Ok(c);
        }

        [HttpGet("GetClasses")]
        public ActionResult GetClasses()
        {
            var c = _repository.GetClasses();
            return Ok(c);
        }

        [HttpGet("GetSections/{classid}")]
        
        public ActionResult GetSections(int classid)
        {
            var cs = _repository.GetSections(classid);
            return Ok(cs);
        }

        [HttpGet("GetSubjects/{classid}")]

        public ActionResult GetSubject(int classid)
        {
            var cs = _repository.GetSubject(classid);
            return Ok(cs);
        }

        [HttpGet("GetStudentToInsertMark/{classID}/{sectionID}")]
        public ActionResult GetStudentToInsertMark(int classID, int sectionID)
        {
            var cs = _repository.GetStudentToInsertMark(classID, sectionID);
            return Ok(cs);
        }

    }
}
