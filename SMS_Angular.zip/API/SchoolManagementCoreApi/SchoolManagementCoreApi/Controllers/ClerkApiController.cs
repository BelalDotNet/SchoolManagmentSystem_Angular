﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/ClerkApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ClerkApiController : ControllerBase
    {
         IClerkRepository _repository;

        public ClerkApiController(IClerkRepository repo)
        {
            _repository = repo;
        }

        [HttpGet("GetClerks")]
       
        public  ActionResult GetAllClerks()
        {
            var clrk = _repository.GetAllClerks();
            return Ok(clrk);
        }
        public ActionResult Get()
        {
            var clrk = _repository.GetAllClerks();
            return Ok(clrk);
        }


        [HttpGet("GetClerkById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var clrk = await _repository.Get(id);
            return Ok(clrk);
        }

        //[HttpPost]
        //[Route("InsertClerk")]
        //public ActionResult InsertClerk(UserClerkVM model)
        //{
        //    try
        //    {
        //        r.InsertClerk(model);
        //        return Ok();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        [HttpPost]
        public async Task<ActionResult> Post(Clerk entity)
        {
            await _repository.Post(entity);
            return Ok(entity);
        }

        [HttpPut("UpdateClerk")]
        public async Task<ActionResult> Put(Clerk entity)
        {

            await _repository.Put(entity);
            return Ok();
        }

        [HttpDelete("DeleteClerk/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
