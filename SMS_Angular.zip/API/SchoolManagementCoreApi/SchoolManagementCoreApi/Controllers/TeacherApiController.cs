﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/TeacherApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class TeacherApiController : ControllerBase
    {
        ISchoolRepository<Teacher> _repository;
        TeacherRepository r;
        public TeacherApiController(ISchoolRepository<Teacher> repo, TeacherRepository repository)
        {
            _repository = repo;
            r = repository;
        }


        [HttpGet("GetTeachers")]
        public async Task<ActionResult> Get()
        {
            var teachers = await _repository.Get();
            return Ok(teachers);
        }

        [HttpGet("GetTeacherById/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost("InsertTeacher")]
        public async Task<ActionResult> Post(Teacher teacher)
        {
            await _repository.Post(teacher);
            return Ok(teacher);
        }

        //[HttpPost("Insert")]
        //public ActionResult InsertTeacher(UserTeacherVM model)
        //{
        //    try
        //    {
        //        r.InsertTeacher(model);
        //        return Ok();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}


        [HttpPut("UpdateTeacher")]
        public async Task<ActionResult> Put(Teacher teacher)
        {
            await _repository.Put(teacher);
            return Ok();

        }

        [HttpDelete("DeleteTeacherById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
