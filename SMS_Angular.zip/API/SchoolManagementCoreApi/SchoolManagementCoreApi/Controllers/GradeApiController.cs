﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.Controllers
{
    [Route("api/GradeApi")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class GradeApiController : ControllerBase
    {
       private IGradeRepository _repository;
        public GradeApiController(IGradeRepository repo)
        {
            _repository = repo;
        }


        [HttpGet("GetGrades")]
        public async Task<ActionResult> Get()
        {
            var grades = await _repository.Get();
            return Ok(grades);
        }

        [HttpGet("GetGradebyId/{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var grade = await _repository.Get(id);
            return Ok(grade);
        }


        [HttpPost("InsertGrade")]
        public async Task<ActionResult> Post(Grade grade)
        {
            await _repository.Post(grade);
            return Ok(grade);
        }

        [HttpPut("UpdateGrade")]
        public async Task<ActionResult> Put(Grade grade)
        {

            await _repository.Put(grade);
            return Ok();
        }

        [HttpDelete("DeleteGradeById/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
