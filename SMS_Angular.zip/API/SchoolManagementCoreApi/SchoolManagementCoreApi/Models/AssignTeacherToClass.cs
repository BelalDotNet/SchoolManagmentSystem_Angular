﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models
{
    public class AssignTeacherToClass
    {
        public int ID { get; set; }
        public int ClassSectionID { get; set; }
        public int TeacherID { get; set; }
        public bool IsClassTeacher { get; set; }

        public  ClassSection ClassSection { get; set; }
        public  Teacher Teacher { get; set; }
    }
}