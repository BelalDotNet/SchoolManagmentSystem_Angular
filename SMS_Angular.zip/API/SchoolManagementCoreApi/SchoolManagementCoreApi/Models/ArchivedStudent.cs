﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace SchoolManagementCoreApi.Models
{
    public class ArchivedStudent
    {
        public int ArchivedStudentID { get; set; }

        public string RollNo { get; set; }


        public string SessionYear { get; set; }


        public string StudentRegID { get; set; }


        public string ClassName { get; set; }


        public string SectionName { get; set; }
    }
}