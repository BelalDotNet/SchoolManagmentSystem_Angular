﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagementCoreApi.Models
{
    public class Notice
    {
        public int NoticeID { get; set; }
        public string Title { get; set; }
        public string Date { get; set; }
        public string ImagePath { get; set; }
        public string FileLink { get; set; }
        public bool IsDisplay { get; set; }
        public string CreatedBy { get; set; }
    }
}