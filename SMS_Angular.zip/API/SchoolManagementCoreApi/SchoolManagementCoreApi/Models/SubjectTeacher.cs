﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace SchoolManagementCoreApi.Models
{
    public class SubjectTeacher
    {
        public int ID { get; set; }

        [Required]
        [Display(Name = "Teacher ID")]
        public int TeacherID { get; set; }


        [Required]
        [Display(Name = "Subject ID")]
        public int SubjectID { get; set; }


        public ICollection<Routine> Routines { get; set; }
        public Teacher Teacher { get; set; }
        public Subject Subject { get; set; }
    }
}