﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models.ViewModels
{
    public class MarkEditVM
    {
        public int ExamId { get; set; }
        public int ClassId { get; set; }
        public int SectionId { get; set; }
        public string Year { get; set; }
        public int Roll { get; set; }

    }
}
