﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagementCoreApi.Models
{
    public class Routine
    {
        public int RoutineID { get; set; }

        [Required]
        [Display(Name = "Class Section ID")]
        public int ClassSectionID { get; set; }

        [Required]
        [Display(Name = "Subject Teacher ID")]
        public int SubjectTeacherID { get; set; }

        [Required]
        public string Day { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string CreatedBy { get; set; }
        public bool IsActive { get; set; }

        public SubjectTeacher SubjectTeacher { get; set; }
        public ClassSection ClassSection { get; set; }
    }
}