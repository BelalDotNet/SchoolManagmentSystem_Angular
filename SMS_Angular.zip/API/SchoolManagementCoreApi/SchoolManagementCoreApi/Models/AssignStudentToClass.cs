﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models
{
    public class AssignStudentToClass
    {
        public int ID { get; set; }
        public int RollNo { get; set; }
        public string SessionYear { get; set; }
        public int StudentID { get; set; }
        public int ClassSectionID { get; set; }
        public string PresentStatus { get; set; }

        public  ClassSection ClassSection { get; set; }
        public  Student Student { get; set; }

        public  ICollection<Mark> Marks { get; set; }

    }
}