﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagementCoreApi.Models
{
    public class Mark
    {
        public int MarkID { get; set; }


        [Required]
        [Display(Name = "Class Section ID")]
        public int ClassSectionID { get; set; }


        [Display(Name = "Subject ID")]
        public int SubjectID { get; set; }


        [Display(Name = "Exam ID")]
        public int ExamID { get; set; }


        [Display(Name = "Passing Year")]
        [DataType(DataType.Date)]
        public DateTime PassingYear { get; set; }


        [Display(Name = "Student Class Assign ID")]
        public int AssignStudentToClassID { get; set; }


        [Display(Name = "Obtained Marks")]
        public decimal ObtainedMark { get; set; }


        [Display(Name = "Full Marks")]
        public decimal SubjectMark { get; set; }


        [Display(Name = "Grade ID")]
        public int GradeID { get; set; }


        [Display(Name = "Entry By")]
        public string EntryBy { get; set; }


        [DataType(DataType.Date)]
        [Display(Name = "Entry Date")]
        public DateTime EntryDate { get; set; }




        public Exam Exam { get; set; }
        public Grade Grade { get; set; }
        public ClassSection ClassSection { get; set; }
        public Subject Subject { get; set; }
        public AssignStudentToClass AssignStudentToClass { get; set; }
    }
}