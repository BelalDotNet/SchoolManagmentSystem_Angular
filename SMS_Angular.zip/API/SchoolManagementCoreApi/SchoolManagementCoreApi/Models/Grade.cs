﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models
{
    public class Grade
    {
        public int GradeID { get; set; }

        [Display(Name = "Grade Range")]
        public string GradeRange { get; set; }


        [Display(Name ="Grade Point")]
        public decimal GradePoint { get; set; }

       

        [Display(Name = "Grade Name")]
        public string GradeName { get; set; }


        public string Comment { get; set; }
        public  ICollection<Mark> Marks { get; set; }

    }
}