﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SchoolManagementCoreApi.Models
{
    public class ApplicationUser : IdentityUser
    {
        //Start Custom Identity Here
        public  ICollection<Clerk> Clerks { get; set; }
        public  ICollection<Student> Students { get; set; }
        public  ICollection<Teacher> Teachers { get; set; }

    }
    public class ApplicationDbContext:IdentityDbContext<ApplicationUser>
    {       
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public ApplicationDbContext()
        {

        }

        public DbSet<ArchivedStudent> ArchivedStudents { get; set; }
        public DbSet<AssignStudentToClass> AssignStudentToClasses { get; set; }
        public DbSet<AssignTeacherToClass> AssignTeacherToClasses { get; set; }
        public DbSet<ClassSection> ClassSections { get; set; }
        public DbSet<Clerk> Clerks { get; set; }
        public DbSet<Exam> Exams { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public DbSet<Mark> Marks { get; set; }
        public DbSet<Notice> Notices { get; set; }
        public DbSet<Parent> Parents { get; set; }
        public DbSet<Routine> Routines { get; set; }
        public DbSet<SClass> SClasses { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<SubjectTeacher> SubjectTeachers { get; set; }
        public DbSet<Teacher> Teachers { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity(typeof(ClassSection))
           .HasOne(typeof(SClass), "SClass")
           .WithMany()
           .HasForeignKey("SClassID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE



            builder.Entity(typeof(ClassSection))
            .HasOne(typeof(Section), "Section")
            .WithMany()
            .HasForeignKey("SectionID")
            .OnDelete(DeleteBehavior.Restrict); // no ON DELETE



            builder.Entity(typeof(AssignStudentToClass))
            .HasOne(typeof(ClassSection), "ClassSection")
            .WithMany()
            .HasForeignKey("ClassSectionID")
            .OnDelete(DeleteBehavior.Restrict); // no ON DELETE



            builder.Entity(typeof(AssignStudentToClass))
            .HasOne(typeof(Student), "Student")
            .WithMany()
            .HasForeignKey("StudentID")
            .OnDelete(DeleteBehavior.Restrict); // no ON DELETE


            builder.Entity(typeof(Mark))
           .HasOne(typeof(Grade), "Grade")
           .WithMany()
           .HasForeignKey("GradeID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE

            builder.Entity(typeof(Mark))
           .HasOne(typeof(Exam), "Exam")
           .WithMany()
           .HasForeignKey("ExamID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE

            builder.Entity(typeof(Mark))
           .HasOne(typeof(ClassSection), "ClassSection")
           .WithMany()
           .HasForeignKey("ClassSectionID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE

            builder.Entity(typeof(Mark))
           .HasOne(typeof(Subject), "Subject")
           .WithMany()
           .HasForeignKey("SubjectID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE


            builder.Entity(typeof(Mark))
           .HasOne(typeof(AssignStudentToClass), "AssignStudentToClass")
           .WithMany()
           .HasForeignKey("ID")
           .OnDelete(DeleteBehavior.Restrict); // no ON DELETE
        }




    }
}
