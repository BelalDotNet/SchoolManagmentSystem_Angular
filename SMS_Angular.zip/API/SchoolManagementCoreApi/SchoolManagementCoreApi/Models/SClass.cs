﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagementCoreApi.Models
{
    public class SClass
    {
        public int SClassID { get; set; }


        [Required]
        [Display(Name = "Class Name")]
        public string ClassName { get; set; }


        [Required]
        [Display(Name = "Numeric Name")]
        public string ClassName_Numeric { get; set; }
        public bool? IsActive { get; set; }

        public ICollection<ClassSection> ClassSection { get; set; }

    }
}