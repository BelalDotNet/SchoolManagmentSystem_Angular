﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models
{
    public class ClassSection
    {
        public int ClassSectionID { get; set; }
        public int SClassID { get; set; }
        public int SectionID { get; set; }

        public ICollection<AssignStudentToClass> AssignStudentdToClasses { get; set; }
        public SClass SClass { get; set; }
        public Section Section { get; set; }
        public ICollection<AssignTeacherToClass> AssignTeacherToClasses { get; set; }
        public ICollection<Routine> Routines { get; set; }
        public ICollection<Mark> Marks { get; set; }


    }
}