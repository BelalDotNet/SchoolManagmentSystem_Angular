﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.Models
{
    public class Teacher
    {
        public int TeacherID { get; set; }

        public string Name { get; set; }
        public string NID { get; set; }

        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }
        public string Gender { get; set; }

        public string Address { get; set; }

        [Required]
        [Display(Name = "User ID")]
        public string ApplicationUserID { get; set; }

        [Required]
        public string Designation { get; set; }
        public string Image { get; set; }
        public bool? IsActive { get; set; }

        public ApplicationUser ApplicationUser { get; set; }
        public ICollection<SubjectTeacher> SubjectTeachers { get; set; }
        public ICollection<AssignTeacherToClass> AssignTeacherToClasses { get; set; }
    }
}