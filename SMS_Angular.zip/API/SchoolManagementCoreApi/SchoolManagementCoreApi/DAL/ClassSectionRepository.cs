﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class ClassSectionRepository: IClassSectionRepository
    {
        ApplicationDbContext ctx;
        public ClassSectionRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var cls = ctx.ClassSections.Find(id);
            if (cls != null)
            {
                ctx.ClassSections.Remove(cls);
                await ctx.SaveChangesAsync();
            }
            return null;
        }

        public IEnumerable<SClass> GetAllClasses()
        {
            return (from c in ctx.SClasses
                select c).ToList();
        }

        public IEnumerable<object> GetAllSectionsForSpecificClass(int id)
        {
            return (from c in ctx.SClasses
                    join cs in ctx.ClassSections
                        on c.SClassID equals cs.SClassID
                    join s in ctx.Sections
                        on cs.SectionID equals s.SectionID
                    where c.SClassID == cs.SClassID && cs.SectionID == s.SectionID
                    where c.SClassID == id
                    select new { s.SectionName, s.NickName, cs.ClassSectionID }
                ).ToList();
        }


        public IEnumerable<object> GetAllSectionsForSpecificClassIU(int id)
        {
            return (from a in ctx.Sections select a).Except(from c in ctx.SClasses
                join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                where c.SClassID == cs.SClassID && cs.SectionID == s.SectionID
                where c.SClassID == id
                select s);
        }


        public async Task<IEnumerable<ClassSection>> Get()
        {
            return await ctx.ClassSections.ToListAsync();
        }

        public async Task<ClassSection> Get(int id)
        {
            return await ctx.ClassSections.FindAsync(id);
        }

        
        public async Task<object> Post(ClassSection entity)
        {
            ctx.ClassSections.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }

        
        public async Task<object> Put(ClassSection entity)
        {
            try
            {
                ClassSection cls = new ClassSection();
                cls = ctx.ClassSections.Find(entity.ClassSectionID);
                if (cls != null)
                {
                    cls.SClassID = entity.SClassID;
                    cls.SectionID = entity.SectionID;
                    ctx.Entry(cls).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return entity;
        }
    }
}