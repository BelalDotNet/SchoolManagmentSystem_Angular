﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.DAL
{
    public interface ISchoolRepository<TEntity> where TEntity:class
    {
        Task<IEnumerable<TEntity>> Get();
        Task<TEntity> Get(int id);
        Task<object> Post(TEntity entity);
        Task<object> Put(TEntity entity);
        Task<object> Delete(int id);
    }
}
