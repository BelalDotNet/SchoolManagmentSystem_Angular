﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class SubjectRepository :ISubjectRepository
    {
        ApplicationDbContext ctx;
        public SubjectRepository(ApplicationDbContext context)
        {
            ctx = context;
        }


        public async Task<object> Delete(int id)
        {
            var subject = ctx.Subjects.Find(id);
            if (subject != null)
            {
                ctx.Subjects.Remove(subject);
                await ctx.SaveChangesAsync();
            }
            return null;
        }



        public async Task<IEnumerable<Subject>> Get()
        {
            return await ctx.Subjects.ToListAsync();
        }

        public async Task<Subject> Get(int id)
        {
            return await ctx.Subjects.FindAsync(id);
        }



        public async Task<object> Post(Subject entity)
        {
            ctx.Subjects.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(Subject entity)
        {

            try
            {
                Subject subject = new Subject();
                subject = ctx.Subjects.Find(entity.SubjectID);
                if (subject != null)
                {
                    subject.SubjectName = entity.SubjectName;
                    ctx.Entry(subject).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();

            }
            catch (Exception)
            {

                throw;
            }


            return entity;
        }




        









    }
}