﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;


namespace SchoolManagementCoreApi.DAL
{
    public class ParentRepository:IParentRepository
    {
        ApplicationDbContext ctx;
        public ParentRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }        

        public async Task<IEnumerable<Parent>> Get()
        {
            return await ctx.Parents.ToListAsync();
        }

        public IEnumerable<Parent> GetParentsIdAndName()
        {
            return (from p in ctx.Set<Parent>()
                    select new { Name = p.ParentName, ParentID = p.ParentID }).ToList()
                .Select(x => new Parent { ParentName = x.Name, ParentID = x.ParentID });
        }


        public async Task<Parent> Get(int id)
        {
            return await ctx.Parents.FindAsync(id);
        }


        public async Task<object> Post(Parent entity)
        {
            ctx.Parents.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }

        public async Task<object> Put(Parent entity)
        {
            try
            {
                Parent parent = new Parent();
                parent = ctx.Parents.Find(entity.ParentID);
                if (parent != null)
                {
                    parent.ParentName = entity.ParentName;
                    parent.Profession = entity.Profession;
                    parent.NID = entity.NID;
                    parent.IsActive = entity.IsActive;
                    ctx.Entry(parent).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return entity;
        }

        public async Task<object> Delete(int id)
        {
            var parent = ctx.Parents.Find(id);
            if (parent != null)
            {
                ctx.Parents.Remove(parent);
                await ctx.SaveChangesAsync();
            }
            return null;

        }
    }
}