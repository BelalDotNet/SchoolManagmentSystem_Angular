﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.DAL
{
    public class TeacherRepository : ISchoolRepository<Teacher>
    {
        ApplicationDbContext context;
        public TeacherRepository(ApplicationDbContext dbContext)
        {
            context = dbContext;
        }





        public async Task<IEnumerable<Teacher>> Get()
        {
            return await context.Teachers.ToListAsync();
        }

        public async Task<Teacher> Get(int id)
        {
            return await context.Teachers.FindAsync(id);
        }






        public async Task<object> Post(Teacher entity)
        {
            context.Teachers.Add(entity);
            await context.SaveChangesAsync();
            return null;
        }


        //  public UserManager<ApplicationUser> userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));

        //public void InsertTeacher(UserTeacherVM model)
        //{
        //    var user = new ApplicationUser
        //    {
        //        Email = model.Email,
        //        PhoneNumber = model.PhoneNumber,
        //        UserName = model.Email
        //    };
        //    IdentityResult result = userManager.Create(user, model.Password);

        //    var teacher = new Teacher
        //    {
        //        Name = model.Name,
        //        NID = model.NID,
        //        DOB = model.DOB,
        //        Gender = model.Gender,
        //        Address = model.Address,
        //        ApplicationUserID = user.Id,
        //        Designation = model.Designation,
        //        Image = model.Image,
        //        IsActive = model.IsActive
        //    };
        //    if (result.Succeeded)
        //    {
        //        try
        //        {
        //            context.Teachers.Add(teacher);
        //            context.SaveChanges();
        //        }
        //        catch (Exception)
        //        {

        //            throw;
        //        }

        //    }
        //}

        public async Task<object> Put(Teacher entity)
        {
            try
            {
                Teacher teacher = new Teacher();
                teacher = context.Teachers.Find(entity.TeacherID);
                if (teacher != null)
                {
                    teacher.Name = entity.Name;
                    teacher.NID = entity.NID;
                    teacher.DOB = entity.DOB;
                    teacher.Gender = entity.Gender;
                    teacher.Address = entity.Address;
                    teacher.Designation = entity.Designation;
                    teacher.Image = entity.Image;
                    teacher.ApplicationUserID = entity.ApplicationUserID;
                    teacher.IsActive = entity.IsActive;


                    context.Entry(teacher).State = EntityState.Modified;
                }
                await context.SaveChangesAsync();


            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }






        public async Task<object> Delete(int id)
        {
            var teacher = context.Teachers.Find(id);
            if (teacher != null)
            {
                context.Teachers.Remove(teacher);
                await context.SaveChangesAsync();
            }
            return null;
        }
    }
}