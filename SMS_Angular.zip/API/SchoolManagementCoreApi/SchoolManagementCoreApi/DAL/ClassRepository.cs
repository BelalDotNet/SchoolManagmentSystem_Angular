﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using  SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class ClassRepository:IClassRepository
    {
        ApplicationDbContext ctx;
        public ClassRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var cls = ctx.SClasses.Find(id);
            if (cls != null)
            {
                ctx.SClasses.Remove(cls);
                await ctx.SaveChangesAsync();
            }
            return null;
        }





        public async Task<IEnumerable<SClass>> Get()
        {
            return await ctx.SClasses.ToListAsync();
        }

        public IEnumerable<SClass> GetClassIdAndName()
        {
            return (from p in ctx.Set<SClass>()
                    select new { Name = p.ClassName, SClassID = p.SClassID }).ToList()
                .Select(x => new SClass { ClassName = x.Name, SClassID = x.SClassID });
        }


        public async Task<SClass> Get(int id)
        {
            return await ctx.SClasses.FindAsync(id);
        }







        public async Task<object> Post(SClass entity)
        {
            ctx.SClasses.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(SClass entity)
        {
            try
            {
                SClass cls = new SClass();
                cls = ctx.SClasses.Find(entity.SClassID);
                if (cls != null)
                {
                    cls.ClassName = entity.ClassName;
                    cls.ClassName_Numeric = entity.ClassName_Numeric;
                    cls.IsActive = entity.IsActive;
                    ctx.Entry(cls).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return entity;
        }
    }
}