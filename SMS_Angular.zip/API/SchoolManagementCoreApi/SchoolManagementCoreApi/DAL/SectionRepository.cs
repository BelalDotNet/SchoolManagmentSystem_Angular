﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.DAL
{
    public class SectionRepository:ISchoolRepository<Section>
    {
        ApplicationDbContext ctx;
        public SectionRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }

        

        public async Task<IEnumerable<Section>> Get()
        {
            return await ctx.Sections.ToListAsync();
        }

        public IEnumerable<Section> GetSectionForSpecificClass(int id)
        {
            return (from p in ctx.Set<Section>()
                    join s in ctx.Set<ClassSection>()
                        on p.SectionID equals s.SectionID
                    join c in ctx.Set<SClass>()
                        on s.SClassID equals c.SClassID
                    where s.SClassID == id
                    select new { SectionName = p.SectionName, SectionID = p.SectionID }).ToList()
                .Select(x => new Section { SectionName = x.SectionName, SectionID = x.SectionID });
        }


        public async Task<Section> Get(int id)
        {
            return await ctx.Sections.FindAsync(id);
        }






        public async Task<object> Post(Section entity)
        {
            ctx.Sections.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }

       

        public async Task<object> Put(Section entity)
        {
            try
            {
                Section section = new Section();
                section = ctx.Sections.Find(entity.SectionID);
                if (section != null)
                {
                    section.SectionName = entity.SectionName;
                    section.NickName = entity.NickName;
                    section.IsActive = entity.IsActive;
                    ctx.Entry(section).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }





        public async Task<object> Delete(int id)
        {
            var cls = ctx.Sections.Find(id);
            if (cls != null)
            {
                ctx.Sections.Remove(cls);
                await ctx.SaveChangesAsync();
            }
            return null;
        }
    }
}