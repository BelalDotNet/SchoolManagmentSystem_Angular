﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.Models;
using SchoolManagementCoreApi.Models.ViewModels;

namespace SchoolManagementCoreApi.DAL.Infrastructure
{
    public interface IMarkRepository:ISchoolRepository<Mark>
    {
        IEnumerable<object> GetExams();
        IEnumerable<object> GetClasses();
        object PostMark(List<Mark> marks);
        IEnumerable<object> GetSections(int classid);
        IEnumerable<object> GetSubject(int classid);
        IEnumerable<object> GetStudentToInsertMark(int classID, int sectionID);
        IEnumerable<object> GetMarkByStudentRoll(MarkEditVM model);


    }
}
 