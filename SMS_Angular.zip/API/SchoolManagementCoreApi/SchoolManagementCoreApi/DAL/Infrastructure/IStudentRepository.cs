﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.Models;

namespace SchoolManagementCoreApi.DAL.Infrastructure
{
    public interface IStudentRepository:ISchoolRepository<Student>
    {
        IEnumerable<object> GetClasses();
        IEnumerable<object> GetParents();
        IEnumerable<object> GetSections(int classid);
        IEnumerable<object> GetStudentForSpecificClass(int id, int secid);
        IEnumerable<object> InsertStudent();
        IEnumerable<object> GetDataForEdit(int? id);

    }
}
