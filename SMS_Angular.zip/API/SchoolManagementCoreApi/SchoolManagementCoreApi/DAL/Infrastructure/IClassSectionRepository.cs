﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.Models;

namespace SchoolManagementCoreApi.DAL.Infrastructure
{
  public interface IClassSectionRepository:ISchoolRepository<ClassSection>
  {
      IEnumerable<SClass> GetAllClasses();
      IEnumerable<object> GetAllSectionsForSpecificClass(int id);
      IEnumerable<object> GetAllSectionsForSpecificClassIU(int id);
  }
}
