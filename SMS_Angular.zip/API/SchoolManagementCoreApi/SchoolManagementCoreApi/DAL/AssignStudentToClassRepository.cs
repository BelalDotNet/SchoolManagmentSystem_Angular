﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class AssignStudentToClassRepository:IAssignStudentToClassRepository
    {
        ApplicationDbContext ctx;
        public AssignStudentToClassRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }






        public async Task<IEnumerable<AssignStudentToClass>> Get()
        {
            return await ctx.AssignStudentToClasses.ToListAsync();
        }

        public async Task<AssignStudentToClass> Get(int id)
        {
            return await ctx.AssignStudentToClasses.FindAsync(id);
        }





        public async Task<object> Post(AssignStudentToClass entity)
        {
            ctx.AssignStudentToClasses.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }






        public async Task<object> Put(AssignStudentToClass entity)
        {
            try
            {
                AssignStudentToClass student = new AssignStudentToClass();
                student = ctx.AssignStudentToClasses.Find(entity.ID);
                if (student != null)
                {
                    student.RollNo = entity.RollNo;
                    student.SessionYear = entity.SessionYear;
                    student.StudentID = entity.StudentID;
                    student.ClassSectionID = entity.ClassSectionID;
                    student.PresentStatus = entity.PresentStatus;
                }
                ctx.Entry(student).State = EntityState.Modified;
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }



            return entity;
        }





        public async Task<object> Delete(int id)
        {
            var student = ctx.AssignStudentToClasses.Find(id);
            if (student != null)
            {
                ctx.AssignStudentToClasses.Remove(student);
                await ctx.SaveChangesAsync();

            }
            return null;
        }
    }
}