﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class GradeRepository:IGradeRepository
    {
        ApplicationDbContext ctx;
        public GradeRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var grade = ctx.Grades.Find(id);
            if (grade != null)
            {
                ctx.Grades.Remove(grade);
                await ctx.SaveChangesAsync();
            }
            return null;
        }





        public async Task<IEnumerable<Grade>> Get()
        {
            return await ctx.Grades.ToListAsync();
        }

        public async Task<Grade> Get(int id)
        {
            return await ctx.Grades.FindAsync(id);
        }







        public async Task<object> Post(Grade grade)
        {
            ctx.Grades.Add(grade);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(Grade entity)
        {
            try
            {
                Grade grade = new Grade();
                grade = ctx.Grades.Find(entity.GradeID);
                if (grade != null)
                {
                    grade.GradeName = entity.GradeName;
                    grade.GradePoint = entity.GradePoint;
                    grade.GradeRange = entity.GradeRange;
                    grade.Comment = entity.Comment;
                    ctx.Entry(grade).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }
    }
}