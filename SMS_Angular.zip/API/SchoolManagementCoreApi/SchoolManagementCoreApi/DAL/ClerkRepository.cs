﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SchoolManagementCoreApi.DAL.Infrastructure;

namespace SchoolManagementCoreApi.DAL
{
    public class ClerkRepository:IClerkRepository
    {
        ApplicationDbContext ctx;
        public ClerkRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var clrk = ctx.Clerks.Find(id);
            if (clrk != null)
            {
                ctx.Clerks.Remove(clrk);
                await ctx.SaveChangesAsync();
            }
            return null;
        }

        public  IEnumerable<object> GetAllClerks()
        {
            return (from c in ctx.Clerks
                join u in ctx.Users
                    on c.ApplicationUserID equals u.Id
                select new { c.Name, u.Email, u.PhoneNumber, c.NID, c.DOB, c.Gender, c.Image }).ToList();
        }




        public async Task<IEnumerable<Clerk>> Get()
        {
            return await ctx.Clerks.ToListAsync();
        }

        public async Task<Clerk> Get(int id)
        {
            return await ctx.Clerks.FindAsync(id);
        }

        // public UserManager<ApplicationUser> userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));

        //public void insertclerk(userclerkvm model)
        //{
        //    var user = new applicationuser
        //    {
        //        email = model.email,
        //        phonenumber = model.phonenumber,
        //        username = model.email
        //    };
        //    identityresult result = usermanager.create(user, model.password);

        //    var clerk = new clerk
        //    {
        //        name = model.name,
        //        nid = model.nid,
        //        dob = model.dob,
        //        gender = model.gender,
        //        address = model.address,
        //        applicationuserid = user.id,
        //        image = model.image,
        //    };
        //    if (result.succeeded)
        //    {
        //        try
        //        {
        //            ctx.clerks.add(clerk);
        //            ctx.savechanges();
        //        }
        //        catch (exception)
        //        {

        //            throw;
        //        }

        //    }
        //}





        public async Task<object> Post(Clerk entity)
        {
            ctx.Clerks.Add(entity);
            await ctx.SaveChangesAsync();
            return entity;
        }





        public async Task<object> Put(Clerk entity)
        {
            try
            {
                Clerk clrk = new Clerk();
                clrk = ctx.Clerks.Find(entity.ClerkID);
                if (clrk != null)
                {
                    clrk.Name = entity.Name;
                    clrk.NID = entity.NID;
                    clrk.DOB = entity.DOB;
                    clrk.Gender = entity.Gender;
                    clrk.Address = entity.Address;
                    clrk.ApplicationUserID = entity.ApplicationUserID;
                    clrk.Image = entity.Image;

                    ctx.Entry(clrk).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }
    }
}