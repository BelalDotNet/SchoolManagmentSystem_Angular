﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using SchoolManagementCoreApi.DAL.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.DAL
{
    public class AssignTeacherToClassRepository:IAssignTeacherToClassRepository
    {
        ApplicationDbContext context;
        public AssignTeacherToClassRepository(ApplicationDbContext dbContext)
        {
            context = dbContext;
        }





        public async Task<IEnumerable<AssignTeacherToClass>> Get()
        {
            return await context.AssignTeacherToClasses.ToListAsync();
        }

        public async Task<AssignTeacherToClass> Get(int id)
        {
            return await context.AssignTeacherToClasses.FindAsync(id);
        }






        public async Task<object> Post(AssignTeacherToClass entity)
        {
            context.AssignTeacherToClasses.Add(entity);
            await context.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(AssignTeacherToClass entity)
        {
            try
            {
                AssignTeacherToClass teacher = new AssignTeacherToClass();
                teacher = context.AssignTeacherToClasses.Find(entity.ID);
                if (teacher != null)
                {
                    teacher.ClassSectionID = entity.ClassSectionID;
                    teacher.TeacherID = entity.TeacherID;
                    teacher.IsClassTeacher = entity.IsClassTeacher;
                    context.Entry(teacher).State = EntityState.Modified;
                }
                await context.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }






        public async Task<object> Delete(int id)
        {
            var teacher = context.AssignTeacherToClasses.Find(id);
            if (teacher != null)
            {
                context.AssignTeacherToClasses.Remove(teacher);
                await context.SaveChangesAsync();
            }
            return null;
        }
    }
}