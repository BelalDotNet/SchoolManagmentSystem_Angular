﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementCoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementCoreApi.DAL
{
    public class StudentRepository:ISchoolRepository<Student>
    {
        ApplicationDbContext ctx;
        public StudentRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }




        

        public async Task<IEnumerable<Student>> Get()
        {
            return await ctx.Students.ToListAsync();
        }

        public IEnumerable<object> GetClasses()
        {
            return (from c in ctx.SClasses
                select new { c.ClassName, c.SClassID }).ToList();
        }

        public IEnumerable<object> GetParents()
        {
            return (from c in ctx.Parents
                select new { c.ParentID, c.ParentName }).ToList();
        }

        public IEnumerable<object> GetSections(int classid)
        {
            return (from c in ctx.SClasses
                join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                where c.SClassID == classid
                select new { c.SClassID, c.ClassName, s.SectionID, s.SectionName }).ToList();
        }

        public IEnumerable<object> GetStudentForSpecificClass(int id, int secid)
        {
            return (from c in ctx.SClasses
                join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                join asc in ctx.AssignStudentToClasses
                    on cs.ClassSectionID equals asc.ClassSectionID
                join st in ctx.Students
                    on asc.StudentID equals st.StudentID
                join pr in ctx.Parents
                    on st.ParentID equals pr.ParentID
                join u in ctx.Users
                    on st.ApplicationUserID equals u.Id
                where st.ApplicationUserID == u.Id
                where c.SClassID == id && s.SectionID == secid
                where cs.SClassID == c.SClassID
                where cs.SectionID == s.SectionID
                select new { st.StudentID, st.StudentRegID, st.Name, s.SectionName, st.Gender, st.DOB, st.NID, pr.ParentName, u.Email, u.PhoneNumber }).ToList();
        }

        // public UserManager<ApplicationUser> userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));

        //public void InsertStudent(UserStudentVM model)
        //{
        //    var user = new ApplicationUser
        //    {

        //        Email = model.Email,
        //        PhoneNumber = model.PhoneNumber,
        //        UserName = model.Email
        //    };
        //    IdentityResult result = userManager.Create(user, model.Password);

        //    var student = new Student
        //    {
        //        StudentRegID = model.StudentRegID,
        //        Name = model.Name,
        //        NID = model.NID,
        //        DOB = model.DOB,
        //        Gender = model.Gender,
        //        Address = model.Address,
        //        ApplicationUserID = user.Id,
        //        ParentID = model.ParentID,
        //        Image = model.Image,
        //        IsActive = model.IsActive
        //    };
        //    if (result.Succeeded)
        //    {
        //        try
        //        {
        //            ctx.Students.Add(student);
        //            ctx.SaveChanges();
        //        }
        //        catch (Exception)
        //        {

        //            throw;
        //        }

        //    }
        //}


        public async Task<Student> Get(int id)
        {
            return await ctx.Students.FindAsync(id);
        }

        public object GetDataForEdit(int? id)
        {
            return (from st in ctx.Students
                join u in ctx.Users
                    on st.ApplicationUserID equals u.Id
                join pr in ctx.Parents
                    on st.ParentID equals pr.ParentID
                where st.ParentID == pr.ParentID
                where st.StudentID == id
                select new { st.StudentID, st.Name, st.Address, st.DOB, st.Gender, st.Image, st.IsActive, st.NID, st.StudentRegID, u.Email, u.PhoneNumber, pr.ParentName }).Single();
        }



        public async Task<object> Post(Student entity)
        {
            ctx.Students.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }






        public async Task<object> Put(Student entity)
        {
            try
            {
                Student student = new Student();
                student = ctx.Students.Find(entity.StudentID);
                if (student != null)
                {
                    student.StudentRegID = entity.StudentRegID;
                    student.Name = entity.Name;
                    student.NID = entity.NID;
                    student.DOB = entity.DOB;
                    student.Gender = entity.Gender;
                    student.Address = entity.Address;
                    student.ParentID = entity.ParentID;
                    student.Image = entity.Image;
                    student.ApplicationUserID = entity.ApplicationUserID;
                    student.IsActive = entity.IsActive;

                    ctx.Entry(student).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();

            }
            catch (Exception)
            {

                throw;
            }

            return entity;
        }





        public async Task<object> Delete(int id)
        {
            var student = ctx.Students.Find(id);
            if (student != null)
            {
                ctx.Students.Remove(student);
                await ctx.SaveChangesAsync();
                
            }
            return null;
        }
    }
}