﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SchoolManagementCoreApi.DAL;
using SchoolManagementCoreApi.DAL.Infrastructure;
using SchoolManagementCoreApi.Models;
using Microsoft.AspNetCore.Cors;

namespace SchoolManagementCoreApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<ISchoolRepository<AssignStudentToClass>, AssignStudentToClassRepository>();
            services.AddTransient<ISchoolRepository<AssignTeacherToClass>, AssignTeacherToClassRepository>();
            services.AddTransient<ISchoolRepository<ClassSection>, ClassSectionRepository>();
            services.AddTransient<IClerkRepository, ClerkRepository>();
            services.AddTransient<ISchoolRepository<Exam>, ExamRepository>();
            services.AddTransient<ISchoolRepository<Grade>, GradeRepository>();
            services.AddTransient<IMarkRepository, MarkRepository>();
            services.AddTransient<ISchoolRepository<Notice>, NoticeRepository>();
            services.AddTransient<IParentRepository, ParentRepository>();
            services.AddTransient<ISchoolRepository<Routine>, RoutineRepository>();
            services.AddTransient<ISchoolRepository<SClass>, ClassRepository>();
            services.AddTransient<ISchoolRepository<Section>, SectionRepository>();
            services.AddTransient<ISchoolRepository<Student>, StudentRepository>();
            services.AddTransient<ISchoolRepository<Subject>, SubjectRepository>();
            services.AddTransient<ISchoolRepository<SubjectTeacher>, SubjectTeacherRepository>();
            services.AddTransient<ISchoolRepository<Teacher>, TeacherRepository>();


            services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options => options.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyMethod());
            });

            

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);


            services.AddDbContext<ApplicationDbContext>(options =>
            options.UseSqlServer(
                Configuration.GetConnectionString("DefaultConnection")));



            services.AddDefaultIdentity<IdentityUser>()
                .AddDefaultUI(UIFramework.Bootstrap4)
                .AddEntityFrameworkStores<ApplicationDbContext>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();


            app.UseCors(options => options.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader());
        }
    }
}
