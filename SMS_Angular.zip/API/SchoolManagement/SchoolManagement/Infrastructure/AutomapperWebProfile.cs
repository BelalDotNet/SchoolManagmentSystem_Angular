﻿using AutoMapper;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Infrastructure
{
    public class AutomapperWebProfile:AutoMapper.Profile
    {
        
        public AutomapperWebProfile()
        {
            CreateMap<ApplicationUser, UserStudentVM>().ReverseMap();
            CreateMap<Parent, UserStudentVM>().ReverseMap();
        }
    }
}