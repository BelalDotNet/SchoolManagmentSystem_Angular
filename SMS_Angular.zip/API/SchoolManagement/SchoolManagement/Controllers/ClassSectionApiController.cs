﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/ClassSectionApi")]
    public class ClassSectionApiController : ApiController
    {
        private ISchoolRepository<ClassSection> _repository;
        private ClassSectionRepository r;
        public ClassSectionApiController(ISchoolRepository<ClassSection> repo, ClassSectionRepository repository)
        {
            _repository = repo;
            r = repository;
        }



        [HttpGet]
        [Route("GetAllClasses")]
        public IHttpActionResult GetAllClasses()
        {
            var cls = r.GetAllClasses();
            return Ok(cls);
        }


        [HttpGet]
        [Route("GetAllSectionsForSpecificClass/{id}")]
        public IHttpActionResult GetAllSectionsForSpecificClass(int id) {
            var s = r.GetAllSectionsForSpecificClass(id);
            return Ok(s);
        }


        [HttpGet]
        [Route("GetAllSectionsForSpecificClassIU/{id}")]
        public IHttpActionResult GetAllSectionsForSpecificClassIU(int id)
        {
            var s = r.GetAllSectionsForSpecificClassIU(id);
            return Ok(s);
        }

        [HttpGet]
        [Route("GetClassSection")]
        public async Task<IHttpActionResult> Get()
        {
            var cls = await _repository.Get();
            return Ok(cls);
        }

        [HttpGet]
        [Route("GetClassSectionById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var cls = await _repository.Get(id);
            return Ok(cls);
        }


        [HttpPost]
        [Route("AssignClass")]
        public async Task<IHttpActionResult> Post(ClassSection cls)
        {
            await _repository.Post(cls);
            return Ok(cls);
        }

        [HttpPut]
        [Route("UpdateClassSection")]
        public async Task<IHttpActionResult> Put(ClassSection cls)
        {

            await _repository.Put(cls);
            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpDelete]
        [Route("DeleteClassSectionById/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
