﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/GradeApi")]

    public class GradeApiController : ApiController
    {
        private ISchoolRepository<Grade> _repository;
        public GradeApiController(ISchoolRepository<Grade> repo)
        {
            _repository = repo;
        }


        [HttpGet]
        [Route("GetGrades")]

        public async Task<IHttpActionResult> Get()
        {
            var grades = await _repository.Get();
            return Ok(grades);
        }

        [HttpGet]
        [Route("GetGradebyId/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var grade = await _repository.Get(id);
            return Ok(grade);
        }


        [HttpPost]
        [Route("InsertGrade")]

        public async Task<IHttpActionResult> Post(Grade grade)
        {
            await _repository.Post(grade);
            return Ok(grade);
        }

        [HttpPut]
        [Route("UpdateGrade")]

        public async Task<IHttpActionResult> Put(Grade grade)
        {

            await _repository.Put(grade);
            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpDelete]
        [Route("DeleteGradeById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
