﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/StudentApi")]
    public class StudentApiController : ApiController
    {
        ISchoolRepository<Student> _repository;
        StudentRepository r;
        ApplicationDbContext ctx;
       
        public StudentApiController(ISchoolRepository<Student> repo, StudentRepository studentRepository)
        {
            _repository = repo;
            r = studentRepository;
        }


        [HttpGet]
        [Route("GetStudents")]
        public async Task<IHttpActionResult> Get()
        {
            var sec = await _repository.Get();
            return Ok(sec);
        }

        [HttpGet]
        [Route("GetClasses")]
        public IHttpActionResult GetClasses()
        {
            var c = r.GetClasses();
            return Ok(c);
        }


        [HttpGet]
        [Route("GetParents")]
        public IHttpActionResult GetParents()
        {
            var c = r.GetParents();
            return Ok(c);
        }


        [HttpGet]
        [Route("GetSections/{classid}")]
        public IHttpActionResult GetSections(int classid)
        {
            var cs = r.GetSections(classid);
            return Ok(cs);
        }

        [HttpGet]
        [Route("GetDataForEdit/{id}")]
        public IHttpActionResult GetDataForEdit(int id)
        {
            var s = r.GetDataForEdit(id);
            return Ok(s);
        }

        [HttpGet]
        [Route("GetStudent")]
        public IHttpActionResult GetStudent()
        {
            var st = r.GetStudent();
            return Ok(st);
        }


        [HttpGet]
        [Route("GetStudentForClass/{id}")]
        public IHttpActionResult GetStudentForClass(int id)
        {
            var st = r.GetStudentForClass(id);
            return Ok(st);
        }

        [HttpGet]
        [Route("GetStudentForSpecificClass/{id}/{secid}")]
        public IHttpActionResult GetStudentForSpecificClass(int id, int secid)
        {
            var st = r.GetStudentForSpecificClass(id, secid);
            return Ok(st);
        }

       



        [HttpGet]
        [Route("GetStudentById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("UploadImage")]
        public HttpResponseMessage UploadImage()
        {
            string imageName = null;
            var httpRequest = HttpContext.Current.Request;
            //Upload Image
            var postedFile = httpRequest.Files["Image"];
            //Create custom filename
            imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(2).ToArray()).Replace(" ", "-");
            imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
            var filePath = HttpContext.Current.Server.MapPath("~/Image/" + imageName);
            postedFile.SaveAs(filePath);

            //Save to DB
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                Upload upload = new Upload()
                {
                    Caption = httpRequest["Caption"],
                    ImageName = imageName
                };
                db.Uploads.Add(upload);
                db.SaveChanges();
            }
            return Request.CreateResponse(HttpStatusCode.Created);
        }


        [HttpPost]
        [Route("InsertStudent")]
        public IHttpActionResult InsertStudent(UserStudentVM model)
        {
            try
            {
                r.InsertStudent(model);
                return Ok();
            }
            catch (Exception)
            {
                throw;
            }
        }



        [HttpPut]
        [Route("UpdateStudent")]
        public async Task<IHttpActionResult> Put(Student student)
        {
            await _repository.Put(student);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteStudent/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
