﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/ParentApi")]
    public class ParentApiController : ApiController
    {
        ISchoolRepository<Parent> _repository;
        ParentRepository r;
        public ParentApiController(ISchoolRepository<Parent> repo, ParentRepository parentRepository)
        {
            _repository = repo;
            r = parentRepository;
        }


        [HttpGet]
        [Route("GetParents")]
        public async Task<IHttpActionResult> Get()
        {
            var parents = await _repository.Get();
            return Ok(parents);
        }

        [HttpGet]
        [Route("GetParentsIdAndName")]
        public IHttpActionResult GetParentsIdAndName()
        {
            var parents = r.GetParentsIdAndName();
            return Ok(parents);
        }

        [HttpGet]
        [Route("GetParentById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("InsertParent")]
        public async Task<IHttpActionResult> Post(Parent parent)
        {
            await _repository.Post(parent);
            return Ok(parent);
        }

        [HttpPut]
        [Route("UpdateParent")]
        public async Task<IHttpActionResult> Put(Parent parent)
        {
            await _repository.Put(parent);
            return Ok(parent);

        }

        [HttpDelete]
        [Route("DeleteParent/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
