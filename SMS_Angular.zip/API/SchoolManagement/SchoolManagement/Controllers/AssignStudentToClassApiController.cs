﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/AssignStudentToClassApi")]

    public class AssignStudentToClassApiController : ApiController
    {
        ISchoolRepository<AssignStudentToClass> _repository;
        private AssignStudentToClassRepository r;
        public AssignStudentToClassApiController(ISchoolRepository<AssignStudentToClass> repo, AssignStudentToClassRepository repository)
        {
            _repository = repo;
            r = repository;
        }


        [HttpGet]
        [Route("GetStudents")]
        public IHttpActionResult GetStudents()
        {
            var sec = r.GetStudents();
            return Ok(sec);
        }


        [HttpGet]
        [Route("GetClasses")]
        public IHttpActionResult GetClasses()
        {
            var c = r.GetClasses();
            return Ok(c);
        }


        [HttpGet]
        [Route("GetSections/{classid}")]
        public IHttpActionResult GetSections(int classid)
        {
            var cs = r.GetSections(classid);
            return Ok(cs);
        }


        [HttpGet]
        [Route("GetClassSectionID/{classID}/{sectionID}")]
        public IHttpActionResult GetClassSectionID(int classID, int sectionID)
        {
            var sc = r.GetClassSectionID(classID, sectionID);
            return Ok(sc);
        }

        [HttpGet]
        [Route("GetAssignStudentToClasses")]
        public async Task<IHttpActionResult> Get()
        {
            var sec = await _repository.Get();
            return Ok(sec);
        }

        [HttpGet]
        [Route("GetAssignStudentToClassById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("AssignStudent")]

        public async Task<IHttpActionResult> Post(AssignStudentToClass student)
        {
            await _repository.Post(student);
            return Ok(student);
        }

        [HttpPut]
        [Route("UpdateAssignStudent")]

        public async Task<IHttpActionResult> Put(AssignStudentToClass student)
        {
            await _repository.Put(student);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteAssignStudentToClass/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
