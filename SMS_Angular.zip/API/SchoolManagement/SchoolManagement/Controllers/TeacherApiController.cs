﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/TeacherApi")]

    public class TeacherApiController : ApiController
    {
        ISchoolRepository<Teacher> _repository;
        TeacherRepository r;
        public TeacherApiController(ISchoolRepository<Teacher> repo, TeacherRepository repository)
        {
            _repository = repo;
            r = repository;
        }


        [HttpGet]
        [Route("GetTeachers")]
        public IHttpActionResult GetTeachers()
        {
            var teachers = r.GetTeachers();
            return Ok(teachers);
        }




        [HttpGet]
        [Route("GetOnlyTeachers")]

        public async Task<IHttpActionResult> Get()
        {
            var teachers = await _repository.Get();
            return Ok(teachers);
        }




        [HttpGet]
        [Route("GetDataForEdit/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("Insert")]

        public async Task<IHttpActionResult> Post(Teacher teacher)
        {
            await _repository.Post(teacher);
            return Ok(teacher);
        }


        

        [HttpPost]
        [Route("InsertTeacher")]
        public IHttpActionResult InsertTeacher(UserTeacherVM model)
        {
            try
            {
                r.InsertTeacher(model);
                return Ok();
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPut]
        [Route("UpdateTeacher")]

        public async Task<IHttpActionResult> Put(Teacher teacher)
        {
            await _repository.Put(teacher);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteTeacher/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
