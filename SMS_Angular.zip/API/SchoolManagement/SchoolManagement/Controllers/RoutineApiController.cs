﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/RoutineApi")]

    public class RoutineApiController : ApiController
    {
        private ISchoolRepository<Routine> _repository;
        public RoutineApiController(ISchoolRepository<Routine> repo)
        {
            _repository = repo;
        }


        [HttpGet]
        [Route("GetRoutines")]

        public async Task<IHttpActionResult> Get()
        {
            var routines = await _repository.Get();
            return Ok(routines);
        }

        [HttpGet]
        [Route("GetRoutineById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var routine = await _repository.Get(id);
            return Ok(routine);
        }


        [HttpPost]
        [Route("InsertRoutine")]

        public async Task<IHttpActionResult> Post(Routine routine)
        {
            await _repository.Post(routine);
            return Ok(routine);
        }

        [HttpPut]
        [Route("UpdateRoutine")]

        public async Task<IHttpActionResult> Put(Routine routine)
        {

            await _repository.Put(routine);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteRoutineById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
