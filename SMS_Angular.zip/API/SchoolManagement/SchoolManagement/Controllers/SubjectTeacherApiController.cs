﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/SubjectTeacherApi")]

    public class SubjectTeacherApiController : ApiController
    {
        private ISchoolRepository<SubjectTeacher> _repository;
        public SubjectTeacherApiController(ISchoolRepository<SubjectTeacher> repo)
        {
            _repository = repo;
        }


        [HttpGet]
        [Route("GetSubjectTeacher")]

        public async Task<IHttpActionResult> Get()
        {
            var subjects = await _repository.Get();
            return Ok(subjects);
        }

        [HttpGet]
    [Route("GetSubjectTeacherById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var subject = await _repository.Get(id);
            return Ok(subject);
        }


        [HttpPost]
        [Route("InsertSubjectTeacher")]

        public async Task<IHttpActionResult> Post(SubjectTeacher subject)
        {
            await _repository.Post(subject);
            return Ok(subject);
        }

        [HttpPut]
        [Route("UpdateSubjectTeacher")]

        public async Task<IHttpActionResult> Put(SubjectTeacher subject)
        {
            await _repository.Put(subject);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteSubjectTeacherById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
