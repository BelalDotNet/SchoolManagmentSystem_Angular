﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/ClassApi")]
    public class ClassApiController : ApiController
    {
        private ISchoolRepository<SClass> _repository;

        ClassRepository r;
        public ClassApiController(ISchoolRepository<SClass> repo, ClassRepository repository)
        {
            _repository = repo;
            r = repository;
        }


        [HttpGet]
        [Route("GetClasses")]
        public async Task<IHttpActionResult> Get()
        {
            var cls = await _repository.Get();
            return Ok(cls);
        }

        [HttpGet]
        [Route("GetClassIdAndName")]
        public IHttpActionResult GetClassIdAndName()
        {
            var classes = r.GetClassIdAndName();
            return Ok(classes);
        }

        [HttpGet]
        [Route("GetClassById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var sClass = await _repository.Get(id);
            return Ok(sClass);
        }


        [HttpPost]
        [Route("InsertClass")]
        public async Task<IHttpActionResult> Post(SClass cls)
        {
            await _repository.Post(cls);
            return Ok(cls);
        }

        [HttpPut]
        [Route("UpdateClass")]
        public async Task<IHttpActionResult> Put(SClass cls)
        {
            
            await _repository.Put(cls);
            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpDelete]
        [Route("DeleteClass/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
