﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/NoticeApi")]

    public class NoticeApiController : ApiController
    {
        ISchoolRepository<Notice> _repository;
        public NoticeApiController(ISchoolRepository<Notice> repo)
        {
            _repository = repo;
        }


        [HttpGet]
        [Route("GetNotices")]

        public async Task<IHttpActionResult> Get()
        {
            var notices = await _repository.Get();
            return Ok(notices);
        }

        [HttpGet]
        [Route("GetNoticeById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("InsertNotice")]

        public async Task<IHttpActionResult> Post(Notice notice)
        {
            await _repository.Post(notice);
            return Ok(notice);
        }

        [HttpPut]
        [Route("UpdateNotice")]

        public async Task<IHttpActionResult> Put(Notice notice)
        {
            await _repository.Put(notice);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteNoticeById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
