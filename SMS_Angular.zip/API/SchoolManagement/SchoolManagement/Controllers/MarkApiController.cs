﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using static SchoolManagement.DAL.MarkRepository;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/MarkApi")]

    public class MarkApiController : ApiController
    {
        private ISchoolRepository<Mark> _repository;
        private MarkRepository mark;
        public MarkApiController(ISchoolRepository<Mark> repo, MarkRepository _mark)
        {
            _repository = repo;
            mark = _mark;
        }

        [HttpGet]
        [Route("GetClassSectionID/{classID}/{sectionID}")]
        public IHttpActionResult GetClassSectionID(int classID, int sectionID)
        {
            var sc = mark.GetClassSectionID(classID, sectionID);
            return Ok(sc);
        }

        [HttpGet]
        [Route("GetAssignStudentID/{studentID}/{year}/{classSectionID}")]
        public IHttpActionResult GetAssignStudentID(int studentID, string year, int classSectionID)
        {
            var assStu = mark.GetAssignStudentID(studentID, year, classSectionID);
            return Ok(assStu);
        }


        [HttpGet]
        [Route("GetMarks")]

        public async Task<IHttpActionResult> Get()
        {
            var marks = await _repository.Get();
            return Ok(marks);
        }

        [HttpGet]
        [Route("GetMarkById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var mark = await _repository.Get(id);
            return Ok(mark);
        }

        [HttpGet]
        [Route("GetInfoOfSpecificRoll")]

        public IHttpActionResult GetInfoOfSpecificRoll(MarkEdit model)
        {
            var info = mark.GetMarkByStudentRoll(model);
            return Ok(info);
        }



        [HttpPost]
        [Route("InsertMark")]
        public IHttpActionResult PostMark(List<Mark> marks)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext db = new ApplicationDbContext())
                {
                    db.Marks.AddRange(marks);
                    db.SaveChanges();

                }
            }

            return Ok();
        }

        //public async Task<IHttpActionResult> Post(Mark mark)
        //{
        //    await _repository.Post(mark);
        //    return Ok(mark);
        //}

        [HttpPut]
        [Route("UpdateMark")]

        public async Task<IHttpActionResult> Put(Mark mark)
        {

            await _repository.Put(mark);
            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpDelete]
        [Route("DeleteMarkById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }

        [HttpGet]
        [Route("GetExams")]
        public IHttpActionResult GetExams()
        {
            var c = mark.GetExams();
            return Ok(c);
        }



        [HttpGet]
        [Route("GetClasses")]
        public IHttpActionResult GetClasses()
        {
            var c = mark.GetClasses();
            return Ok(c);
        }

        [HttpGet]
        [Route("GetSections/{classid}")]
        public IHttpActionResult GetSections(int classid)
        {
            var cs = mark.GetSections(classid);
            return Ok(cs);
        }

        [HttpGet]
        [Route("GetSubjects/{classid}")]

        public IHttpActionResult GetSubject(int classid)
        {
            var cs = mark.GetSubject(classid);
            return Ok(cs);
        }

        [HttpGet]
        [Route("GetStudentToInsertMark/{classID}/{sectionID}")]
        public IHttpActionResult GetStudentToInsertMark(int classID, int sectionID)
        {
            var cs = mark.GetStudentToInsertMark(classID, sectionID);
            return Ok(cs);
        }
    }
}
