﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/ClerkApi")]
    public class ClerkApiController : ApiController
    {
        private ISchoolRepository<Clerk> _repository;
        ClerkRepository r;
        public ClerkApiController(ISchoolRepository<Clerk> repo, ClerkRepository repository)
        {
            _repository = repo;
            r = repository;
        }


        [HttpGet]
        [Route("GetClerks")]
        public IHttpActionResult GetClerks()
        {
            var clrk = r.GetAllClerks();
            return Ok(clrk);
        }

        public async Task<IHttpActionResult> Get()
        {
            await _repository.Get();
            return Ok();
        }

        [HttpGet]
        [Route("GetClerkById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var clrk = await _repository.Get(id);
            return Ok(clrk);
        }



        [HttpPost]
        [Route("InsertClerk")]
        public IHttpActionResult InsertClerk(UserClerkVM model)
        {
            try
            {
                r.InsertClerk(model);
                return Ok();
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]

        public async Task<IHttpActionResult> Post(Clerk entity)
        {
            await _repository.Post(entity);
            return Ok(entity);
        }

        [HttpPut]
        [Route("UpdateClerk")]
        public async Task<IHttpActionResult> Put(Clerk entity)
        {

            await _repository.Put(entity);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteClerk/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
