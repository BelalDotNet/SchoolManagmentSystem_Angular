﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/ExamApi")]

    public class ExamApiController : ApiController
    {
        private ISchoolRepository<Exam> _repository;
        public ExamApiController(ISchoolRepository<Exam> repo)
        {
            _repository = repo;
        }


        [HttpGet]
        [Route("GetExams")]

        public async Task<IHttpActionResult> Get()
        {
            var exams = await _repository.Get();
            return Ok(exams);
        }

        [HttpGet]
        [Route("GetExamById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var exam = await _repository.Get(id);
            return Ok(exam);
        }


        [HttpPost]
        [Route("InsertExam")]

        public async Task<IHttpActionResult> Post(Exam exam)
        {
            await _repository.Post(exam);
            return Ok(exam);
        }

        [HttpPut]
        [Route("UpdateExam")]

        public async Task<IHttpActionResult> Put(Exam exam)
        {

            await _repository.Put(exam);
            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpDelete]
        [Route("DeleteExamById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
