﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/SectionApi")]
    public class SectionApiController : ApiController
    {
        ISchoolRepository<Section> _repository;
        SectionRepository r;
        public SectionApiController(ISchoolRepository<Section> repo, SectionRepository sectionRepository)
        {
            _repository = repo;
            r = sectionRepository;
        }


        [HttpGet]
        [Route("GetSections")]
        public async Task<IHttpActionResult> Get()
        {
            var sections = await _repository.Get();
            return Ok(sections);
        }

        //[HttpGet]
        //[Route("GetSectionForAllClass")]
        //public IHttpActionResult GetSectionForAllClass()
        //{
        //    var sections = r.GetSectionForAllClass();
        //    return Ok(sections);
        //}


        [HttpGet]
        [Route("GetSectionForSpecificClass/{id}")]
        public IHttpActionResult GetSectionForSpecificClass(int id)
        {
            var sections = r.GetSectionForSpecificClass(id);
            return Ok(sections);
        }

        [HttpGet]
        [Route("GetSectionById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("InsertSection")]

        public async Task<IHttpActionResult> Post(Section section)
        {
            await _repository.Post(section);
            return Ok(section);
        }

        [HttpPut]
        [Route("UpdateSection")]

        public async Task<IHttpActionResult> Put(Section section)
        {
            await _repository.Put(section);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteSection/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
