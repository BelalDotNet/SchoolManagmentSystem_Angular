﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/SubjectApi")]

    public class SubjectApiController : ApiController
    {
        private ISchoolRepository<Subject> _repository;
        public SubjectApiController(ISchoolRepository<Subject> repo)
        {
            _repository = repo;
        }

                                                
        [HttpGet]
        [Route("GetSubjects")]

        public async Task<IHttpActionResult> Get()
        {
            var subjects = await _repository.Get();
            return Ok(subjects);
        }

        [HttpGet]
        [Route("GetSubjectById/{id}")]

        public async Task<IHttpActionResult> Get(int id)
        {
            var subject = await _repository.Get(id);
            return Ok(subject);
        }


        [HttpPost]
         [Route("InsertSubject")]

        public async Task<IHttpActionResult> Post(Subject subject)
        {
            await _repository.Post(subject);
            return Ok(subject);
        }

        [HttpPut]
    [Route("UpdateSubject")]

        public async Task<IHttpActionResult> Put(Subject subject)
        {

            await _repository.Put(subject);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteSubjectById/{id}")]

        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
