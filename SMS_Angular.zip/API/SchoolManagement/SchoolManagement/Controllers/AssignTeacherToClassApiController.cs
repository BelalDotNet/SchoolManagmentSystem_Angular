﻿using SchoolManagement.DAL;
using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace SchoolManagement.Controllers
{
    [RoutePrefix("api/AssignTeacherToClassApi")]

    public class AssignTeacherToClassApiController : ApiController
    {
        ISchoolRepository<AssignTeacherToClass> _repository;
        AssignTeacherToClassRepository r;
        public AssignTeacherToClassApiController(ISchoolRepository<AssignTeacherToClass> repo, AssignTeacherToClassRepository repository)
        {
            _repository = repo;
            r = repository;
        }



        [HttpGet]
        [Route("GetClasses")]
        public IHttpActionResult GetClasses()
        {
            var c = r.GetClasses();
            return Ok(c);
        }


        [HttpGet]
        [Route("GetSections/{classid}")]
        public IHttpActionResult GetSections(int classid)
        {
            var cs = r.GetSections(classid);
            return Ok(cs);
        }



        [HttpGet]
        [Route("GetClassSectionID/{classID}/{sectionID}")]
        public IHttpActionResult GetClassSectionID(int classID, int sectionID)
        {
            var sc = r.GetClassSectionID(classID, sectionID);
            return Ok(sc);
        }



        [HttpGet]
        [Route("GetTeachers/{id}")]
        public IHttpActionResult GetTeachers(int id)
        {
            var s = r.GetTeachers(id);
            return Ok(s);
        }


        [HttpGet]
        [Route("GetAssignTeacherToClass")]
        public async Task<IHttpActionResult> Get()
        {
            var teachers = await _repository.Get();
            return Ok(teachers);
        }

        [HttpGet]
        [Route("GetAssignTeacherToClassById/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            return Ok(await _repository.Get(id));
        }


        [HttpPost]
        [Route("AssignTeacher")]
        public async Task<IHttpActionResult> Post(AssignTeacherToClass teacher)
        {
            await _repository.Post(teacher);
            return Ok(teacher);
        }

        [HttpPut]
        [Route("UpdateAssignTeacher")]
        public async Task<IHttpActionResult> Put(AssignTeacherToClass teacher)
        {
            await _repository.Put(teacher);
            return Ok();

        }

        [HttpDelete]
        [Route("DeleteAssignTeacherToClassById/{id}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();

        }
    }
}
