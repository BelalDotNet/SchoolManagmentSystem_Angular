﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class MarkRepository:ISchoolRepository<Mark>
    {
        ApplicationDbContext ctx;
        public MarkRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var mark = ctx.Marks.Find(id);
            if (mark != null)
            {
                ctx.Marks.Remove(mark);
                await ctx.SaveChangesAsync();
            }
            return null;
        }

        public int GetClassSectionID(int classID, int sectionID)
        {
            return (from cs in ctx.ClassSections
                    where cs.SClassID == classID && cs.SectionID == sectionID
                    select cs.ClassSectionID
                 ).Single();
        }


        public int GetAssignStudentID(int studentID, string year, int classSectionID)
        {
            return (from assStu in ctx.AssignStudentToClasses
                    where assStu.StudentID == studentID && assStu.SessionYear == year && assStu.ClassSectionID == classSectionID
                    select assStu.ID).Single();
        }


        public async Task<IEnumerable<Mark>> Get()
        {
            return await ctx.Marks.ToListAsync();
        }

        public async Task<Mark> Get(int id)
        {
            return await ctx.Marks.FindAsync(id);
        }







        public async Task<object> Post(Mark entity)
        {
            ctx.Marks.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(Mark entity)
        {
            try
            {
                Mark mark = new Mark();
                mark = ctx.Marks.Find(entity.MarkID);
                if (mark != null)
                {
                    mark.ExamID = entity.ExamID;
                    mark.PassingYear = entity.PassingYear;
                    mark.ObtainedMark = entity.ObtainedMark;
                    mark.SubjectMark = entity.SubjectMark;
                    mark.GradeID = entity.GradeID;
                    mark.EntryBy = entity.EntryBy;
                    mark.EntryDate = entity.EntryDate;
                    ctx.Entry(mark).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }
            
            return entity;
        }

        public IEnumerable<object> GetExams()
        {
            return (from e in ctx.Exams
                select new { e.ExamID, e.ExamName }).ToList();
        }

        public IEnumerable<object> GetClasses()
        {
            return (from c in ctx.SClasses
                select new { c.ClassName, c.SClassID }).ToList();
        }

        public IEnumerable<object> GetSections(int classid)
        {
            return (from c in ctx.SClasses
                join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                where c.SClassID == classid
                select new { c.SClassID, c.ClassName, s.SectionID, s.SectionName }).ToList();
        }

        public IEnumerable<object> GetSubject(int classid)
        {
            return (from c in ctx.SClasses
                join sub in ctx.Subjects
                    on c.ClassName equals sub.ClassName
                where c.SClassID == classid
                select new { c.SClassID, c.ClassName, sub.SubjectID, sub.SubjectName }).ToList();
        }


        public IEnumerable<object> GetStudentToInsertMark(int classID, int sectionID)
        {
            return (from c in ctx.SClasses
                join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                join asc in ctx.AssignStudentToClasses
                    on cs.ClassSectionID equals asc.ClassSectionID
                join st in ctx.Students
                    on asc.StudentID equals st.StudentID
                join pr in ctx.Parents
                    on st.ParentID equals pr.ParentID
                join u in ctx.Users
                    on st.ApplicationUserID equals u.Id
                where st.ApplicationUserID == u.Id
                where c.SClassID == classID && s.SectionID == sectionID
                where cs.SClassID == c.SClassID
                where cs.SectionID == s.SectionID
                select new { st.StudentID, st.StudentRegID, st.Name, s.SectionName, st.Gender, st.DOB, st.NID, pr.ParentName, u.Email, u.PhoneNumber, asc.RollNo}).ToList();
        }

        public IEnumerable<object> GetMarkByStudentRoll(MarkEdit model)
        {
            return (
                from m in ctx.Marks
                join e in ctx.Exams
                    on m.ExamID equals e.ExamID
                join a in ctx.AssignStudentToClasses
                    on m.AssignStudentToClassID equals a.ID
                join s in ctx.Students
                    on a.StudentID equals s.StudentID
                join cs in ctx.ClassSections
                    on a.ClassSectionID equals cs.ClassSectionID
                join c in ctx.SClasses
                    on cs.SClassID equals c.SClassID
                join sec in ctx.Sections
                    on cs.SectionID equals sec.SectionID
                where e.ExamID == model.ExamId
                where c.SClassID == model.ClassId
                where sec.SectionID == model.SectionId
                where a.SessionYear == model.Year
                where a.RollNo == model.Roll

                select new { e.ExamName, s.Name, c.ClassName, sec.SectionName, a.RollNo, a.SessionYear }
            ).Include(a => a.ExamName);

        }

        public class MarkEdit
        {
            public int ExamId { get; set; }
            public int ClassId { get; set; }
            public int SectionId { get; set; }
            public string Year { get; set; }
            public int Roll { get; set; }

        }

    }
}