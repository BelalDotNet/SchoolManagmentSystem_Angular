﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class SubjectTeacherRepository:ISchoolRepository<SubjectTeacher>
    {
        ApplicationDbContext ctx;
        public SubjectTeacherRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var subTcr = ctx.SubjectTeachers.Find(id);
            if (subTcr != null)
            {
                ctx.SubjectTeachers.Remove(subTcr);
                await ctx.SaveChangesAsync();
            }
            return null;
        }





        public async Task<IEnumerable<SubjectTeacher>> Get()
        {
            return await ctx.SubjectTeachers.ToListAsync();
        }

        public async Task<SubjectTeacher> Get(int id)
        {
            return await ctx.SubjectTeachers.FindAsync(id);
        }







        public async Task<object> Post(SubjectTeacher entity)
        {
            ctx.SubjectTeachers.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(SubjectTeacher entity)
        {
            try
            {
                SubjectTeacher subject = new SubjectTeacher();
                subject = ctx.SubjectTeachers.Find(entity.ID);
                if (subject != null)
                {
                    subject.SubjectID = entity.SubjectID;
                    subject.TeacherID = entity.TeacherID;
                    ctx.Entry(subject).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            
            return entity;
        }
    }
}