﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class NoticeRepository:ISchoolRepository<Notice>
    {
        ApplicationDbContext ctx;
        public NoticeRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }





        public async Task<IEnumerable<Notice>> Get()
        {
            return await ctx.Notices.ToListAsync();
        }

        public async Task<Notice> Get(int id)
        {
            return await ctx.Notices.FindAsync(id);
        }






        public async Task<object> Post(Notice entity)
        {
            ctx.Notices.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }






        public async Task<object> Put(Notice entity)
        {
            try
            {
                Notice notice = new Notice();
                notice = ctx.Notices.Find(entity.NoticeID);
                if (notice != null)
                {
                    notice.Title = entity.Title;
                    notice.Date = entity.Date;
                    notice.ImagePath = entity.ImagePath;
                    notice.FileLink = entity.FileLink;
                    notice.IsDisplay = entity.IsDisplay;
                    notice.CreatedBy = entity.CreatedBy;

                    ctx.Entry(notice).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();

            }
            catch (Exception)
            {

                throw;
            }
            
            return entity;
        }



        public async Task<object> Delete(int id)
        {
            var notice = ctx.Notices.Find(id);
            if (notice != null)
            {
                ctx.Notices.Remove(notice);
                await ctx.SaveChangesAsync();
            }
            return null;

        }
    }
}