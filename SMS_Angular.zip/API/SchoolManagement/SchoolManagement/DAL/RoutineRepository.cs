﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class RoutineRepository:ISchoolRepository<Routine>
    {
        ApplicationDbContext ctx;
        public RoutineRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var routine = ctx.Routines.Find(id);
            if (routine != null)
            {
                ctx.Routines.Remove(routine);
                await ctx.SaveChangesAsync();
            }
            return null;
        }





        public async Task<IEnumerable<Routine>> Get()
        {
            return await ctx.Routines.ToListAsync();
        }

        public async Task<Routine> Get(int id)
        {
            return await ctx.Routines.FindAsync(id);
        }







        public async Task<object> Post(Routine entity)
        {
            ctx.Routines.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(Routine entity)
        {
            try
            {
                Routine routine = new Routine();
                routine = ctx.Routines.Find(entity.RoutineID);
                if (routine != null)
                {
                    routine.ClassSectionID = entity.ClassSectionID;
                    routine.SubjectTeacherID = entity.SubjectTeacherID;
                    routine.Day = entity.Day;
                    routine.StartTime = entity.StartTime;
                    routine.EndTime = entity.EndTime;
                    routine.CreatedBy = entity.CreatedBy;
                    routine.IsActive = entity.IsActive;


                    ctx.Entry(routine).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();

            }
            catch (Exception)
            {

                throw;
            }
           
            return entity;
        }
    }
}