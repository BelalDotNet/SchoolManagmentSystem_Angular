﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class AssignTeacherToClassRepository:ISchoolRepository<AssignTeacherToClass>
    {
        ApplicationDbContext context;
        public AssignTeacherToClassRepository(ApplicationDbContext dbContext)
        {
            context = dbContext;
        }


        public IEnumerable<object> GetClasses()
        {
            return (from c in context.SClasses
                    select new { c.ClassName, c.SClassID }).ToList();
        }



        public IEnumerable<object> GetSections(int classid)
        {
            return (from c in context.SClasses
                    join cs in context.ClassSections
                    on c.SClassID equals cs.SClassID
                    join s in context.Sections
                    on cs.SectionID equals s.SectionID
                    where c.SClassID == classid
                    select new { c.SClassID, c.ClassName, s.SectionID, s.SectionName }).ToList();
        }


        public int GetClassSectionID(int classID, int sectionID)
        {
            return (from cs in context.ClassSections
                    where cs.SClassID == classID && cs.SectionID == sectionID
                    select cs.ClassSectionID
                 ).Single();
        }


        public IEnumerable<object>GetTeachers(int classSectionID)
        {
            return (from teacher in context.Teachers select teacher).Except(from cls in context.SClasses
                                                                            join clsec in context.ClassSections
                                                                            on cls.SClassID equals clsec.SClassID
                                                                            join sec in context.Sections
                                                                            on clsec.SectionID equals sec.SectionID
                                                                            join atc in context.AssignTeacherToClasses
                                                                            on clsec.ClassSectionID equals atc.ClassSectionID
                                                                            join tr in context.Teachers
                                                                            on atc.TeacherID equals tr.TeacherID
                                                                            where clsec.ClassSectionID == classSectionID
                                                                            select tr);
        }


        public async Task<IEnumerable<AssignTeacherToClass>> Get()
        {
            return await context.AssignTeacherToClasses.ToListAsync();
        }

        public async Task<AssignTeacherToClass> Get(int id)
        {
            return await context.AssignTeacherToClasses.FindAsync(id);
        }






        public async Task<object> Post(AssignTeacherToClass entity)
        {
            context.AssignTeacherToClasses.Add(entity);
            await context.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(AssignTeacherToClass entity)
        {
            try
            {
                AssignTeacherToClass teacher = new AssignTeacherToClass();
                teacher = context.AssignTeacherToClasses.Find(entity.ID);
                if (teacher != null)
                {
                    teacher.ClassSectionID = entity.ClassSectionID;
                    teacher.TeacherID = entity.TeacherID;
                    teacher.IsClassTeacher = entity.IsClassTeacher;
                    context.Entry(teacher).State = EntityState.Modified;
                }
                await context.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }
            
            return entity;
        }






        public async Task<object> Delete(int id)
        {
            var teacher = context.AssignTeacherToClasses.Find(id);
            if (teacher != null)
            {
                context.AssignTeacherToClasses.Remove(teacher);
                await context.SaveChangesAsync();
            }
            return null;
        }
    }
}