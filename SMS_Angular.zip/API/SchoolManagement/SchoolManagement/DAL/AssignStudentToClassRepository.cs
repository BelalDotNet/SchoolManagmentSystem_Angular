﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace SchoolManagement.DAL
{
    public class AssignStudentToClassRepository:ISchoolRepository<AssignStudentToClass>
    {
        ApplicationDbContext ctx;
        public AssignStudentToClassRepository(ApplicationDbContext dbContext)
        {
            ctx = dbContext;
        }


        public IEnumerable<object> GetStudents()
        {
            return (from students in ctx.Students
                    select students).ToList();
        }


        public IEnumerable<object> GetClasses()
        {
            return (from c in ctx.SClasses
                    select new { c.ClassName, c.SClassID }).ToList();
        }


        public IEnumerable<object> GetSections(int classid)
        {
            return (from c in ctx.SClasses
                    join cs in ctx.ClassSections
                    on c.SClassID equals cs.SClassID
                    join s in ctx.Sections
                    on cs.SectionID equals s.SectionID
                    where c.SClassID == classid
                    select new { c.SClassID, c.ClassName, s.SectionID, s.SectionName }).ToList();
        }


        public int GetClassSectionID(int classID, int sectionID)
        {
            return (from cs in ctx.ClassSections
                    where cs.SClassID == classID && cs.SectionID == sectionID
                    select cs.ClassSectionID
                 ).Single();
        }

        public async Task<IEnumerable<AssignStudentToClass>> Get()
        {
            return await ctx.AssignStudentToClasses.ToListAsync();
        }

        public async Task<AssignStudentToClass> Get(int id)
        {
            return await ctx.AssignStudentToClasses.FindAsync(id);
        }





        public async Task<object> Post(AssignStudentToClass entity)
        {
            ctx.AssignStudentToClasses.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }






        public async Task<object> Put(AssignStudentToClass entity)
        {
            try
            {
                AssignStudentToClass student = new AssignStudentToClass();
                student = ctx.AssignStudentToClasses.Find(entity.ID);
                if (student != null)
                {
                    student.RollNo = entity.RollNo;
                    student.SessionYear = entity.SessionYear;
                    student.StudentID = entity.StudentID;
                    student.ClassSectionID = entity.ClassSectionID;
                    student.PresentStatus = entity.PresentStatus;
                }
                ctx.Entry(student).State = EntityState.Modified;
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }
            

            
            return entity;
        }





        public async Task<object> Delete(int id)
        {
            var student = ctx.AssignStudentToClasses.Find(id);
            if (student != null)
            {
                ctx.AssignStudentToClasses.Remove(student);
                await ctx.SaveChangesAsync();

            }
            return null;
        }
    }
}