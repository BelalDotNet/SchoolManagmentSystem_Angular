﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class ClerkRepository:ISchoolRepository<Clerk>
    {
        ApplicationDbContext ctx;
        public ClerkRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var clrk = ctx.Clerks.Find(id);
            if (clrk != null)
            {
                ctx.Clerks.Remove(clrk);
                await ctx.SaveChangesAsync();
            }
            return null;
        }


        public IEnumerable<object> GetAllClerks()
        {
            return (from c in ctx.Clerks
                    join u in ctx.Users
                    on c.ApplicationUserID equals u.Id
                    select new { c.Name, u.Email, u.PhoneNumber, c.NID, c.DOB, c.Gender, c.Image }).ToList();
        }


        public async Task<IEnumerable<Clerk>> Get()
        {
            return await ctx.Clerks.ToListAsync();
        }

        public async Task<Clerk> Get(int id)
        {
            return await ctx.Clerks.FindAsync(id);
        }


        public UserManager<ApplicationUser> userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));
        public void InsertClerk(UserClerkVM model)
        {
            var user = new ApplicationUser
            {
                Email = model.Email,
                PhoneNumber = model.PhoneNumber,
                UserName = model.Email
            };
            IdentityResult result = userManager.Create(user, model.Password);

            var clerk = new Clerk
            {
                Name = model.Name,
                NID = model.NID,
                DOB = model.DOB,
                Gender = model.Gender,
                Address = model.Address,
                ApplicationUserID = user.Id,
                Image = model.Image,
            };
            if (result.Succeeded)
            {
                try
                {
                    ctx.Clerks.Add(clerk);
                    ctx.SaveChanges();
                }
                catch (Exception)
                {

                    throw;
                }

            }
        }





        public async Task<object> Post(Clerk entity)
        {
            ctx.Clerks.Add(entity);
            await ctx.SaveChangesAsync();
            return entity;
        }





        public async Task<object> Put(Clerk entity)
        {
            try
            {
                Clerk clrk = new Clerk();
                clrk = ctx.Clerks.Find(entity.ClerkID);
                if (clrk != null)
                {
                    clrk.Name = entity.Name;
                    clrk.NID = entity.NID;
                    clrk.DOB = entity.DOB;
                    clrk.Gender = entity.Gender;
                    clrk.Address = entity.Address;
                    clrk.ApplicationUserID = entity.ApplicationUserID;
                    clrk.Image = entity.Image;

                    ctx.Entry(clrk).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }
            
            return entity;
        }
    }
}