﻿using SchoolManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SchoolManagement.DAL
{
    public class ExamRepository:ISchoolRepository<Exam>
    {
        ApplicationDbContext ctx;
        public ExamRepository(ApplicationDbContext context)
        {
            ctx = context;
        }




        public async Task<object> Delete(int id)
        {
            var exam = ctx.Exams.Find(id);
            if (exam != null)
            {
                ctx.Exams.Remove(exam);
                await ctx.SaveChangesAsync();
            }
            return null;
        }





        public async Task<IEnumerable<Exam>> Get()
        {
            return await ctx.Exams.ToListAsync();
        }

        public async Task<Exam> Get(int id)
        {
            return await ctx.Exams.FindAsync(id);
        }







        public async Task<object> Post(Exam entity)
        {
            ctx.Exams.Add(entity);
            await ctx.SaveChangesAsync();
            return null;
        }





        public async Task<object> Put(Exam entity)
        {
            try
            {
                Exam exam = new Exam();
                exam = ctx.Exams.Find(entity.ExamID);
                if (exam != null)
                {
                    exam.ExamName = entity.ExamName;
                    exam.Comment = entity.Comment;

                    ctx.Entry(exam).State = EntityState.Modified;
                }
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {

                throw;
            }
            
            return entity;
        }
    }
}