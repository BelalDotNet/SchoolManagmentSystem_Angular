namespace SchoolManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ArchivedStudents",
                c => new
                    {
                        ArchivedStudentID = c.Int(nullable: false, identity: true),
                        RollNo = c.Int(nullable: false),
                        SessionYear = c.String(),
                        StudentRegID = c.String(),
                        ClassName = c.String(),
                        SectionName = c.String(),
                    })
                .PrimaryKey(t => t.ArchivedStudentID);
            
            CreateTable(
                "dbo.AssignStudentToClasses",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        RollNo = c.Int(nullable: false),
                        SessionYear = c.String(),
                        StudentID = c.Int(),
                        ClassSectionID = c.Int(),
                        PresentStatus = c.String(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ClassSections", t => t.ClassSectionID)
                .ForeignKey("dbo.Students", t => t.StudentID)
                .Index(t => t.StudentID)
                .Index(t => t.ClassSectionID);
            
            CreateTable(
                "dbo.ClassSections",
                c => new
                    {
                        ClassSectionID = c.Int(nullable: false, identity: true),
                        SClassID = c.Int(nullable: false),
                        SectionID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ClassSectionID)
                .ForeignKey("dbo.SClasses", t => t.SClassID, cascadeDelete: true)
                .ForeignKey("dbo.Sections", t => t.SectionID, cascadeDelete: true)
                .Index(t => t.SClassID)
                .Index(t => t.SectionID);
            
            CreateTable(
                "dbo.AssignTeacherToClasses",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        ClassSectionID = c.Int(nullable: false),
                        TeacherID = c.Int(nullable: false),
                        IsClassTeacher = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ClassSections", t => t.ClassSectionID, cascadeDelete: true)
                .ForeignKey("dbo.Teachers", t => t.TeacherID, cascadeDelete: true)
                .Index(t => t.ClassSectionID)
                .Index(t => t.TeacherID);
            
            CreateTable(
                "dbo.Teachers",
                c => new
                    {
                        TeacherID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        NID = c.String(),
                        DOB = c.DateTime(nullable: false),
                        Gender = c.String(),
                        Address = c.String(),
                        ApplicationUserID = c.String(nullable: false, maxLength: 128),
                        Designation = c.String(nullable: false),
                        Image = c.String(),
                        IsActive = c.Boolean(),
                    })
                .PrimaryKey(t => t.TeacherID)
                .ForeignKey("dbo.AspNetUsers", t => t.ApplicationUserID, cascadeDelete: true)
                .Index(t => t.ApplicationUserID);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Clerks",
                c => new
                    {
                        ClerkID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        NID = c.String(),
                        DOB = c.DateTime(nullable: false),
                        Gender = c.String(),
                        Address = c.String(),
                        ApplicationUserID = c.String(maxLength: 128),
                        Image = c.String(),
                    })
                .PrimaryKey(t => t.ClerkID)
                .ForeignKey("dbo.AspNetUsers", t => t.ApplicationUserID)
                .Index(t => t.ApplicationUserID);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.Students",
                c => new
                    {
                        StudentID = c.Int(nullable: false, identity: true),
                        StudentRegID = c.String(),
                        Name = c.String(),
                        NID = c.String(),
                        DOB = c.DateTime(nullable: false),
                        Gender = c.String(),
                        Address = c.String(),
                        ApplicationUserID = c.String(maxLength: 128),
                        ParentID = c.Int(nullable: false),
                        Image = c.String(),
                        IsActive = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.StudentID)
                .ForeignKey("dbo.AspNetUsers", t => t.ApplicationUserID)
                .ForeignKey("dbo.Parents", t => t.ParentID, cascadeDelete: true)
                .Index(t => t.ApplicationUserID)
                .Index(t => t.ParentID);
            
            CreateTable(
                "dbo.Parents",
                c => new
                    {
                        ParentID = c.Int(nullable: false, identity: true),
                        ParentName = c.String(),
                        Profession = c.String(),
                        NID = c.String(),
                        IsActive = c.Boolean(),
                    })
                .PrimaryKey(t => t.ParentID);
            
            CreateTable(
                "dbo.SubjectTeachers",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        TeacherID = c.Int(nullable: false),
                        SubjectID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Subjects", t => t.SubjectID, cascadeDelete: true)
                .ForeignKey("dbo.Teachers", t => t.TeacherID, cascadeDelete: true)
                .Index(t => t.TeacherID)
                .Index(t => t.SubjectID);
            
            CreateTable(
                "dbo.Routines",
                c => new
                    {
                        RoutineID = c.Int(nullable: false, identity: true),
                        ClassSectionID = c.Int(nullable: false),
                        SubjectTeacherID = c.Int(nullable: false),
                        Day = c.String(nullable: false),
                        StartTime = c.String(),
                        EndTime = c.String(),
                        CreatedBy = c.String(),
                        IsActive = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.RoutineID)
                .ForeignKey("dbo.ClassSections", t => t.ClassSectionID, cascadeDelete: true)
                .ForeignKey("dbo.SubjectTeachers", t => t.SubjectTeacherID, cascadeDelete: true)
                .Index(t => t.ClassSectionID)
                .Index(t => t.SubjectTeacherID);
            
            CreateTable(
                "dbo.Subjects",
                c => new
                    {
                        SubjectID = c.Int(nullable: false, identity: true),
                        SubjectName = c.String(nullable: false),
                        ClassName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.SubjectID);
            
            CreateTable(
                "dbo.Marks",
                c => new
                    {
                        MarkID = c.Int(nullable: false, identity: true),
                        ClassSectionID = c.Int(nullable: false),
                        SubjectID = c.Int(nullable: false),
                        ExamID = c.Int(nullable: false),
                        PassingYear = c.String(),
                        AssignStudentToClassID = c.Int(nullable: false),
                        ObtainedMark = c.Decimal(nullable: false, precision: 18, scale: 2),
                        SubjectMark = c.Decimal(nullable: false, precision: 18, scale: 2),
                        GradeID = c.Int(nullable: false),
                        EntryBy = c.String(),
                        EntryDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.MarkID)
                .ForeignKey("dbo.AssignStudentToClasses", t => t.AssignStudentToClassID, cascadeDelete: true)
                .ForeignKey("dbo.ClassSections", t => t.ClassSectionID, cascadeDelete: true)
                .ForeignKey("dbo.Exams", t => t.ExamID, cascadeDelete: true)
                .ForeignKey("dbo.Grades", t => t.GradeID, cascadeDelete: true)
                .ForeignKey("dbo.Subjects", t => t.SubjectID, cascadeDelete: true)
                .Index(t => t.ClassSectionID)
                .Index(t => t.SubjectID)
                .Index(t => t.ExamID)
                .Index(t => t.AssignStudentToClassID)
                .Index(t => t.GradeID);
            
            CreateTable(
                "dbo.Exams",
                c => new
                    {
                        ExamID = c.Int(nullable: false, identity: true),
                        ExamName = c.String(),
                        Comment = c.String(),
                    })
                .PrimaryKey(t => t.ExamID);
            
            CreateTable(
                "dbo.Grades",
                c => new
                    {
                        GradeID = c.Int(nullable: false, identity: true),
                        GradeRange = c.String(),
                        GradePoint = c.Decimal(nullable: false, precision: 18, scale: 2),
                        GradeName = c.String(),
                        Comment = c.String(),
                    })
                .PrimaryKey(t => t.GradeID);
            
            CreateTable(
                "dbo.SClasses",
                c => new
                    {
                        SClassID = c.Int(nullable: false, identity: true),
                        ClassName = c.String(nullable: false),
                        ClassName_Numeric = c.String(nullable: false),
                        IsActive = c.Boolean(),
                    })
                .PrimaryKey(t => t.SClassID);
            
            CreateTable(
                "dbo.Sections",
                c => new
                    {
                        SectionID = c.Int(nullable: false, identity: true),
                        SectionName = c.String(nullable: false),
                        NickName = c.String(),
                        IsActive = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.SectionID);
            
            CreateTable(
                "dbo.Notices",
                c => new
                    {
                        NoticeID = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Date = c.DateTime(nullable: false),
                        ImagePath = c.String(),
                        FileLink = c.String(),
                        IsDisplay = c.Boolean(nullable: false),
                        CreatedBy = c.String(),
                    })
                .PrimaryKey(t => t.NoticeID);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.ClassSections", "SectionID", "dbo.Sections");
            DropForeignKey("dbo.ClassSections", "SClassID", "dbo.SClasses");
            DropForeignKey("dbo.SubjectTeachers", "TeacherID", "dbo.Teachers");
            DropForeignKey("dbo.SubjectTeachers", "SubjectID", "dbo.Subjects");
            DropForeignKey("dbo.Marks", "SubjectID", "dbo.Subjects");
            DropForeignKey("dbo.Marks", "GradeID", "dbo.Grades");
            DropForeignKey("dbo.Marks", "ExamID", "dbo.Exams");
            DropForeignKey("dbo.Marks", "ClassSectionID", "dbo.ClassSections");
            DropForeignKey("dbo.Marks", "AssignStudentToClassID", "dbo.AssignStudentToClasses");
            DropForeignKey("dbo.Routines", "SubjectTeacherID", "dbo.SubjectTeachers");
            DropForeignKey("dbo.Routines", "ClassSectionID", "dbo.ClassSections");
            DropForeignKey("dbo.AssignTeacherToClasses", "TeacherID", "dbo.Teachers");
            DropForeignKey("dbo.Teachers", "ApplicationUserID", "dbo.AspNetUsers");
            DropForeignKey("dbo.Students", "ParentID", "dbo.Parents");
            DropForeignKey("dbo.AssignStudentToClasses", "StudentID", "dbo.Students");
            DropForeignKey("dbo.Students", "ApplicationUserID", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Clerks", "ApplicationUserID", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AssignTeacherToClasses", "ClassSectionID", "dbo.ClassSections");
            DropForeignKey("dbo.AssignStudentToClasses", "ClassSectionID", "dbo.ClassSections");
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropIndex("dbo.Marks", new[] { "GradeID" });
            DropIndex("dbo.Marks", new[] { "AssignStudentToClassID" });
            DropIndex("dbo.Marks", new[] { "ExamID" });
            DropIndex("dbo.Marks", new[] { "SubjectID" });
            DropIndex("dbo.Marks", new[] { "ClassSectionID" });
            DropIndex("dbo.Routines", new[] { "SubjectTeacherID" });
            DropIndex("dbo.Routines", new[] { "ClassSectionID" });
            DropIndex("dbo.SubjectTeachers", new[] { "SubjectID" });
            DropIndex("dbo.SubjectTeachers", new[] { "TeacherID" });
            DropIndex("dbo.Students", new[] { "ParentID" });
            DropIndex("dbo.Students", new[] { "ApplicationUserID" });
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.Clerks", new[] { "ApplicationUserID" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.Teachers", new[] { "ApplicationUserID" });
            DropIndex("dbo.AssignTeacherToClasses", new[] { "TeacherID" });
            DropIndex("dbo.AssignTeacherToClasses", new[] { "ClassSectionID" });
            DropIndex("dbo.ClassSections", new[] { "SectionID" });
            DropIndex("dbo.ClassSections", new[] { "SClassID" });
            DropIndex("dbo.AssignStudentToClasses", new[] { "ClassSectionID" });
            DropIndex("dbo.AssignStudentToClasses", new[] { "StudentID" });
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.Notices");
            DropTable("dbo.Sections");
            DropTable("dbo.SClasses");
            DropTable("dbo.Grades");
            DropTable("dbo.Exams");
            DropTable("dbo.Marks");
            DropTable("dbo.Subjects");
            DropTable("dbo.Routines");
            DropTable("dbo.SubjectTeachers");
            DropTable("dbo.Parents");
            DropTable("dbo.Students");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.Clerks");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.Teachers");
            DropTable("dbo.AssignTeacherToClasses");
            DropTable("dbo.ClassSections");
            DropTable("dbo.AssignStudentToClasses");
            DropTable("dbo.ArchivedStudents");
        }
    }
}
