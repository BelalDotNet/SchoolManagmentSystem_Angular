namespace SchoolManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ssfs : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Uploads",
                c => new
                    {
                        UploadID = c.Int(nullable: false, identity: true),
                        Caption = c.String(),
                        ImageName = c.String(),
                    })
                .PrimaryKey(t => t.UploadID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Uploads");
        }
    }
}
