namespace SchoolManagement.Migrations
{
    using SchoolManagement.Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<SchoolManagement.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(SchoolManagement.Models.ApplicationDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            if (!context.Users.Any())
            {
                var users = new List<ApplicationUser>
            {
                new ApplicationUser{Id="1",Email="mehedi@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Mehedi"},
                new ApplicationUser{Id="2",Email="mamun@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Mamun"},
                new ApplicationUser{Id="3",Email="belal@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Belal"},
                new ApplicationUser{Id="4",Email="azim@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Azim"},
                new ApplicationUser{Id="5",Email="naznin@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Naznin"},
                new ApplicationUser{Id="6",Email="nasir@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Nasir"},
                new ApplicationUser{Id="7",Email="kaiyum@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Kaiyum"},
                new ApplicationUser{Id="8",Email="riduan@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Riduan"},
                new ApplicationUser{Id="9",Email="noman@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Noman"}
            };

                users.ForEach(u => context.Users.AddOrUpdate(u));
                context.SaveChanges();

            }

            if (!context.SClasses.Any())
            {
                var cls = new List<SClass>
                {
                    new SClass {ClassName = "One", ClassName_Numeric = "01", IsActive = true},
                    new SClass {ClassName = "Two", ClassName_Numeric = "02", IsActive = true},
                    new SClass {ClassName = "Three", ClassName_Numeric = "03", IsActive = true},
                    new SClass {ClassName = "Four", ClassName_Numeric = "04", IsActive = true},
                    new SClass {ClassName = "Five", ClassName_Numeric = "05", IsActive = true},
                    new SClass {ClassName = "Six", ClassName_Numeric = "06", IsActive = true},
                    new SClass {ClassName = "Seven", ClassName_Numeric = "07", IsActive = true},
                    new SClass {ClassName = "Eight", ClassName_Numeric = "08", IsActive = true},
                    new SClass {ClassName = "Nine", ClassName_Numeric = "09", IsActive = true},
                    new SClass {ClassName = "Ten", ClassName_Numeric = "10", IsActive = true},
                };

                cls.ForEach(s => context.SClasses.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Sections.Any())
            {
                var sec = new List<Section>
                {
                    new Section {SectionName = "A", NickName ="Padma", IsActive = true},
                    new Section {SectionName = "B", NickName ="Meghna", IsActive = true},
                    new Section {SectionName = "C", NickName ="Jamuna", IsActive = true},

                };
                sec.ForEach(s => context.Sections.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.ClassSections.Any())
            {
                var clsSectionsec = new List<ClassSection>
                {
                     new ClassSection{SClassID =1,SectionID = 1},
                     new ClassSection{SClassID =1,SectionID = 2},
                     new ClassSection{SClassID =1,SectionID = 3},
                     new ClassSection{SClassID =2,SectionID = 1},
                     new ClassSection{SClassID =2,SectionID = 2},
                     new ClassSection{SClassID =3,SectionID = 1},
                     new ClassSection{SClassID =3,SectionID = 2},
                     new ClassSection{SClassID =4,SectionID = 1},
                     new ClassSection{SClassID =4,SectionID = 2},
                     new ClassSection{SClassID =5,SectionID = 1},
                     new ClassSection{SClassID =5,SectionID = 2},
                     new ClassSection{SClassID =5,SectionID = 2},
                     new ClassSection{SClassID =6,SectionID = 1},
                     new ClassSection{SClassID =6,SectionID = 2},
                     new ClassSection{SClassID =7,SectionID = 1},
                     new ClassSection{SClassID =7,SectionID = 2},
                     new ClassSection{SClassID =8,SectionID = 1},
                     new ClassSection{SClassID =8,SectionID = 2},
                     new ClassSection{SClassID =9,SectionID = 1},
                     new ClassSection{SClassID =9,SectionID = 2},
                     new ClassSection{SClassID =10,SectionID = 1},
                     new ClassSection{SClassID =10,SectionID = 2}
                };
                clsSectionsec.ForEach(s => context.ClassSections.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Grades.Any())
            {
                var grades = new List<Grade>
                {
                    new Grade {GradeRange = "80-100",GradePoint =Convert.ToDecimal(5.00),GradeName = "A+",Comment = "Excellent"},
                    new Grade {GradeRange = "70-79",GradePoint =Convert.ToDecimal(4.00),GradeName = "A",Comment = "Very Good"},
                    new Grade {GradeRange = "60-69",GradePoint =Convert.ToDecimal(3.50),GradeName = "A-",Comment = "Good"},
                    new Grade {GradeRange = "50-59",GradePoint =Convert.ToDecimal(3.00),GradeName = "B",Comment = "Average"},
                    new Grade {GradeRange = "40-49",GradePoint =Convert.ToDecimal(2.00),GradeName = "C",Comment = "Poor"},
                    new Grade {GradeRange = "33-39",GradePoint =Convert.ToDecimal(1.00),GradeName = "D",Comment = "Pass"}
                };
                grades.ForEach(s => context.Grades.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Exams.Any())
            {
                var exam = new List<Exam>
                {
                    new Exam {ExamName = "1st Semister", Comment = ""},
                    new Exam {ExamName = "2nd Semister", Comment = ""},
                    new Exam {ExamName = "3rd Semister", Comment = ""},
                    new Exam {ExamName = "Class Test-1", Comment = ""},
                    new Exam {ExamName = "Class Test-2", Comment = ""}
                };
                exam.ForEach(s => context.Exams.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Subjects.Any())
            {
                var subjects = new List<Subject>
            {
                //Class One
                new Subject{SubjectName="English", ClassName="One"},
                new Subject{SubjectName="Bangla", ClassName="One"},
                new Subject{SubjectName="General Math", ClassName="One"},
                new Subject{SubjectName="Religious Studies", ClassName="One"},
                

                 



                //Class Two
                new Subject{SubjectName="English", ClassName="Two"},
                new Subject{SubjectName="Bangla", ClassName="Two"},
                new Subject{SubjectName="General Math", ClassName="Two"},
                new Subject{SubjectName="Religious Studies", ClassName="Two"},
                


                //Class Three
                new Subject{SubjectName="English", ClassName="Three"},
                new Subject{SubjectName="Bangla", ClassName="Three"},
                new Subject{SubjectName="General Math", ClassName="Three"},
                new Subject{SubjectName="General Science", ClassName="Three"},
                new Subject{SubjectName="Religious Studies", ClassName="Three"},
               
                



                //Class Four
                new Subject{SubjectName="English", ClassName="Four"},
                new Subject{SubjectName="Bangla", ClassName="Four"},
                new Subject{SubjectName="General Math", ClassName="Four"},
                new Subject{SubjectName="General Science", ClassName="Four"},
                new Subject{SubjectName="Religious Studies", ClassName="Four"},
                



                //Class Five
                new Subject{SubjectName="English", ClassName="Five"},
                new Subject{SubjectName="Bangla", ClassName="Five"},
                new Subject{SubjectName="General Math", ClassName="Five"},
                new Subject{SubjectName="General Science", ClassName="Five"},
                new Subject{SubjectName="Religious Studies", ClassName="Five"},               


                //Class Six
                new Subject{SubjectName="English 1st Paper", ClassName="Six"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Six"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Six"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Six"},
                new Subject{SubjectName="General Math", ClassName="Six"},
                new Subject{SubjectName="General Science", ClassName="Six"},
                new Subject{SubjectName="Religious Studies", ClassName="Six"},
                new Subject{SubjectName="Social Science", ClassName="Six"},
                new Subject{SubjectName="Agriculture", ClassName="Six"},
                new Subject{SubjectName="ICT", ClassName="Six"},               


                //Class Seven
                new Subject{SubjectName="English 1st Paper", ClassName="Seven"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Seven"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Seven"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Seven"},
                new Subject{SubjectName="General Math", ClassName="Seven"},
                new Subject{SubjectName="General Science", ClassName="Seven"},
                new Subject{SubjectName="Religious Studies", ClassName="Seven"},
                new Subject{SubjectName="Social Science", ClassName="Seven"},
                new Subject{SubjectName="Agriculture", ClassName="Seven"},
                new Subject{SubjectName="ICT", ClassName="Seven"},


                //Class Eight
                new Subject{SubjectName="English 1st Paper", ClassName="Eight"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Eight"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Eight"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Eight"},
                new Subject{SubjectName="General Math", ClassName="Eight"},
                new Subject{SubjectName="General Science", ClassName="Eight"},
                new Subject{SubjectName="Religious Studies", ClassName="Eight"},
                new Subject{SubjectName="Social Science", ClassName="Eight"},
                new Subject{SubjectName="Agriculture", ClassName="Eight"},
                new Subject{SubjectName="ICT", ClassName="Eight"},



                //Class Nine
                new Subject{SubjectName="English 1st Paper", ClassName="Nine"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Nine"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Nine"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Nine"},
                new Subject{SubjectName="General Math", ClassName="Nine"},
                new Subject{SubjectName="General Science", ClassName="Nine"},
                new Subject{SubjectName="Religious Studies", ClassName="Nine"},
                new Subject{SubjectName="Social Science", ClassName="Nine"},
                new Subject{SubjectName="Economics", ClassName="Nine"},
                new Subject{SubjectName="Business Entrepreneur", ClassName="Nine"},
                new Subject{SubjectName="Physics", ClassName="Nine"},
                new Subject{SubjectName="Chemistry", ClassName="Nine"},
                new Subject{SubjectName="Biology", ClassName="Nine"},
                new Subject{SubjectName="Higher Math", ClassName="Nine"},
                new Subject{SubjectName="Agriculture", ClassName="Nine"},
                new Subject{SubjectName="Statistics", ClassName="Nine"},
                new Subject{SubjectName="ICT", ClassName="Nine"},
                new Subject{SubjectName="Geology", ClassName="Nine"},
                new Subject{SubjectName="History", ClassName="Nine"},
                


                //Class Ten
                new Subject{SubjectName="English 1st Paper", ClassName="Ten"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Ten"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Ten"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Ten"},
                new Subject{SubjectName="General Math", ClassName="Ten"},
                new Subject{SubjectName="General Science", ClassName="Ten"},
                new Subject{SubjectName="Religious Studies", ClassName="Ten"},
                new Subject{SubjectName="Social Science", ClassName="Ten"},
                new Subject{SubjectName="Economics", ClassName="Ten"},
                new Subject{SubjectName="Business Entrepreneur", ClassName="Ten"},
                new Subject{SubjectName="Physics", ClassName="Ten"},
                new Subject{SubjectName="Chemistry", ClassName="Ten"},
                new Subject{SubjectName="Biology", ClassName="Ten"},
                new Subject{SubjectName="Higher Math", ClassName="Ten"},
                new Subject{SubjectName="Agriculture", ClassName="Ten"},
                new Subject{SubjectName="Statistics", ClassName="Ten"},
                new Subject{SubjectName="ICT", ClassName="Ten"},
                new Subject{SubjectName="Geology", ClassName="Ten"},
                new Subject{SubjectName="History", ClassName="Ten"},
            };
                subjects.ForEach(s => context.Subjects.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Parents.Any())
            {
                var parent = new List<Parent>
             {
                 new Parent{Profession="Job Holder", NID="012457845",ParentName="Sadik Chowdhury",IsActive=true},
                 new Parent{Profession="Job Holder", NID="012457846",ParentName="Sorwar Hossain",IsActive=true},
                 new Parent{Profession="Banker", NID="012457847",ParentName="Mehedi Maruf",IsActive=true},
                 new Parent{Profession="Banker", NID="012457848",ParentName="Sajjad Hossain",IsActive=true},
                 new Parent{Profession="Business", NID="012457849",ParentName="Humaun Ahmed",IsActive=true},
             };
                parent.ForEach(s => context.Parents.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Students.Any())
            {
                var stdnt = new List<Student>
                {
                    new Student {StudentRegID ="201901",Name = "Mehedi Hasan",NID = "",DOB=Convert.ToDateTime("2014/01/20").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "1",ParentID = 1,Image = "",IsActive = true},
                    new Student {StudentRegID ="201902",Name = "Masum Rana",NID = "",DOB=Convert.ToDateTime("2014/02/20").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "2",ParentID = 2,Image = "",IsActive = true},
                    new Student {StudentRegID ="201903",Name = "Nasir Ahmed",NID = "",DOB=Convert.ToDateTime("2015/02/20").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "3",ParentID = 3,Image = "",IsActive = true},
                    new Student {StudentRegID ="201904",Name = "Bellal Hossain",NID = "",DOB=Convert.ToDateTime("2014/02/20").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "4",ParentID = 2,Image = "",IsActive = true},
                    new Student {StudentRegID ="201905",Name = "Nasir Ahmed",NID = "",DOB=Convert.ToDateTime("2015/02/22").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "5",ParentID = 4,Image = "",IsActive = true},
                    new Student {StudentRegID ="201906",Name = "Nasir Ahmed",NID = "",DOB=Convert.ToDateTime("2015/02/12").Date,Gender ="Male",Address = "Nasirabad,CTG",ApplicationUserID = "6",ParentID = 5,Image = "",IsActive = true}
                };
                stdnt.ForEach(s => context.Students.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Clerks.Any())
            {
                var clrk = new List<Clerk>
                {
                    new Clerk {Name= "Hasib Chowdhury",NID = "SDGSDFGFD",DOB = Convert.ToDateTime("1986/11/23"),Gender = "Male",Address = "Comilla",ApplicationUserID="1",Image = ""},
                    new Clerk {Name="Sumon Miah",NID = "HJFGHJGHJKGHK",DOB = Convert.ToDateTime("1988/04/15"),Gender = "Male",Address = "Dhaka",ApplicationUserID="2",Image = ""},
                    new Clerk {Name="Jalal Ahmed",NID = "JHKGJHKHGH",DOB = Convert.ToDateTime("1995/12/24"),Gender = "Male",Address = "Chottogram",ApplicationUserID="3",Image = ""},
                     new Clerk {Name="Sohel Rana",NID = "DSRDSGVCXVXCF",DOB = Convert.ToDateTime("1998/03/22"),Gender = "Male",Address = "Rajshahi",ApplicationUserID="4",Image = ""}
                };

                clrk.ForEach(s => context.Clerks.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Teachers.Any())
            {
                var teacher = new List<Teacher>
                {
                    new Teacher{Name= "Nasir Ahmed",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/01/1990") ,Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="3"},
                    new Teacher{Name= "Kabir Ahmed",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/01/1991"),Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="4"},
                    new Teacher{Name= "Sahadat Hossain",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/01/1992"),Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="5"},
                    new Teacher{Name= "Monjurul Alam",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/01/1993"),Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="6"},
                    new Teacher{Name= "Ariful Islam",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/05/1990"),Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="5"},
                    new Teacher{Name= "Nasrin Akter",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/11/1990"),Gender="Female",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="7"},
                    new Teacher{Name= "Ballal Hossain",Designation="Assistant Teacher",DOB=Convert.ToDateTime("01/12/1990"),Gender="Male",Image="",IsActive=true,Address="Chattogram",ApplicationUserID="8"},
                };
                teacher.ForEach(s => context.Teachers.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.AssignTeacherToClasses.Any())
            {
                var assignTeacherToClasses = new List<AssignTeacherToClass>
                {
                    new AssignTeacherToClass {ClassSectionID = 1, TeacherID = 1, IsClassTeacher = true},
                    new AssignTeacherToClass {ClassSectionID = 2, TeacherID = 2, IsClassTeacher = true},
                    new AssignTeacherToClass {ClassSectionID = 3, TeacherID = 3, IsClassTeacher = true},
                    new AssignTeacherToClass {ClassSectionID = 4, TeacherID = 4, IsClassTeacher = true},
                    new AssignTeacherToClass {ClassSectionID = 5, TeacherID = 5, IsClassTeacher = true}
                };
                assignTeacherToClasses.ForEach(s => context.AssignTeacherToClasses.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.SubjectTeachers.Any())
            {
                var subTech = new List<SubjectTeacher>
                {
                    new SubjectTeacher {SubjectID = 1, TeacherID = 1},
                    new SubjectTeacher {SubjectID = 2, TeacherID = 2},
                    new SubjectTeacher {SubjectID = 3, TeacherID = 3},
                    new SubjectTeacher {SubjectID = 4, TeacherID = 4},
                    new SubjectTeacher {SubjectID = 5, TeacherID = 5},
                    new SubjectTeacher {SubjectID = 6, TeacherID = 1},
                    new SubjectTeacher {SubjectID = 7, TeacherID = 2},
                    new SubjectTeacher {SubjectID = 8, TeacherID = 3},
                    new SubjectTeacher {SubjectID = 9, TeacherID = 4},
                    new SubjectTeacher {SubjectID = 10, TeacherID = 5}

                };
                subTech.ForEach(s => context.SubjectTeachers.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.AssignStudentToClasses.Any())
            {
                var assignStudentToClasses = new List<AssignStudentToClass>
                {
                    new AssignStudentToClass {RollNo=1,SessionYear="2019",StudentID=1,ClassSectionID=1,PresentStatus="Promoted",},
                    new AssignStudentToClass {RollNo=2,SessionYear="2019",StudentID=2,ClassSectionID=1,PresentStatus="Promoted",},
                    new AssignStudentToClass {RollNo=3,SessionYear="2019",StudentID=3,ClassSectionID=1,PresentStatus="Promoted",},
                    new AssignStudentToClass {RollNo=4,SessionYear="2019",StudentID=4,ClassSectionID=1,PresentStatus="Promoted",},
                    new AssignStudentToClass {RollNo=5,SessionYear="2019",StudentID=5,ClassSectionID=1,PresentStatus="Promoted",}
                };
                assignStudentToClasses.ForEach(s => context.AssignStudentToClasses.AddOrUpdate(s));
                context.SaveChanges();
            }


            if (!context.Marks.Any())
            {
                var mark = new List<Mark>
                {
                    new Mark {ClassSectionID =1,SubjectID = 1,ExamID = 1,PassingYear ="2019",AssignStudentToClassID =1,ObtainedMark = 90,SubjectMark =100, GradeID =1,EntryBy ="Bellal Hossain" ,EntryDate = Convert.ToDateTime("2019/08/03")},
                    new Mark {ClassSectionID =1,SubjectID = 1,ExamID = 1,PassingYear ="2019",AssignStudentToClassID =2,ObtainedMark = 90,SubjectMark =100, GradeID =1,EntryBy ="Bellal Hossain" ,EntryDate = Convert.ToDateTime("2019/08/03")},
                    new Mark {ClassSectionID =1,SubjectID = 1,ExamID = 1,PassingYear ="2019",AssignStudentToClassID =3,ObtainedMark = 90,SubjectMark =100, GradeID =1,EntryBy ="Bellal Hossain" ,EntryDate = Convert.ToDateTime("2019/08/03")},
                    new Mark {ClassSectionID =1,SubjectID = 1,ExamID = 1,PassingYear ="2019",AssignStudentToClassID =4,ObtainedMark = 90,SubjectMark =100, GradeID =1,EntryBy ="Bellal Hossain" ,EntryDate = Convert.ToDateTime("2019/08/03")},
                    new Mark {ClassSectionID =1,SubjectID = 1,ExamID = 1,PassingYear ="2019",AssignStudentToClassID =5,ObtainedMark = 90,SubjectMark =100, GradeID =1,EntryBy ="Bellal Hossain" ,EntryDate = Convert.ToDateTime("2019/08/03")}
                };
                mark.ForEach(s => context.Marks.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.Notices.Any())
            {
                var notice = new List<Notice>
                {
                    new Notice {Title = "Exam Notice",Date = Convert.ToDateTime("2019/07/01"),ImagePath = "",FileLink = "",IsDisplay = true,CreatedBy = "Abdullah al Masum"}
                };
                notice.ForEach(s => context.Notices.AddOrUpdate(s));
                context.SaveChanges();
            }

            if (!context.ArchivedStudents.Any())
            {
                var archiveStudent = new List<ArchivedStudent>
                {
                    new ArchivedStudent{RollNo = 1, SessionYear = "2010", StudentRegID = "201001", ClassName = "One",SectionName = "Padma"}
                };
                archiveStudent.ForEach(s => context.ArchivedStudents.AddOrUpdate(s));
                context.SaveChanges();
            }
        }
    }
}
