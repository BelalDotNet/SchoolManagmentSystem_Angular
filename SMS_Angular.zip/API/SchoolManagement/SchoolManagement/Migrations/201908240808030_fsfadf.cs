namespace SchoolManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class fsfadf : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Notices", "Body", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Notices", "Body");
        }
    }
}
