using SchoolManagement.DAL;
using SchoolManagement.Models;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace SchoolManagement
{
	public static class UnityConfig
	{
		public static void RegisterComponents()
		{
			var container = new UnityContainer();

			// register all your components with the container here
			// it is NOT necessary to register your controllers

			// e.g. container.RegisterType<ITestService, TestService>();

			container.RegisterType<ISchoolRepository<SClass>, ClassRepository>();
			container.RegisterType<ISchoolRepository<Section>, SectionRepository>();
			container.RegisterType<ISchoolRepository<Parent>, ParentRepository>();
			container.RegisterType<ISchoolRepository<Student>, StudentRepository>();
			container.RegisterType<ISchoolRepository<Subject>, SubjectRepository>();
			container.RegisterType<ISchoolRepository<Teacher>, TeacherRepository>();
			container.RegisterType<ISchoolRepository<Exam>, ExamRepository>();
			container.RegisterType<ISchoolRepository<Clerk>, ClerkRepository>();
			container.RegisterType<ISchoolRepository<SubjectTeacher>, SubjectTeacherRepository>();
			container.RegisterType<ISchoolRepository<Routine>, RoutineRepository>();
			container.RegisterType<ISchoolRepository<Notice>, NoticeRepository>();
			container.RegisterType<ISchoolRepository<Mark>, MarkRepository>();
			container.RegisterType<ISchoolRepository<Grade>, GradeRepository>();
			container.RegisterType<ISchoolRepository<ClassSection>, ClassSectionRepository>();
			container.RegisterType<ISchoolRepository<AssignTeacherToClass>, AssignTeacherToClassRepository>();
			container.RegisterType<ISchoolRepository<AssignStudentToClass>, AssignStudentToClassRepository>();

			GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
		}
	}
}