﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;

namespace SchoolManagement.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit https://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        //Start Custom Identity Here
        


        public virtual ICollection<Clerk> Clerks { get; set; }
        public virtual ICollection<Student> Students { get; set; }
        public virtual ICollection<Teacher> Teachers { get; set; }








        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager, string authenticationType)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, authenticationType);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(): base("DbCon", throwIfV1Schema: false)
        {
            //this.Configuration.LazyLoadingEnabled = false;

        }
        
        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            

        }
        public DbSet<ArchivedStudent> ArchivedStudents { get; set; }
        public DbSet<AssignStudentToClass> AssignStudentToClasses { get; set; }
        public DbSet<AssignTeacherToClass> AssignTeacherToClasses { get; set; }
        public DbSet<ClassSection> ClassSections { get; set; }
        public DbSet<SubjectTeacher> SubjectTeachers { get; set; }

        public DbSet<SClass> SClasses { get; set; }
        public DbSet<Exam> Exams { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public DbSet<Mark> Marks { get; set; }
        public DbSet<Notice> Notices { get; set; }
        public DbSet<Parent> Parents { get; set; }
        public DbSet<Routine> Routines { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Clerk> Clerks { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Upload> Uploads { get; set; }





      

    }
}