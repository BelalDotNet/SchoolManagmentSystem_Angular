﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Upload
    {
        public int UploadID { get; set; }
        public string Caption { get; set; }
        public string ImageName { get; set; }
    }
}