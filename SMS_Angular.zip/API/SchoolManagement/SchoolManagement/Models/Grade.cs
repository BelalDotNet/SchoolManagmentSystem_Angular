﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Grade
    {
        public int GradeID { get; set; }
        public string GradeRange { get; set; }
        public decimal GradePoint { get; set; }
        public string GradeName { get; set; }
        public string Comment { get; set; }
        public  ICollection<Mark> Marks { get; set; }

    }
}