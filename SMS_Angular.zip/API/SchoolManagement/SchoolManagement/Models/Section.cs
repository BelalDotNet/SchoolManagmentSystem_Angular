﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Section
    {
        public int SectionID { get; set; }
        
        [Required]
        public string SectionName { get; set; }
        public string NickName { get; set; }

        [Required]
        public bool? IsActive { get; set; }

        public ICollection<ClassSection> ClassSection { get; set; }
    }
}