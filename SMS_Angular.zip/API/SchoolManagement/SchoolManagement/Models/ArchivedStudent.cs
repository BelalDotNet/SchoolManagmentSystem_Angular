﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class ArchivedStudent
    {
        public int ArchivedStudentID { get; set; }
        public int RollNo { get; set; }
        public string SessionYear { get; set; }
        public string StudentRegID { get; set; }
        public string ClassName { get; set; }
        public string SectionName { get; set; }
    }
}