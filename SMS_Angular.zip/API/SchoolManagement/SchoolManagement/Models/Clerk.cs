﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Clerk
    {
        public int ClerkID { get; set; }

        public string Name { get; set; }
        public string NID { get; set; }

        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }
        public string Gender { get; set; }

        public string Address { get; set; }

        [Display(Name = "User ID")]
        public string ApplicationUserID { get; set; }
        public string Image { get; set; }
        public  ApplicationUser ApplicationUser { get; set; }
    }
}