﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Student
    {
        public int StudentID { get; set; }

        //[Required]
        [Display(Name = "Student Reg. ID")]
        public string StudentRegID { get; set; }

        public string Name { get; set; }
        public string NID { get; set; }

        [Display(Name = "Date Of Birth")]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        public string Gender { get; set; }

        public string Address { get; set; }



        //[Required]
        [Display(Name = "User ID")]
        public string ApplicationUserID { get; set; }

        [Display(Name ="Parent ID")]
        public int ParentID { get; set; }
        public string Image { get; set; }

        [NotMapped]
        public HttpPostedFileBase ImageFile { get; set; }
        public bool IsActive { get; set; }

        public  ApplicationUser ApplicationUser { get; set; }
        public  Parent Parent { get; set; }
        public  ICollection<AssignStudentToClass> AssignStudentToClasses { get; set; }

    }
}