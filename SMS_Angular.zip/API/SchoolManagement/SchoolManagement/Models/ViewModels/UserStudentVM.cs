﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models.ViewModels
{
    public class UserStudentVM
    {
        //User Properties
        public string Email { get; set; }        
        public string Password { get; set; }               
        public string ConfirmPassword { get; set; }
        public string PhoneNumber { get; set; }


        //Student Properties
        public int StudentID { get; set; }
        public string StudentRegID { get; set; }
        public string Name { get; set; }
        public string NID { get; set; }   
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }       
        public string ApplicationUserID { get; set; }
        public int ParentID { get; set; }
        public string Image { get; set; }

        [NotMapped]
        public HttpPostedFileBase ImageFile { get; set; }
        public bool IsActive { get; set; }        
    }
}