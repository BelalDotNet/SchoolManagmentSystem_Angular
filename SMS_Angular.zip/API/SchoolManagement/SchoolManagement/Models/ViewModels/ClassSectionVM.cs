﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models.ViewModels
{
    public class ClassSectionVM
    {
        public int SectionID { get; set; }

        [Required]
        public string SectionName { get; set; }
        public string NickName { get; set; }

        [Required]
        public bool? IsActive { get; set; }

        public int SClassID { get; set; }


        [Required]
        [Display(Name = "Class Name")]
        public string ClassName { get; set; }


        [Required]
        [Display(Name = "Numeric Name")]
        public string ClassName_Numeric { get; set; }

    }
}