﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Parent
    {
        public int ParentID { get; set; }
        public string ParentName { get; set; }
        public string Profession { get; set; }
        public string NID { get; set; }
        public bool? IsActive { get; set; }

        public  ICollection<Student> Students { get; set; }
    }
}
