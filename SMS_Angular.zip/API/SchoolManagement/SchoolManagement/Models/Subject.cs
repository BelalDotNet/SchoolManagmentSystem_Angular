﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SchoolManagement.Models
{
    public class Subject
    {
        public int SubjectID { get; set; }

        [Required]
        [Display(Name ="Subject Name")]
        public string SubjectName { get; set; }
        
        [Required]
        [Display(Name ="Class Name")]
        public string ClassName { get; set; }     
        

        public  ICollection<SubjectTeacher> SubjectTeachers  { get; set; }
        public  ICollection<Mark> Marks  { get; set; }
    }
}