﻿using AutoMapper;
using Newtonsoft.Json.Serialization;
using SchoolManagement.Infrastructure;
using SchoolManagement.Models;
using SchoolManagement.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace SchoolManagement
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            UnityConfig.RegisterComponents();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<AutomapperWebProfile>();              
            });
            var mapper = config.CreateMapper();

            HttpConfiguration config2 = GlobalConfiguration.Configuration;
            config2.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            config2.Formatters.JsonFormatter.UseDataContractJsonSerializer = false;
        }
    }
}
