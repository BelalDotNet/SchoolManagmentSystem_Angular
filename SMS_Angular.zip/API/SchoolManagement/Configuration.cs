namespace SchoolManagement.Migrations
{
    using SchoolManagement.Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<SchoolManagement.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(SchoolManagement.Models.ApplicationDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
            if (!context.Users.Any())
            {
                var users = new List<ApplicationUser>
            {
                new ApplicationUser{Id="1",Email="mehedi@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Mehedi"},
                new ApplicationUser{Id="2",Email="mamun@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Mamun"},
                new ApplicationUser{Id="3",Email="belal@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Belal"},
                new ApplicationUser{Id="4",Email="azim@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Azim"},
                new ApplicationUser{Id="5",Email="naznin@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Naznin"},
                new ApplicationUser{Id="6",Email="nasir@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Nasir"},
                new ApplicationUser{Id="7",Email="kaiyum@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Kaiyum"},
                new ApplicationUser{Id="8",Email="riduan@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Riduan"},
                new ApplicationUser{Id="9",Email="noman@gmail.com", EmailConfirmed=true, PasswordHash="Mehedi@123", SecurityStamp="",PhoneNumber="01723962962",PhoneNumberConfirmed=true,TwoFactorEnabled=false, LockoutEndDateUtc=DateTime.Parse("2019/02/02"), LockoutEnabled=true, AccessFailedCount=2, UserName="Noman"}
            };

                users.ForEach(u => context.Users.Add(u));
                context.SaveChanges();

            }




            if (!context.Subjects.Any())
            {
                var subjects = new List<Subject>
            {
                //Class One
                new Subject{SubjectName="English", ClassName="One"},
                new Subject{SubjectName="Bangla", ClassName="One"},
                new Subject{SubjectName="General Math", ClassName="One"},
                new Subject{SubjectName="Religious Studies", ClassName="One"},
                

                 



                //Class Two
                new Subject{SubjectName="English", ClassName="Two"},
                new Subject{SubjectName="Bangla", ClassName="Two"},
                new Subject{SubjectName="General Math", ClassName="Two"},
                new Subject{SubjectName="Religious Studies", ClassName="Two"},
                


                //Class Three
                new Subject{SubjectName="English", ClassName="Three"},
                new Subject{SubjectName="Bangla", ClassName="Three"},
                new Subject{SubjectName="General Math", ClassName="Three"},
                new Subject{SubjectName="General Science", ClassName="Three"},
                new Subject{SubjectName="Religious Studies", ClassName="Three"},
               
                



                //Class Four
                new Subject{SubjectName="English", ClassName="Four"},
                new Subject{SubjectName="Bangla", ClassName="Four"},
                new Subject{SubjectName="General Math", ClassName="Four"},
                new Subject{SubjectName="General Science", ClassName="Four"},
                new Subject{SubjectName="Religious Studies", ClassName="Four"},
                



                //Class Five
                new Subject{SubjectName="English", ClassName="Five"},
                new Subject{SubjectName="Bangla", ClassName="Five"},
                new Subject{SubjectName="General Math", ClassName="Five"},
                new Subject{SubjectName="General Science", ClassName="Five"},
                new Subject{SubjectName="Religious Studies", ClassName="Five"},               


                //Class Six
                new Subject{SubjectName="English 1st Paper", ClassName="Six"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Six"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Six"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Six"},
                new Subject{SubjectName="General Math", ClassName="Six"},
                new Subject{SubjectName="General Science", ClassName="Six"},
                new Subject{SubjectName="Religious Studies", ClassName="Six"},
                new Subject{SubjectName="Social Science", ClassName="Six"},                
                new Subject{SubjectName="Agriculture", ClassName="Six"},
                new Subject{SubjectName="ICT", ClassName="Six"},               


                //Class Seven
                new Subject{SubjectName="English 1st Paper", ClassName="Seven"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Seven"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Seven"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Seven"},
                new Subject{SubjectName="General Math", ClassName="Seven"},
                new Subject{SubjectName="General Science", ClassName="Seven"},
                new Subject{SubjectName="Religious Studies", ClassName="Seven"},
                new Subject{SubjectName="Social Science", ClassName="Seven"},
                new Subject{SubjectName="Agriculture", ClassName="Seven"},
                new Subject{SubjectName="ICT", ClassName="Seven"},


                //Class Eight
                new Subject{SubjectName="English 1st Paper", ClassName="Eight"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Eight"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Eight"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Eight"},
                new Subject{SubjectName="General Math", ClassName="Eight"},
                new Subject{SubjectName="General Science", ClassName="Eight"},
                new Subject{SubjectName="Religious Studies", ClassName="Eight"},
                new Subject{SubjectName="Social Science", ClassName="Eight"},
                new Subject{SubjectName="Agriculture", ClassName="Eight"},
                new Subject{SubjectName="ICT", ClassName="Eight"},



                //Class Nine
                new Subject{SubjectName="English 1st Paper", ClassName="Nine"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Nine"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Nine"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Nine"},
                new Subject{SubjectName="General Math", ClassName="Nine"},
                new Subject{SubjectName="General Science", ClassName="Nine"},
                new Subject{SubjectName="Religious Studies", ClassName="Nine"},
                new Subject{SubjectName="Social Science", ClassName="Nine"},
                new Subject{SubjectName="Economics", ClassName="Nine"},
                new Subject{SubjectName="Business Entrepreneur", ClassName="Nine"},
                new Subject{SubjectName="Physics", ClassName="Nine"},
                new Subject{SubjectName="Chemistry", ClassName="Nine"},
                new Subject{SubjectName="Biology", ClassName="Nine"},
                new Subject{SubjectName="Higher Math", ClassName="Nine"},
                new Subject{SubjectName="Agriculture", ClassName="Nine"},
                new Subject{SubjectName="Statistics", ClassName="Nine"},
                new Subject{SubjectName="ICT", ClassName="Nine"},
                new Subject{SubjectName="Geology", ClassName="Nine"},
                new Subject{SubjectName="History", ClassName="Nine"},
                


                //Class Ten
                new Subject{SubjectName="English 1st Paper", ClassName="Ten"},
                new Subject{SubjectName="English 2nd Paper", ClassName="Ten"},
                new Subject{SubjectName="Bangla 1st Paper", ClassName="Ten"},
                new Subject{SubjectName="Bangla 2nd Paper", ClassName="Ten"},
                new Subject{SubjectName="General Math", ClassName="Ten"},
                new Subject{SubjectName="General Science", ClassName="Ten"},
                new Subject{SubjectName="Religious Studies", ClassName="Ten"},
                new Subject{SubjectName="Social Science", ClassName="Ten"},
                new Subject{SubjectName="Economics", ClassName="Ten"},
                new Subject{SubjectName="Business Entrepreneur", ClassName="Ten"},
                new Subject{SubjectName="Physics", ClassName="Ten"},
                new Subject{SubjectName="Chemistry", ClassName="Ten"},
                new Subject{SubjectName="Biology", ClassName="Ten"},
                new Subject{SubjectName="Higher Math", ClassName="Ten"},
                new Subject{SubjectName="Agriculture", ClassName="Ten"},
                new Subject{SubjectName="Statistics", ClassName="Ten"},
                new Subject{SubjectName="ICT", ClassName="Ten"},
                new Subject{SubjectName="Geology", ClassName="Ten"},
                new Subject{SubjectName="History", ClassName="Ten"},
            };
                subjects.ForEach(s => context.Subjects.Add(s));
                context.SaveChanges();
            }
        }
    }
}
