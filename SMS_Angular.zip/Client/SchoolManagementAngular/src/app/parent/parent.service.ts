import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Parent } from './parent';



@Injectable({
  providedIn: 'root'
})
export class ParentService {
  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getAllParent(): Observable<Parent[]> {
    return this._http.get<Parent[]>(this.url + '/ParentApi/GetParents');
  }

  getParentById(id: any): Observable<any> {
    return this._http.get<Parent>(this.url + '/ParentApi/GetParentById/' + id);
  }


  createParent(parent: Parent): Observable<Parent> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Parent>(this.url + '/ParentApi/InsertParent/', parent, httpOptions);
  }

  updateParent(parent: Parent): Observable<Parent> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Parent>(this.url + '/ParentApi/UpdateParent', parent, httpOptions);
  }

  deleteParentById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/ParentApi/DeleteParent/' + id,
      httpOptions);
  }

}
