import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { ParentService} from './parent.service';
import { Parent} from './parent';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-parent',
  templateUrl: './list-parent.component.html',
  styleUrls: ['./list-parent.component.css']
})
export class ListParentComponent implements OnInit {

  dataSaved = false;
  parentForm: any;
  allParents: Observable<Parent[]>;
  parentIdUpdate = null;
  message = null;

  constructor(private formbulider: FormBuilder, private parentService: ParentService, private routes:Router) { }

  ngOnInit() {  
    this.parentForm = this.formbulider.group({
      parentName: ['', [Validators.required]],
      profession: ['', [Validators.required]],
      nid: ['', [Validators.required]],
      isActive: [''],
    });
    this.loadAllParents();
    console.log("ID = "+this.parentIdUpdate);

  }

  loadAllParents() {
    this.allParents = this.parentService.getAllParent();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const parent = this.parentForm.value;
    this.CreateParent(parent);
    this.parentForm.reset();
  }

  loadParentToEdit(parentid: any) {
    this.parentService.getParentById(parentid).subscribe(parent => {
      this.message = null;
      this.dataSaved = false;
      this.parentIdUpdate = parent.parentID;
      this.parentForm.get('parentName').setValue(parent["parentName"]);
      this.parentForm.get('profession').setValue(parent["profession"]);
      this.parentForm.get('nid').setValue(parent["nid"]);
    });
  }



  CreateParent(parent: Parent) {
    if (this.parentIdUpdate == null) {
      this.parentService.createParent(parent).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllParents();
          this.parentIdUpdate = null;
          this.parentForm.reset();
        }
      );
    }
    else {
      parent.ParentID = this.parentIdUpdate;
      this.parentService.updateParent(parent).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllParents();
        this.parentIdUpdate = null;
        this.parentForm.reset();
      });
    }
  }

  deleteParent(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.parentService.deleteParentById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllParents();
        this.parentIdUpdate = null;
        this.parentForm.reset();
      });
    }
  }

  resetForm() {
    this.parentForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  
  
}
