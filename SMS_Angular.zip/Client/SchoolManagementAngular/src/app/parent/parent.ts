export class Parent {
  ParentID: any;
  ParentName: string;
  Profession: string;
  NID: string;
  IsActive: boolean;
}
