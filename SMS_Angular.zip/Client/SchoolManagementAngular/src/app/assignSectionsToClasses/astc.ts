export class ClassSection {
  ID:any;
    SClassID:any;
    ClassName:string;
    ClassName_Numeric:any;
    SectionID: any;
    SectionName: string;
    NickName: string;
    IsActive: boolean;
  }