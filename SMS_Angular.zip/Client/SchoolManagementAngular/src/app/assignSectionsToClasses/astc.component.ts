import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { AstcService} from './astc.service';
import { ClassSection} from './astc';
import { Router } from '@angular/router';


@Component({
  selector: 'app-astc',
  templateUrl: './astc.component.html',
  styleUrls: ['./astc.component.css']
})
export class AstcComponent implements OnInit {

  dataSaved = false;
  astcForm: any;
  modalForm: any;
  editForm:any;
  getClasses:{};
  getClassesIU:{};
  getSections:{};
  getSectionsIU:{};
  getClassesModal:{};
  classSectionIdUpdate=null;
  message = null;



  constructor(private formbulider: FormBuilder, private astcService: AstcService, private routes:Router) { }

  ngOnInit() {

    this.astcForm = this.formbulider.group({
      
      
      sclass:[''],
      section:[''],
      

    });


    this.modalForm=this.formbulider.group({
      sClassID:[''],
      sectionID:['']
    });

    this.editForm=this.formbulider.group({
      sClassID:[''],
      sectionID:['']
    })
  
  this.loadClasses();
  this.loadClassesIU();

  }

  loadClasses(){
    this.astcService.getClasses().subscribe(data=>
      this.getClasses=data,
      
      );
  }


  loadClassesIU(){
    this.astcService.getClasses().subscribe(data=>
      this.getClassesIU=data,
      
      );
  }

  onFormSubmit() {
    this.dataSaved = false;
    const classSection = this.modalForm.value;
    this.AssignSection(classSection);
    this.astcForm.reset();
    console.log(this.modalForm.value);
  }


  loadSectionToEdit(id: any) {
    this.astcService.getSectionById(id).subscribe(classSection => {
      this.message = null;
      this.dataSaved = false;
      this.classSectionIdUpdate = classSection.classSectionID;
      this.editForm.get('sClassID').setValue(classSection["sClassID"]);
      this.editForm.get('sectionID').setValue(classSection["sectionID"]);


    });
  }

  AssignSection(classSection: ClassSection) {
    if (this.classSectionIdUpdate == null) {
      this.astcService.assignSection(classSection).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadClasses();
          this.classSectionIdUpdate = null;
          this.modalForm.reset();
        }
      );
    }
    else {
      classSection.ID = this.classSectionIdUpdate;
      this.astcService.updateClassSection(classSection).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadClasses();
        this.classSectionIdUpdate = null;
        this.modalForm.reset();
      });
    }
  }


  onChangeClass(sClassID:any){
    if(sClassID){
      this.astcService.getSections(sClassID).subscribe(section=>{
      this.getSections=section;
      });
    }
    else{
      this.getSections=null;
    }
  }

  onChangeClasses(sClassID:any){
    if(sClassID){
      this.astcService.getSectionsIU(sClassID).subscribe(section=>{
      this.getSectionsIU=section;
      });
    }
    else{
      this.getSectionsIU=null;
    }
  }


  resetForm() {
    this.astcForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
