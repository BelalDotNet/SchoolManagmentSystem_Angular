import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ClassSection } from './astc';


@Injectable({
  providedIn: 'root'
})
export class AstcService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getClasses(){
    return this._http.get(this.url+'/ClassSectionApi/GetAllClasses');
  }


  getSections(classid:any){
    return this._http.get(this.url+'/ClassSectionApi/GetAllSectionsForSpecificClass/'+classid);
  }


  getSectionsIU(classid:any){
    return this._http.get(this.url+'/ClassSectionApi/GetAllSectionsForSpecificClassIU/'+classid);
  }

  getSectionById(id: any): Observable<any> {
    return this._http.get<ClassSection>(this.url + '/ClassSectionApi/GetClassSectionById/' + id);
  }


  assignSection(classSection: ClassSection): Observable<ClassSection> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<ClassSection>(this.url + '/ClassSectionApi/AssignClass', classSection, httpOptions);
  }


  updateClassSection(classSection: ClassSection): Observable<ClassSection> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<ClassSection>(this.url + '/ClassSectionApi/UpdateClassSection', classSection, httpOptions);
  }
}
