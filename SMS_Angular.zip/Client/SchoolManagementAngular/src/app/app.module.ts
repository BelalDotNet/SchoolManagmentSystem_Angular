import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule, MatMenuModule, MatDatepickerModule, MatNativeDateModule, MatIconModule, MatCardModule, MatSidenavModule, MatFormFieldModule,
  MatInputModule, MatTooltipModule, MatToolbarModule
} from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListParentComponent } from './parent/list-parent.component';
import { DashboardComponent } from './admin/dashboard.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule} from '@angular/common/http';
import { ParentService } from './parent/parent.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PublicComponent } from './layout/public/public.component';
import { SecureComponent } from './layout/secure/secure.component';
import { PublicRoutingModule } from './layout/public/public-routing.module';
import { SecureRoutingModule } from './layout/secure/secure-routing.module';
import { RootComponent } from './root/root.component';
import { AngularFontAwesomeModule}from 'angular-font-awesome';
import { DynamicScriptLoaderServiceService}from '../app/service/dynamic-script-loader-service.service';

import { from } from 'rxjs';
import { StudentComponent } from './student/student.component';
import { ClerkComponent } from './clerk/clerk.component';
import { ClassComponent } from './class/class.component';
import { TeacherComponent } from './teacher/teacher.component';
import { MarkComponent } from './mark/mark.component';
import { SectionComponent } from './section/section.component';
import { AstcComponent } from './assignSectionsToClasses/astc.component';
import { AssignStudentComponent } from './assignStudentsToClasses/assign-student.component';
import { ExamComponent } from './exam/exam.component';
import { AssignTeacherComponent } from './assignTeacherToClasses/assign-teacher.component';
import { SubjectComponent } from './subject/subject.component';
import { GradeComponent } from './grade/grade.component';
import { NoticeComponent } from './notice/notice.component';
import { NoticeGenerateComponent } from './notice/notice-generate.component';
@NgModule({
  declarations: [
    AppComponent,
    ListParentComponent,
    DashboardComponent,
    HomeComponent,
    PublicComponent,
    SecureComponent,
    RootComponent,
    StudentComponent,
    ClerkComponent,
    ClassComponent,
    TeacherComponent,
    MarkComponent,
    SectionComponent,
    AstcComponent,
    AssignStudentComponent,
    ExamComponent,
    AssignTeacherComponent,
    SubjectComponent,
    GradeComponent,
    NoticeComponent,
    NoticeGenerateComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatRadioModule,
    MatCardModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatToolbarModule,
    PublicRoutingModule,
    SecureRoutingModule,
    AngularFontAwesomeModule
  ],
  providers: [ParentService, HttpClientModule, MatDatepickerModule, DynamicScriptLoaderServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
