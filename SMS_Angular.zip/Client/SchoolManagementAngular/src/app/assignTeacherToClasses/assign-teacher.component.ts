import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { AssignTeacherService} from './assign-teacher.service';
import { AssignTeacherToClass} from './assign-teacher';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assign-teacher',
  templateUrl: './assign-teacher.component.html',
  styleUrls: ['./assign-teacher.component.css']
})
export class AssignTeacherComponent implements OnInit {

  dataSaved = false;
  assignTeacherForm: any;
  message = null;
  getTeachers:{};
  getClasses:{};
  getSections:{};
  classesid=null;
  sectionsid=null;
  getClassSectionId=null;
  teacherIdUpdate=null;

  constructor(private formbulider: FormBuilder, private assignTeacherService: AssignTeacherService, private routes:Router) { }

  ngOnInit() {

    this.assignTeacherForm = this.formbulider.group({
      
      teacherID:[''],
      sClassID:[''],
      sectionID:[''],
      isClassTeacher:[''],
      classSectionID:['']
      

  });

  this.loadClasses();

  }


  loadClasses(){
    this.assignTeacherService.getClasses().subscribe(data=>
      this.getClasses=data
      );
  }


  onChangeClass(sClassID:any){
    this.classesid=sClassID;
    if(sClassID){
      this.assignTeacherService.getSections(sClassID).subscribe(section=>{
      this.getSections=section;
     
      });
    }
    else{
      this.getSections=null;
     
    }
  }



  onChangeSection(sectionID: any){
    this.sectionsid=sectionID;
    if(sectionID){
      this.assignTeacherService.getClassSectionId(this.classesid, sectionID).subscribe(data=>{
        this.assignTeacherForm.get('classSectionID').setValue(data);
        
        this.assignTeacherService.getTeachers(data).subscribe(data=>
          this.getTeachers=data
          );


      });
    }
    else{
      this.getClassSectionId=null;
      this.getTeachers=null;
    }
  }


  onFormSubmit() {
    this.dataSaved = false;
    const teacher = this.assignTeacherForm.value;
    this.AssignTeacher(teacher);
    this.assignTeacherForm.reset();
  }


  AssignTeacher(teacher: AssignTeacherToClass) {
    if (this.teacherIdUpdate == null) {
      this.assignTeacherService.assignTeacher(teacher).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.teacherIdUpdate = null;
          this.assignTeacherForm.reset();
         
        }
      );   
    }
    else {
      teacher.ID = this.teacherIdUpdate;
      this.assignTeacherService.updateAssignTeacher(teacher).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.teacherIdUpdate = null;
        this.assignTeacherForm.reset();
      });
    }
  }



  resetForm() {
    this.assignTeacherForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
