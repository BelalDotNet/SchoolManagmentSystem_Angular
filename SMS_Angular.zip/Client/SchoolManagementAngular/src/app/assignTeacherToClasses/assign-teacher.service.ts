import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AssignTeacherToClass } from './assign-teacher';

@Injectable({
  providedIn: 'root'
})
export class AssignTeacherService {
  
  url = localStorage.getItem('url');

  constructor(private _http: HttpClient) { }

  getClasses(){
    return this._http.get(this.url+'/AssignTeacherToClassApi/GetClasses');
  }

  getSections(classid:any){
    return this._http.get(this.url+'/AssignTeacherToClassApi/GetSections/'+classid);
  }

  getClassSectionId(classid:any, sectionid:any){
    return this._http.get(this.url+'/AssignTeacherToClassApi/GetClassSectionId/'+classid+'/'+sectionid);

  }


  getTeachers(id:any){
    return this._http.get(this.url+'/AssignTeacherToClassApi/GetTeachers/'+id);
  }

  assignTeacher(student: AssignTeacherToClass): Observable<AssignTeacherToClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<AssignTeacherToClass>(this.url + '/AssignTeacherToClassApi/AssignTeacher/', student, httpOptions);
    console.log(student);
  }

  updateAssignTeacher(student: AssignTeacherToClass): Observable<AssignTeacherToClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<AssignTeacherToClass>(this.url + '/AssignTeacherToClassApi/UpdateAssignTeacher', student, httpOptions);
  }

}
