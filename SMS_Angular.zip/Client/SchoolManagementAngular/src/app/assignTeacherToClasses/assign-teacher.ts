export class AssignTeacherToClass {
    ID:any;
    ClassSectionID:any;
    TeacherID:any;
    IsClassTeacher:any;
    }