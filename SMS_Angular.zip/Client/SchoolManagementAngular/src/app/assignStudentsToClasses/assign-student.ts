export class AssignStudentToClass {
    ID:any;
    RollNo:any;
    SessionYear:string;
    StudentID:any;
    ClassSectionID:any;
    PresentStatus:string;
    }