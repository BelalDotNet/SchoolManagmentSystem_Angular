import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AssignStudentToClass } from './assign-student';

@Injectable({
  providedIn: 'root'
})
export class AssignStudentService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getStudents(){
    return this._http.get(this.url+'/AssignStudentToClassApi/GetStudents');
  }


  getClasses(){
    return this._http.get(this.url+'/AssignStudentToClassApi/GetClasses');
  }

  getSections(classid:any){
    return this._http.get(this.url+'/AssignStudentToClassApi/GetSections/'+classid);
  }


  getClassSectionId(classid:any, sectionid:any){
    return this._http.get(this.url+'/AssignStudentToClassApi/GetClassSectionId/'+classid+'/'+sectionid);

  }


  assignStudent(student: AssignStudentToClass): Observable<AssignStudentToClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<AssignStudentToClass>(this.url + '/AssignStudentToClassApi/AssignStudent/', student, httpOptions);
    console.log(student);
  }

  updateAssignStudent(student: AssignStudentToClass): Observable<AssignStudentToClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<AssignStudentToClass>(this.url + '/AssignStudentToClassApi/UpdateAssignStudent', student, httpOptions);
  }


}
