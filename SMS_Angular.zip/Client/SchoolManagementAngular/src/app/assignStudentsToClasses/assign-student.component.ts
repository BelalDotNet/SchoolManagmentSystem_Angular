import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { AssignStudentService} from './assign-student.service';
import { AssignStudentToClass} from './assign-student';
import { Router } from '@angular/router';


@Component({
  selector: 'app-assign-student',
  templateUrl: './assign-student.component.html',
  styleUrls: ['./assign-student.component.css']
})
export class AssignStudentComponent implements OnInit {
  dataSaved = false;
  assignStudentForm: any;
  message = null;
  getStudents:{};
  getClasses:{};
  getSections:{};
  classesid=null;
  sectionsid=null;
  getClassSectionId=null;
  studentIdUpdate=null;

  constructor(private formbulider: FormBuilder, private assignStdentService: AssignStudentService, private routes:Router) { }

  ngOnInit() {

    this.assignStudentForm = this.formbulider.group({
      
      studentID:[''],
      sClassID:[''],
      sectionID:[''],
      sessionYear:[''],
      classSectionID:[''],
      rollNo:['']
      

  });

  this.loadStudents();
  

  }

  
  loadStudents(){
    this.assignStdentService.getStudents().subscribe(data=>
      this.getStudents=data
      );
  }

  onChangeStudent(studentID:any){
    this.assignStdentService.getClasses().subscribe(data=>
      this.getClasses=data
      );
  }

  onChangeClass(sClassID:any){
    this.classesid=sClassID;
    if(sClassID){
      this.assignStdentService.getSections(sClassID).subscribe(section=>{
      this.getSections=section;
     
      });
    }
    else{
      this.getSections=null;
     
    }
  }

  onChangeSection(sectionID: any){
    this.sectionsid=sectionID;
    if(sectionID){
      this.assignStdentService.getClassSectionId(this.classesid, sectionID).subscribe(data=>{
        this.assignStudentForm.get('classSectionID').setValue(data);
        this.getClassSectionId=data;
        console.log(data);
      });
    }
    else{
      this.getClassSectionId=null;
      
    }
  }

  onFormSubmit() {
    this.dataSaved = false;
    const student = this.assignStudentForm.value;
    this.AssignStudent(student);
    this.assignStudentForm.reset();
  }

  AssignStudent(student: AssignStudentToClass) {
    if (this.studentIdUpdate == null) {
      this.assignStdentService.assignStudent(student).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.studentIdUpdate = null;
          this.assignStudentForm.reset();
        }
      );   
    }
    else {
      student.ID = this.studentIdUpdate;
      this.assignStdentService.updateAssignStudent(student).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.studentIdUpdate = null;
        this.assignStudentForm.reset();
      });
    }
  }



  resetForm() {
    this.assignStudentForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
