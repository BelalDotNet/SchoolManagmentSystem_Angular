export class Mark {
    MarkID: any;
    ClassSectionID: any;
    SubjectID: any;
    ExamID: any;
    PassingYear: string;
    AssignStudentToClassID:any;
    ObtainedMark:any;
    SubjectMark:any;
    GradeID:any;
    EntryBy:string;
    EntryDate:any;
  }