import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { MarkService } from './mark.service';
import { Mark } from './mark';
import { Router } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';


@Component({
  selector: 'app-mark',
  templateUrl: './mark.component.html',
  styleUrls: ['./mark.component.css']
})
export class MarkComponent implements OnInit {

  dataSaved = false;
  markForm: any;
  allMarks: Observable<Mark[]>;
  studentIdUpdate = null;
  classid = null;
  message = null;
  classesid = null;
  sectionsid = null;
  classSectionId=null;
  studentAssignId=null;
  studentid=null;
  examid = null;
  subjectid = null;
  getExams: {};
  getClasses: {};
  getSections: {};
  getStudents: {};
  getSubjects: {};
  constructor(private formbulider: FormBuilder, private markService: MarkService, private routes: Router) { }
  

  ngOnInit() {

    this.markForm = this.formbulider.group({
      sClassID: [''],
      sectionID: [''],
      examID: [''],
      subjectID: ['']
  });
    this.loadExams();
    
  }

  loadExams() {
    this.markService.getExams().subscribe(data =>
      this.getExams = data
    );
  }


 onChangeExam(examID:any){
   if(examID>=1){
    this.markService.getClasses().subscribe(data =>
      this.getClasses = data
    );
   }
   else{
     this.getClasses=null
   }
  
 }


  onChangeClass(sClassID: any) {
    this.classesid = sClassID;
    if (sClassID) {
      this.markService.getSections(sClassID).subscribe(section => {
        this.getSections = section;
        this.getStudents = null;
      });
      
    }
    else {
      this.getSections = null;
      this.getSubjects = null;
      this.getStudents = null;
    }
  }

onChangeSection(sectionID:any){
  this.sectionsid=sectionID;
  this.markService.getSubjects(this.classesid).subscribe(subject => {
    this.getSubjects = subject;
    this.getStudents = null;
  });
}


  onChangeSubject(subjectID: any) {
    if (subjectID) {
      this.markService.getStudentToInsertMark(this.classesid,this.sectionsid).subscribe(data => {
        this.getStudents = data;
       

      });

      this.markService.getClassSectionID(this.classesid, this.sectionsid).subscribe(data=>{
        this.classSectionId=data;
      })

     
      
    }
    else {
      this.getStudents = null;
    }
  }

  getAssignStudent(studentID:any, year:string, classSectionID:any){
    this.markService.getAssignStudentID(studentID, year, classSectionID).subscribe(data=>{
      this.studentid=data;
    })
  }


  //onFormSubmit() {
  //  this.dataSaved = false;
  //  const mark = this.markForm.value;
  //  this.CreateMark(mark);
  //  this.markForm.reset();
  //}

  resetForm() {
    this.markForm.reset();
    this.message = null;
    this.dataSaved = false;
  } 

}
