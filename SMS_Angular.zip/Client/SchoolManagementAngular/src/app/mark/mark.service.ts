import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Mark } from './mark';

@Injectable({
  providedIn: 'root'
})
export class MarkService {
  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getStudentToInsertMark(id: any, secid: any): Observable<Mark[]> {
    return this._http.get<Mark[]>(this.url + '/MarkApi/GetStudentToInsertMark/'+ id+'/'+secid);
  }

  getExams() {
    return this._http.get(this.url + '/MarkApi/GetExams');
  }

  getClasses() {
    return this._http.get(this.url + '/MarkApi/GetClasses');
  }

  getSections(classid: any) {
    return this._http.get(this.url + '/MarkApi/GetSections/' + classid);
  }

  getSubjects(classid: any) {
    return this._http.get(this.url + '/MarkApi/GetSubjects/' + classid);
  }

  createMark(mark: Mark): Observable<Mark> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Mark>(this.url + '/MarkApi/InsertMark/', mark, httpOptions);
  }

  updateStudent(parent: Mark): Observable<Mark> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Mark>(this.url + '/MarkApi/UpdateStudent', parent, httpOptions);
  }

  deleteStudentById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/MarkApi/DeleteStudent/' + id,
      httpOptions);
  }

  getClassSectionID(classid:any, sectionID:any){
    return this._http.get(this.url+'/MarkApi/GetClassSectionID/'+classid+'/'+sectionID);
  }

  getAssignStudentID(studentID:any, year:string, classSectionID:any){
    return this._http.get(this.url+'/MarkApi/GetAssignStudentID/'+studentID+'/'+year+'/'+classSectionID);
  }

}
