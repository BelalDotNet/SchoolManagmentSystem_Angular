import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { GradeService} from './grade.service';
import { Grade} from './grade';
import { Router } from '@angular/router';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit {
  dataSaved = false;
  gradeForm: any;
  allGrades: Observable<Grade[]>;
  gradeIdUpdate = null;
  message = null;
  getgrades={};

  constructor(private formbulider: FormBuilder, private gradeService: GradeService, private routes:Router) { }

  ngOnInit() {
    this.gradeForm = this.formbulider.group({
      gradeRange: ['', [Validators.required]],
      gradePoint: ['', [Validators.required]],
      gradeName: ['', [Validators.required]],
      comment: ['', [Validators.required]],
      
    });
    this.loadAllGrades();
  }

  loadAllGrades() {
    this.getgrades = this.gradeService.getAllGrades();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const grade = this.gradeForm.value;
    this.CreateGrade(grade);
    this.gradeForm.reset();
  }

  loadGradeToEdit(gradeID: any) {
    this.gradeService.getGradeById(gradeID).subscribe(grade => {
      this.message = null;
      this.dataSaved = false;
      this.gradeIdUpdate = grade.gradeID;
      this.gradeForm.get('gradeRange').setValue(grade["gradeRange"]);
      this.gradeForm.get('gradePoint').setValue(grade["gradePoint"]);
      this.gradeForm.get('gradeName').setValue(grade["gradeName"]);
      this.gradeForm.get('comment').setValue(grade["comment"]);
     

    });
  }

  CreateGrade(grade: Grade) {
    if (this.gradeIdUpdate == null) {
      this.gradeService.createGrade(grade).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllGrades();
          this.gradeIdUpdate = null;
          this.gradeForm.reset();
        }
      );
    }
    else {
      grade.GradeID = this.gradeIdUpdate;
      this.gradeService.updateGrade(grade).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllGrades();
        this.gradeIdUpdate = null;
        this.gradeForm.reset();
      });
    }
  }

  deleteGrade(gradeID: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.gradeService.deleteGradeById(gradeID).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllGrades();
        this.gradeIdUpdate = null;
        this.gradeForm.reset();
      });
    }
  }

  resetForm() {
    this.gradeForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
