import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Grade } from './grade';


@Injectable({
  providedIn: 'root'
})
export class GradeService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getAllGrades(): Observable<Grade[]> {
    return this._http.get<Grade[]>(this.url + '/GradeApi/GetGrades');
  }

  getGradeById(id: any): Observable<any> {
    return this._http.get<Grade>(this.url + '/GradeApi/GetGradebyId/' + id);
  }

  createGrade(grade: Grade): Observable<Grade> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Grade>(this.url + '/GradeApi/InsertGrade/', grade, httpOptions);
  }

  updateGrade(grade: Grade): Observable<Grade> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Grade>(this.url + '/GradeApi/UpdateGrade', grade, httpOptions);
  }

  deleteGradeById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/GradeApi/DeleteGradeById/' + id, httpOptions);
  }
}
