export class Grade{
    GradeID:number;
    GradeRange:string;
    GradePoint:number;
    GradeName:string;
    Comment:string;
}