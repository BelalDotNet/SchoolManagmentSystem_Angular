import { Component, OnInit } from '@angular/core';

import{DynamicScriptLoaderServiceService}from '../app/service/dynamic-script-loader-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'School Management';
constructor (private jsService:DynamicScriptLoaderServiceService){

}
  ngOnInit(){
this.loadScripts();
  }
  private loadScripts() {
    // You can load multiple scripts by just providing the key as argument into load method of the service
    this.jsService.load("jquery","bootstrap","slimscroll","mainjs","chartist","sparkline","raphael","morris","c3","d3","c3Chart","dash","modern").then(data => {
      // Script Loaded Successfully
    }).catch(error => console.log(error));
}}
