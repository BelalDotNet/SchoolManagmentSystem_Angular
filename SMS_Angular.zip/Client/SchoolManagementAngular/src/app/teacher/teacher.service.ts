import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserTeacherVM } from './teacher';

@Injectable({
  providedIn: 'root'
})

export class TeacherService {

  url = localStorage.getItem('url');

  constructor(private _http: HttpClient) { }

  getAllTeacher(): Observable<UserTeacherVM[]> {
    return this._http.get<UserTeacherVM[]>(this.url + '/TeacherApi/GetTeachers');
  }

  getClasses(){
    return this._http.get(this.url+'/TeacherApi/GetClasses');
  }

  getSections(classid:any){
    return this._http.get(this.url+'/TeacherApi/GetSections/'+classid);
  }

  getTeacherById(id: any): Observable<any> {
    return this._http.get<UserTeacherVM>(this.url + '/TeacherApi/GetDataForEdit/' + id);
  }
  getTeacherByClassSection(id: any, secid: any) {
    return this._http.get(this.url + '/TeacherApi/GetTeacherForSpecificClass/' + id+'/'+secid);
  }


  createTeacher(teacher: UserTeacherVM){
    return this._http.post(this.url + '/TeacherApi/InsertTeacher', teacher);
  }

  updateTeacher(teacher: UserTeacherVM){
    return this._http.put(this.url + '/TeacherApi/UpdateTeacher', teacher);
  }

  deleteTeacherById(id: string) {
    return this._http.delete(this.url + '/TeacherApi/DeleteTeacher/' + id);
  }


}
