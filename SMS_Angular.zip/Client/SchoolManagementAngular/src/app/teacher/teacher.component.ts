import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators ,FormGroup} from '@angular/forms';
import { Observable} from 'rxjs';
import { TeacherService} from './teacher.service';
import { UserTeacherVM} from './teacher';
import { Router } from '@angular/router';


@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {

  imageUrl: string = "/assets/images/ForUpload/download.png";
  fileToUpload: File = null;
  dataSaved = false;
  teacherForm: any;
  insertForm:any;
  allTeachers: Observable<UserTeacherVM[]>;
  teacherIdUpdate = null;
  classid=null;
  message = null;
  classesid=null;
  sectionsid=null;
  getClasses:{};
  getParent:{};
  getSections:{};
  getTeachers:{};

  constructor(private formbulider: FormBuilder, private teacherService: TeacherService, private routes:Router) { }

  ngOnInit() {

    this.teacherForm = this.formbulider.group({
      
    });
  



    this.insertForm = this.formbulider.group({
      name:['', [Validators.required]],      
      designation:['', [Validators.required]],      
      email: [''],
      password: [''],
      confirmPassword: [''],
      phoneNumber:[''],
      nid: ['', [Validators.required]],
      dob:['', [Validators.required]],
      gender:['', [Validators.required]],
      address:['', [Validators.required]],
      image:[''],
      isActive:[''],
      applicationUserID:['']

    });

    this.loadTeachers();
  }



  
  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
     //Show image preview
     var reader = new FileReader();
     reader.onload = (event:any) => {
       this.imageUrl = event.target.result;
     }
     reader.readAsDataURL(this.fileToUpload);

  }

  onFormSubmit() {
    this.dataSaved = false;
    this.insertForm.get('image').setValue('TestString');
    this.insertForm.get('applicationUserID').setValue('1');
    const teacher = this.insertForm.value;
    this.CreateTeacher(teacher);
    this.teacherForm.reset();
  }

  

  loadTeacherToEdit(teacherID: any) {
    this.teacherService.getTeacherById(teacherID).subscribe(teacher => {
      this.message = null;
      this.dataSaved = false;
      this.teacherIdUpdate = teacher.teacherID;
      this.insertForm.get('name').setValue(teacher["name"]);
      this.insertForm.get('nid').setValue(teacher["nid"]);
      this.insertForm.get('dob').setValue(teacher["dob"]);
      this.insertForm.get('gender').setValue(teacher["gender"]);
      this.insertForm.get('address').setValue(teacher["address"]);
      this.insertForm.get('image').setValue(teacher["image"]);
      this.insertForm.get('parentName').setValue(teacher["parentName"]);
      this.insertForm.get('designation').setValue(teacher["designation"]);

    });
  }



  CreateTeacher(teacher: UserTeacherVM) {
    if (this.teacherIdUpdate == null) {
      this.teacherService.createTeacher(teacher).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadTeachers();
          this.teacherIdUpdate = null;
          this.insertForm.reset();
        }
      );   
    }
    else {
      teacher.TeacherID = this.teacherIdUpdate;
      this.teacherService.updateTeacher(teacher).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadTeachers();
        this.teacherIdUpdate = null;
        this.insertForm.reset();
      });
    }
  }




  deleteTeacher(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.teacherService.deleteTeacherById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadTeachers();
        this.teacherIdUpdate = null;
        this.teacherForm.reset();
      });
    }
  }


  loadTeachers() { 
      this.teacherService.getAllTeacher().subscribe(data=>{
      this.getTeachers=data;
    });
  }


  resetForm() {
    this.insertForm.reset();
    this.message = null;
    this.dataSaved = false;
  } 

}
