export class UserTeacherVM{
    Email:string;
    Password:string;
    ConfirmPassword:string;
    PhoneNumber:string;

    TeacherID:any;
    Name:string;
    NID:string;
    DOB:Date;
    Gender:string;
    Address:string;
    Designation:string;
    ApplicationUserID:string;
    Image:string;
    IsActive:boolean
}