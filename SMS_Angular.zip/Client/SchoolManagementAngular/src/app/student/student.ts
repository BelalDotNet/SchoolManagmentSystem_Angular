export class UserStudentVM{
    Email:string;
    Password:string;
    ConfirmPassword:string;
    PhoneNumber:string;

    StudentID:any;
    StudentRegID:string;
    Name:string;
    NID:string;
    DOB:Date;
    Gender:string;
    Address:string;
    ParentID:any;
    ParentName:string;
    Image:string;
    IsActive:boolean
    ImageFile:File;
}