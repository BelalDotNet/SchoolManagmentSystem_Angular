import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpEvent, HttpEventType } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { UserStudentVM } from './student';
import { catchError, map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class StudentService {
  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }


  upload(formData){
    return this._http.post('${this.url}'+'/StudentApi/upload',formData, {
      reportProgress:true,
      observe:'events'
    }).pipe(
      map(event=>this.getEventMessage(event, formData)),
      catchError(this.hadleError)
    );

  }

  private getEventMessage(event:HttpEvent<any>, formData){
    switch(event.type){
      case HttpEventType.UploadProgress:
        return this.fileUploadProgress(event);
      case HttpEventType.Response:
        return this.apiResponse(event);
      default:
        return 'File "${formData.get("profile").name}" surprising upload event:';
    }
  }

  private fileUploadProgress(event){
    const percentDone=Math.round(100*event.loaded/event.total);
    return {status:'progress', message:percentDone};
  }

  private apiResponse(event){
    return event.body;
  }


  private hadleError(error:HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.error('An error occured:', error.error.message);
    }else{
      console.error('Backend returned code ${error.status},'+'body was: ${error.error.message}');
    }
    return throwError('Something bad happened. Please try again later.');
  }

  getAllStudent(): Observable<UserStudentVM[]> {
    return this._http.get<UserStudentVM[]>(this.url + '/StudentApi/GetStudents');
  }

  getClasses(){
    return this._http.get(this.url+'/StudentApi/GetClasses');
  }

  getParents(){
    return this._http.get(this.url+'/StudentApi/GetParents');
  }


  getSections(classid:any){
    return this._http.get(this.url+'/StudentApi/GetSections/'+classid);
  }

  getStudentById(id: any): Observable<any> {
    return this._http.get<UserStudentVM>(this.url + '/StudentApi/GetDataForEdit/' + id);
  }

  getStudent() {
    return this._http.get(this.url + '/StudentApi/GetStudent/');
  }


  getStudentByClass(id: any) {
    return this._http.get(this.url + '/StudentApi/GetStudentForClass/' + id);
  }


  getStudentByClassSection(id: any, secid: any) {
    return this._http.get(this.url + '/StudentApi/GetStudentForSpecificClass/' + id+'/'+secid);
  }


  createStudent(student: UserStudentVM){
    return this._http.post(this.url + '/StudentApi/InsertStudent/', student);
    console.log(student);
  }


  

  updateStudent(student: UserStudentVM){ 
    return this._http.put(this.url + '/StudentApi/UpdateStudent', student);
  }

  deleteStudentById(id: string){
    return this._http.delete(this.url + '/StudentApi/DeleteStudent/' + id);
  }


  postFile(student:UserStudentVM) {
    const endpoint = this.url+'/StudentApi/UploadImage/';
    return this._http
      .post(endpoint, student);
  }


}
