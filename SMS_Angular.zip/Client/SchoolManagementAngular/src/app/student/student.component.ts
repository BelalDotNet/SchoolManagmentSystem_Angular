import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators ,FormGroup} from '@angular/forms';
import { Observable} from 'rxjs';
import { StudentService} from './student.service';
import { UserStudentVM} from './student';
import { Router } from '@angular/router';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
  providers: [StudentService]

})
export class StudentComponent implements OnInit {
  imageUrl: string = "/assets/images/ForUpload/download.png";
  fileToUpload: File = null;
  dataSaved = false;
  studentForm: any;
  imageForm:FormGroup;
  signUpForm:any;
  insertForm:any;
  allStudents: Observable<UserStudentVM[]>;
  studentIdUpdate = null;
  classid=null;
  message = null;
  classesid=null;
  sectionsid=null;
  getClasses:{};
  getParent:{};
  getSections:{};
  getStudents:{};
  studentImage=null;
  profileForm:FormGroup;

  constructor(private formbulider: FormBuilder, private studentService: StudentService, private routes:Router) { }

  ngOnInit() {

    this.insertForm = this.formbulider.group({    
     
      name:[''],      
      email: [''],
      password: [''],
      confirmPassword: [''],
      phoneNumber:[''],
      studentRegID:[''],
      nid: [''],
      dob:[''],
      gender:[''],
      address:[''],
      parentID:[''],
      image:[''],
      applicationUserID:[''],
      isActive:['']

    });

    
    this.studentForm = this.formbulider.group({  
      sClassID:[''],
      sectionID:[''] 
    })

    this.imageForm=this.formbulider.group({
      caption:[''],
      imageName:['']
    })
    

    this.profileForm=this.formbulider.group({
      name:[''],
      profile:['']
    })
  
    this.loadClasses();
    this.loadParents();
    this.loadStudents();
  }


  onSelectedFile(event){
    if (event.target.files.length>0){
      const profile=event.target.files[0];
      this.profileForm.get('profile').setValue(profile);
    }
  }


  

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
     //Show image preview
     var reader = new FileReader();
     reader.onload = (event:any) => {
       this.imageUrl = event.target.result;
     }
     reader.readAsDataURL(this.fileToUpload);

  }

  OnSubmit(){

  }


  




  loadClasses(){
    this.studentService.getClasses().subscribe(data=>
      this.getClasses=data
      );
  }


  loadStudents(){
    this.studentService.getStudent().subscribe(data=>
      this.getStudents=data
      );
  }


  loadParents(){
    this.studentService.getParents().subscribe(data=>
      this.getParent=data
      );
  }


  onChangeClass(sClassID:any){
    this.classesid=sClassID;
    if(sClassID){
      this.studentService.getSections(sClassID).subscribe(section=>{
      this.getSections=section;
      });

      this.studentService.getStudentByClass(sClassID).subscribe(data=>
        this.getStudents=data
        );
    }
    else{
      this.getSections=null;

      this.studentService.getStudent().subscribe(data=>
        this.getStudents=data
        );

      
    }
  }


  onChangeSection(sectionID: any){
    if(sectionID){
      console.log(this.classesid, sectionID);
      this.studentService.getStudentByClassSection(this.classesid, sectionID).subscribe(data=>{
        this.getStudents=data;
      });
    }
    else{
      this.studentService.getStudentByClass(this.classesid).subscribe(data=>
        this.getStudents=data
        );
    }
  }

  

 


  onFormSubmit(){

    this.dataSaved = false;
    this.insertForm.get('image').setValue('TestString');
    this.insertForm.get('applicationUserID').setValue('1');
    const student = this.insertForm.value;
    
    this.CreateStudent(student);
    this.insertForm.reset();
  }




  loadStudentToEdit(studentID: any) {
    this.studentService.getStudentById(studentID).subscribe(student => {
      this.message = null;
      this.dataSaved = false;
      this.studentIdUpdate = student.studentID;
      this.insertForm.get('name').setValue(student["name"]);
      this.insertForm.get('nid').setValue(student["nid"]);
      this.insertForm.get('dob').setValue(student["dob"]);
      this.insertForm.get('gender').setValue(student["gender"]);
      this.insertForm.get('address').setValue(student["address"]);
      this.insertForm.get('image').setValue(student["image"]);
      this.insertForm.get('parentID').setValue(student["parentID"]);
      this.insertForm.get('studentRegID').setValue(student["studentRegID"]);


    });
  }



  CreateStudent(student : UserStudentVM) {
    if (this.studentIdUpdate == null) {

      this.studentService.createStudent(student).subscribe(
          () => {
            this.dataSaved = true;
            this.message = 'Record saved Successfully';
            this.loadStudents();
            this.insertForm.reset();
          }
        );
  
      } else {
        student.StudentID = this.studentIdUpdate;
        this.studentService.updateStudent(student).subscribe(() => {
          this.dataSaved = true;
          this.message = 'Record Updated Successfully';
          this.loadStudents();
          this.studentIdUpdate = null;
          this.studentForm.reset();
        });
      }
        
    
  }

  deleteStudent(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.studentService.deleteStudentById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadStudents();
        this.studentIdUpdate = null;
        this.insertForm.reset();
      });
    }
  }

  
  resetForm() {
    this.insertForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  
}
