import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SClass } from './class';



@Injectable({
  providedIn: 'root'
})
export class ClassService {
  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }


  getAllClass(): Observable<SClass[]> {
    return this._http.get<SClass[]>(this.url + '/ClassApi/GetClasses');
  }

  getClassById(id: any): Observable<any> {
    return this._http.get<SClass>(this.url + '/ClassApi/GetClassById/' + id);
  }


  createClass(parent: SClass): Observable<SClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<SClass>(this.url + '/ClassApi/InsertClass/', parent, httpOptions);
  }

  updateClass(parent: SClass): Observable<SClass> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<SClass>(this.url + '/ClassApi/UpdateClass', parent, httpOptions);
  }

  deleteClassById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/ClassApi/DeleteClass/' + id,
      httpOptions);
  }
}
