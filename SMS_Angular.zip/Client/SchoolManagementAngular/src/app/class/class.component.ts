import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { ClassService} from './class.service';
import { SClass} from './class';
import { Router } from '@angular/router';

@Component({
  selector: 'app-class',
  templateUrl: './class.component.html',
  styleUrls: ['./class.component.css']
})
export class ClassComponent implements OnInit {

  dataSaved = false;
  classForm: any;
  allClasses: Observable<SClass[]>;
  classIdUpdate = null;
  message = null;
  getClasses:{};

  constructor(private formbulider: FormBuilder, private classService: ClassService, private routes:Router) { }

  ngOnInit() {

    this.classForm = this.formbulider.group({
      className: ['', [Validators.required]],
      className_Numeric: ['', [Validators.required]],
      isActive: [''],
    });
    this.loadAllClasses();
  }

  loadAllClasses() {

     this.classService.getAllClass().subscribe(data=>
      this.getClasses=data
      );    
  }

  onFormSubmit() {
    this.dataSaved = false;
    const sclass = this.classForm.value;
    this.CreateClass(sclass);
    this.classForm.reset();
  }

  loadClassToEdit(classid: any) {
    this.classService.getClassById(classid).subscribe(sclass => {
      this.message = null;
      this.dataSaved = false;
      this.classIdUpdate = sclass.sClassID;
      this.classForm.get('className').setValue(sclass["className"]);
      this.classForm.get('className_Numeric').setValue(sclass["className_Numeric"]);
      this.classForm.get('isActive').setValue(sclass["isActive"]);

    });
  }



  CreateClass(sclass: SClass) {
    if (this.classIdUpdate == null) {
      this.classService.createClass(sclass).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllClasses();
          this.classIdUpdate = null;
          this.classForm.reset();
        }
      );
    }
    else {
      sclass.SClassID = this.classIdUpdate;
      this.classService.updateClass(sclass).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllClasses();
        this.classIdUpdate = null;
        this.classForm.reset();
      });
    }
  }

  deleteClass(sClassID:any) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.classService.deleteClassById(sClassID).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllClasses();
        this.classIdUpdate = null;
        this.classForm.reset();
      });
    }
  }

  resetForm() {
    this.classForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
