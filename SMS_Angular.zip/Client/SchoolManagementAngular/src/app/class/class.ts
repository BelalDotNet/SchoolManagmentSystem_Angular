export class SClass {
    SClassID: any;
    ClassName: string;
    ClassName_Numeric: any;
    IsActive: boolean;
  }
  