export class Subject{
    SubjectID:number;
    SubjectName:string;
    ClassName:string;
}