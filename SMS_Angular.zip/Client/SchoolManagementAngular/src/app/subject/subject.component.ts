import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { SubjectService} from './subject.service';
import { Subject} from './subject';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.css']
  
})
export class SubjectComponent implements OnInit {
  dataSaved = false;
  subjectForm: any;
  allSubjects: Observable<Subject[]>;
  subjectIdUpdate = null;
  message = null;
 
  constructor(private formbulider: FormBuilder, private subjectService: SubjectService, private routes:Router) { }

  ngOnInit() {
    this.subjectForm = this.formbulider.group({
      subjectName: ['', [Validators.required]],
      className: ['', [Validators.required]]
      
    });
    this.loadAllSubjects();
  }

  loadAllSubjects() {
    this.allSubjects = this.subjectService.getAllSubjects();
  }
  onFormSubmit() {
    this.dataSaved = false;
    const subject = this.subjectForm.value;
    this.CreateSubject(subject);
    this.subjectForm.reset();
  }

  loadSubjectToEdit(subjectid: any) {
    this.subjectService .getSubjectById(subjectid).subscribe(subject => {
      this.message = null;
      this.dataSaved = false;
      this.subjectIdUpdate = subject.subjectid;
      this.subjectForm.get('subjectName').setValue(subject["subjectName"]);
      this.subjectForm.get('className').setValue(subject["className"]);
      

    });
  }

  CreateSubject(subject: Subject) {
    if (this.subjectIdUpdate == null) {
      this.subjectService.createSubject(subject).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllSubjects();
          this.subjectIdUpdate = null;
          this.subjectForm.reset();
        }
      );
    }
    else {
      subject.SubjectID = this.subjectIdUpdate;
      this.subjectService.updateSubject(subject).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllSubjects();
        this.subjectIdUpdate = null;
        this.subjectForm.reset();
      });
    }
  }

  deleteSubject(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.subjectService.deleteSubjectById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllSubjects();
        this.subjectIdUpdate = null;
        this.subjectForm.reset();
      });
    }
  }

  resetForm() {
    this.subjectForm.reset();
    this.message = null;
    this.dataSaved = false;
  } 

}
