import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Subject } from './subject';
@Injectable({
  providedIn: 'root'
})
export class SubjectService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }


  getAllSubjects(): Observable<Subject[]> {
    return this._http.get<Subject[]>(this.url + '/SubjectApi/GetSubjects');
  }

  getSubjectById(id: any): Observable<any> {
    return this._http.get<Subject>(this.url + '/SubjectApi/GetSubjectById/' + id);
  }


  createSubject(subject: Subject): Observable<Subject> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Subject>(this.url + '/SubjectApi/InsertSubject/', subject, httpOptions);
  }

  updateSubject(subject: Subject): Observable<Subject> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Subject>(this.url + '/SubjectApi/UpdateSubject', subject, httpOptions);
  }

  deleteSubjectById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/SubjectApi/DeleteSubjectById/' + id,
      httpOptions);
  }
}
