export class Notice{
    NoticeID:any;
    Title:string;
    Date:Date;
    Body:string;
    ImagePath:string;
    FileLink:string;
    IsDisplay:boolean;
    CreatedBy:string
}