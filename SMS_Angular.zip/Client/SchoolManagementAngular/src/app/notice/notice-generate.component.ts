import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { NoticeService} from './notice.service';
import { Notice} from './notice';
import { Router } from '@angular/router';
import {formatDate, DatePipe  } from '@angular/common';


@Component({
  selector: 'app-notice-generate',
  templateUrl: './notice-generate.component.html',
  styleUrls: ['./notice-generate.component.css'],
  providers:[DatePipe]
})
export class NoticeGenerateComponent implements OnInit {

  myDate = new Date();
  NoticeForm:any;
  dataSaved = false;
  message = null;
  noticeIdUpdate = null;


  constructor(private datePipe: DatePipe,private formbulider: FormBuilder, private noticeService: NoticeService, private routes:Router) { }

  ngOnInit() {
    this.NoticeForm = this.formbulider.group({
      title: ['', [Validators.required]],
      body: ['', [Validators.required]],
      date:[''],
      isDisplay:['']
      
    });

  }
  

  onFormSubmit(){
    this.dataSaved = false;
    this.NoticeForm.get('date').setValue(formatDate(new Date(), 'yyyy/MM/dd', 'en'));    
    this.NoticeForm.get('isDisplay').setValue(true);    
    const notice = this.NoticeForm.value;
    this.CreateNotice(notice);
    console.log(notice);
    this.NoticeForm.reset();
  }

  CreateNotice(notice:Notice){
   
      this.noticeService.createNotice(notice).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.noticeIdUpdate = null;
          this.NoticeForm.reset();
        }
      );
    

  }
}
