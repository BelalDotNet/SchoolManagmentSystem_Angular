import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { NoticeService} from './notice.service';
import { Notice} from './notice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.css']
})
export class NoticeComponent implements OnInit {

  noticeForm:any;
  getNotices:{};
  constructor(private formbulider: FormBuilder, private noticeService: NoticeService, private routes:Router) { }

  ngOnInit() {

    this.noticeForm = this.formbulider.group({
      title:[''],
      body:['']
    });



    this.loadNotices();
  }
  loadNotices(){
    this.noticeService.getNotices().subscribe(data=>{
      this.getNotices=data;
    });
  }



  loadNoticeToView(noticeID:any){
    this.noticeService.getNoticeById(noticeID).subscribe(data=>{
      this.noticeForm.get('title').setValue(data["title"]);
      this.noticeForm.get('body').setValue(data["body"]);
    })
  }



























}
