import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Notice } from './notice';

@Injectable({
  providedIn: 'root'
})
export class NoticeService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getNotices(){
    return this._http.get(this.url + '/NoticeApi/GetNotices');
  }


  getNoticeById(noticeID:any){
    return this._http.get(this.url + '/NoticeApi/GetNoticeById/'+noticeID);
  }


  createNotice(notice:Notice){
    return this._http.post(this.url + '/NoticeApi/InsertNotice/', notice);
  }
}
