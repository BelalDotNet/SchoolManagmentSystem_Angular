export class Section {
    SectionID: any;
    SectionName: string;
    NickName: string;
    IsActive: boolean;
  }
  