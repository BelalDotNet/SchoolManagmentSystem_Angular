import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Section } from './section';



@Injectable({
  providedIn: 'root'
})
export class SectionService {

  url = localStorage.getItem('url');

  constructor(private _http: HttpClient) { }


  getAllSection(): Observable<Section[]> {
    return this._http.get<Section[]>(this.url + '/SectionApi/GetSections');
  }

  getSectionById(id: any): Observable<any> {
    return this._http.get<Section>(this.url + '/SectionApi/GetSectionById/' + id);
  }


  createSection(section: Section): Observable<Section> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Section>(this.url + '/SectionApi/InsertSection/', section, httpOptions);
  }

  updateSection(section: Section): Observable<Section> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Section>(this.url + '/SectionApi/UpdateSection', section, httpOptions);
  }

  deleteSectionById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/SectionApi/DeleteSection/' + id,
      httpOptions);
  }
}
