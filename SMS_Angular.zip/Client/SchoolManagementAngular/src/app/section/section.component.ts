import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { SectionService} from './section.service';
import { Section} from './section';
import { Router } from '@angular/router';


@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {

  dataSaved = false;
  sectionForm: any;
  allSections: Observable<Section[]>;
  sectionIdUpdate = null;
  message = null;

  constructor(private formbulider: FormBuilder, private sectionService: SectionService, private routes:Router) { }

  ngOnInit() {

    this.sectionForm = this.formbulider.group({
      sectionName: ['', [Validators.required]],
      nickName: ['', [Validators.required]],
      isActive: [''],
    });
    this.loadAllSections();

  }

  loadAllSections() {
    this.allSections = this.sectionService.getAllSection();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const section = this.sectionForm.value;
    this.CreateSection(section);
    this.sectionForm.reset();
  }

  loadSectionToEdit(sectionid: any) {
    this.sectionService.getSectionById(sectionid).subscribe(section => {
      this.message = null;
      this.dataSaved = false;
      this.sectionIdUpdate = section.sectionID;
      this.sectionForm.get('sectionName').setValue(section["sectionName"]);
      this.sectionForm.get('nickName').setValue(section["nickName"]);
      this.sectionForm.get('isActive').setValue(section["isActive"]);

    });
  }



  CreateSection(section: Section) {
    if (this.sectionIdUpdate == null) {
      this.sectionService.createSection(section).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllSections();
          this.sectionIdUpdate = null;
          this.sectionForm.reset();
        }
      );
    }
    else {
      section.SectionID = this.sectionIdUpdate;
      this.sectionService.updateSection(section).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllSections();
        this.sectionIdUpdate = null;
        this.sectionForm.reset();
      });
    }
  }

  deleteSection(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.sectionService.deleteSectionById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllSections();
        this.sectionIdUpdate = null;
        this.sectionForm.reset();
      });
    }
  }

  resetForm() {
    this.sectionForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
