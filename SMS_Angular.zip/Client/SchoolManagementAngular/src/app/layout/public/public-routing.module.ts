import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule} from '@angular/router';
import { ListParentComponent } from 'src/app/parent/list-parent.component';

export const PUBLIC_ROUTES: Routes = [
  //{ path: 'parentList', component: ListParentComponent }
];


@NgModule({
  declarations: [],
  imports: [RouterModule],
})
export class PublicRoutingModule { }
