import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserClerkVM } from './clerk';

@Injectable({
  providedIn: 'root'
})
export class ClerkService {
  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }

  getAllClerk(): Observable<UserClerkVM[]> {
    return this._http.get<UserClerkVM[]>(this.url + '/ClerkApi/GetClerks');
  }

  getClerkById(id: any): Observable<any> {
    return this._http.get<UserClerkVM>(this.url + '/ClerkApi/GetClerkById/' + id);
  }


  createClerk(clerk: UserClerkVM): Observable<UserClerkVM> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<UserClerkVM>(this.url + '/ClerkApi/InsertClerk/', clerk, httpOptions);
  }

  updateClerk(clerk: UserClerkVM): Observable<UserClerkVM> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<UserClerkVM>(this.url + '/ClerkApi/UpdateClerk', clerk, httpOptions);
  }

  deleteClerkById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/ClerkApi/DeleteClerk/' + id,
      httpOptions);
  }
}
