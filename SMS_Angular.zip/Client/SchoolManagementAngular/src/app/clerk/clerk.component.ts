import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { ClerkService} from './clerk.service';
import { UserClerkVM} from './clerk';
import { Router } from '@angular/router';


@Component({
  selector: 'app-clerk',
  templateUrl: './clerk.component.html',
  styleUrls: ['./clerk.component.css']
})
export class ClerkComponent implements OnInit {

  dataSaved = false;
  clerkForm: any;
  allClerks: Observable<UserClerkVM[]>;
  clerkIdUpdate = null;
  message = null;

  constructor(private formbulider: FormBuilder, private clerkService: ClerkService, private routes:Router) { }

  ngOnInit() {
    this.clerkForm = this.formbulider.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
      phoneNumber:['', [Validators.required]],
      name:['', [Validators.required]],
      nid: ['', [Validators.required]],
      dob:['', [Validators.required]],
      gender:['', [Validators.required]],
      address:['', [Validators.required]],
      image:['']

    });
    this.loadAllClerks();
    console.log("ID = "+this.clerkIdUpdate);
  }


  loadAllClerks() {
    this.allClerks = this.clerkService.getAllClerk();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const clerk = this.clerkForm.value;
    this.CreateClerk(clerk);
    this.clerkForm.reset();
  }

  loadClerkToEdit(clerkid: any) {
    this.clerkService.getClerkById(clerkid).subscribe(clerk => {
      this.message = null;
      this.dataSaved = false;
      this.clerkIdUpdate = clerk.clerkID;
      this.clerkForm.get('email').setValue(clerk["email"]);
      this.clerkForm.get('password').setValue(clerk["password"]);
      this.clerkForm.get('confirmPassword').setValue(clerk["confirmPassword"]);
      this.clerkForm.get('phoneNumber').setValue(clerk["phoneNumber"]);
      this.clerkForm.get('name').setValue(clerk["name"]);
      this.clerkForm.get('nid').setValue(clerk["nid"]);
      this.clerkForm.get('dob').setValue(clerk["dob"]);
      this.clerkForm.get('gender').setValue(clerk["gender"]);
      this.clerkForm.get('address').setValue(clerk["address"]);
      this.clerkForm.get('image').setValue(clerk["image"]);
      console.log("ID = "+this.clerkIdUpdate);


    });
  }



  CreateClerk(clerk: UserClerkVM) {
    if (this.clerkIdUpdate == null) {
      this.clerkService.createClerk(clerk).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllClerks();
          this.clerkIdUpdate = null;
          this.clerkForm.reset();
        }
      );
    }
    else {
      clerk.ClerkID = this.clerkIdUpdate;
      this.clerkService.updateClerk(clerk).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllClerks();
        this.clerkIdUpdate = null;
        this.clerkForm.reset();
      });
    }
  }

  deleteClerk(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.clerkService.deleteClerkById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllClerks();
        this.clerkIdUpdate = null;
        this.clerkForm.reset();
      });
    }
  }

  resetForm() {
    this.clerkForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  

}
