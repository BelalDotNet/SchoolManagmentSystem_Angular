export class UserClerkVM {
    ClerkID:any;
    Email: string;
    Password: string;
    ConfirmPassword: string;
    PhoneNumber:string;
    Name:string;
    NID: string;
    DOB:Date;
    Gender:string;
    Address:string;
    Image:string;
  }
  