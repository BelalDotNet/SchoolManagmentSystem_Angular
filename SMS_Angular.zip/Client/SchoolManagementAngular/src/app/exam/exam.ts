export class Exam {
    ExamID: any;
    ExamName: string;
    Comment: string;
  }