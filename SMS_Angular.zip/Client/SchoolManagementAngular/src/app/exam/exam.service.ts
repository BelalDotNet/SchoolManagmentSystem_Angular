import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Exam } from './exam';

@Injectable({
  providedIn: 'root'
})
export class ExamService {

  url = localStorage.getItem('url');
  constructor(private _http: HttpClient) { }



  getAllExam(): Observable<Exam[]> {
    return this._http.get<Exam[]>(this.url + '/ExamApi/GetExams');
  }

  getExamById(id: any): Observable<any> {
    return this._http.get<Exam>(this.url + '/ExamApi/GetExamById/' + id);
  }



  createExam(exam: Exam): Observable<Exam> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.post<Exam>(this.url + '/ExamApi/InsertExam/', exam, httpOptions);
  }



  updateExam(exam: Exam): Observable<Exam> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.put<Exam>(this.url + '/ExamApi/UpdateExam', exam, httpOptions);
  }


  deleteExamById(id: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this._http.delete<number>(this.url + '/ExamApi/DeleteExamById/' + id,
      httpOptions);
  }

}
