import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable} from 'rxjs';
import { ExamService} from './exam.service';
import { Exam} from './exam';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent implements OnInit {


  dataSaved = false;
  examForm: any;
  allExams: Observable<Exam[]>;
  examIdUpdate = null;
  message = null;
  getExams:{};

  constructor(private formbulider: FormBuilder, private examService: ExamService, private routes:Router) { }

  ngOnInit() {
    this.examForm = this.formbulider.group({
      examName: ['', [Validators.required]],
      comment: ['', [Validators.required]],
    });
    this.loadAllExams();
  }

  loadAllExams() {
    this.examService.getAllExam().subscribe(data=>
      this.getExams=data
      );
  }

  onFormSubmit() {
    this.dataSaved = false;
    const exam = this.examForm.value;
    this.CreateExam(exam);
    this.examForm.reset();
  }

  loadExamToEdit(examID: any) {
    this.examService.getExamById(examID).subscribe(exam => {
      this.message = null;
      this.dataSaved = false;
      this.examIdUpdate = exam.examID;
      this.examForm.get('examName').setValue(exam["examName"]);
      this.examForm.get('comment').setValue(exam["comment"]);
    });
  }


  CreateExam(exam: Exam) {
    if (this.examIdUpdate == null) {
      this.examService.createExam(exam).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Record saved Successfully';
          this.loadAllExams();
          this.examIdUpdate = null;
          this.examForm.reset();
        }
      );
    }
    else {
      exam.ExamID = this.examIdUpdate;
      this.examService.updateExam(exam).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Updated Successfully';
        this.loadAllExams();
        this.examIdUpdate = null;
        this.examForm.reset();
      });
    }
  }


  deleteExam(id: string) {
    if (confirm("Are you sure you want to delete this ?")) {
      this.examService.deleteExamById(id).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Record Deleted Succefully';
        this.loadAllExams();
        this.examIdUpdate = null;
        this.examForm.reset();
      });
    }
  }



  resetForm() {
    this.examForm.reset();
    this.message = null;
    this.dataSaved = false;
  }  







}
