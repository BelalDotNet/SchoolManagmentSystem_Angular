import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListParentComponent } from './parent/list-parent.component';
import { DashboardComponent } from './admin/dashboard.component';
import { HomeComponent } from './home/home.component';
import { SecureComponent } from './layout/secure/secure.component';
import { PublicComponent } from './layout/public/public.component';
import { RootComponent} from './root/root.component';
import { StudentComponent } from './student/student.component';
import { ClerkComponent } from './clerk/clerk.component';
import { ClassComponent } from './class/class.component';
import { SectionComponent } from './section/section.component';
import { TeacherComponent } from './teacher/teacher.component';
import { MarkComponent } from './mark/mark.component';
import { AstcComponent} from './assignSectionsToClasses/astc.component';
import { AssignStudentComponent} from './assignStudentsToClasses/assign-student.component';
import { ExamComponent } from './exam/exam.component'
import { AssignTeacherComponent } from './assignTeacherToClasses/assign-teacher.component'
import { SubjectComponent } from './subject/subject.component'
import { GradeComponent } from './grade/grade.component';
import { NoticeComponent } from './notice/notice.component';
import { NoticeGenerateComponent } from './notice/notice-generate.component';

const routes: Routes = [
  {
    path: 'home',
    component: PublicComponent,
    data: { title: 'Public Views' },
    children: [
      {path:'', component: HomeComponent}
    ]
  },



  {
    path: 'notice',
    component: PublicComponent,
    data: { title: 'Public Views' },
    children: [
      {path:'', component: NoticeComponent}
    ]
  },

  {
    path: 'noticeList',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: NoticeComponent}
    ]
  },


   {
    path: 'noticeGenerate',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: NoticeGenerateComponent}
    ]
  },

  {
    path: 'dashboard',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: DashboardComponent}
    ]
  },
  {
    path: 'parent',
    component: SecureComponent,
    children: [
      { path: '', component: ListParentComponent }
    ]
  },
  {
    path: 'grade',
    component: SecureComponent,
    children: [
      { path: '', component: GradeComponent }
    ]
  },


  {
    path: 'subject',
    component: SecureComponent,
    children: [
      { path: '', component: SubjectComponent }
    ]
  },
  
  
  {
    path: 'assignTeacher',
    component: SecureComponent,
    children: [
      { path: '', component: AssignTeacherComponent }
    ]
  },

  {
    path: 'student',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: StudentComponent}
    ]
  },


  {
    path: 'exam',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: ExamComponent}
    ]
  },

  {
    path: 'assignStudent',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: AssignStudentComponent}
    ]
  },


  {
    path: 'staff',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: ClerkComponent}
    ]
  },

  {
    path: 'class',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: ClassComponent}
    ]
  },

  {
    path: 'section',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: SectionComponent}
    ]
  },


  {
    path: 'astc',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: AstcComponent}
    ]
  },

  {
    path: 'teacher',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: TeacherComponent}
    ]
  },

  {
    path: 'mark',
    component: SecureComponent,
    data: { title: 'Secure Views' },
    children: [
      {path:'', component: MarkComponent}
    ]
  },


  { path: 'root', component: RootComponent },
  { path: '', redirectTo: '/root', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
