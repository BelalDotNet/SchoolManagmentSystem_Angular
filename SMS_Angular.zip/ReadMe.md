Hello Everyone!
This is me Md. Ballal Hossain,and two other Project members are
Md.Mehedi Hasan and Monjurul Alam.
Mail : mdbillal73@gmail.com
Cell : 01815716388

Trainee of IsDB-BISEW IT Scholarship Project.
IDB Bhaban (4th Floor), 
E/8-A, Rokeya Sharani, 
Sher-e-Bangla Nagar, Dhaka-1207

Round No-38,
Course Name: ESAD-CS(C#.NET)
TSP : NVIT, Chattogram, Bangladesh.
Trainee ID 1245968
Trainee ID 1245091
Trainee ID 1245178
=====================================================

Project Name : School Management System
=====================================================

Technology Used : MS-SQL Server 2016,
		: ASP.Net MVC5 With CodeFirst Approach,
		: ASP.Net Core,
		: Web API 2.2,Repository Pattern,Dependency Injection,	
		: Angular6,AngularJS,Typscript,HTML5,CSS3,Bootstrap4
		: Fontawesome and Many more.
======================================================
Project Description :

School Management System is designed for educational institutes like primary school,
secondary and higher secondary school  or other public institutes 
and also private institutes to manage academic activities more accurate and  faster than manual system.


School Management System is a such service that reduces most of the drawbacks of the traditional methods.
The system is web based so Student admission, Employee Registration,Attendance,
 payroll, result publishing are totally automatic. Thus, it minimizes the time and human effort by accurate performance. 
A person can check student information, notices, result etc.

This Web based application will facilitate a school by performing following tasks-
Administrative panel, Admit Student, Employ Teacher, Parent Information, Class management, Exam and Result management
Administrative Panel will operate the system.There are various types of user of this system. Each of the user will access the system according to their provided (by admin) rules.
Teacher can submit marks in his/her subject and generate student result.

Although we tried by heart and soul in our limited time most of the task we completed succesfully
and some feature couldn't add yet like attendance, dynamic class routine and Mark generation.These are under proccessing. 
Follow me on facebook "fb.com/BelalDotNet"

==================================================================
Project Run Proccess: 
1. We Used Back-End Two Web API (MVC Web API & Core Web API) And One Front-End Angular Application. 
2. Two Web Api can consume together by choosing one in Angular Site.
3. First of all you have to run two api successfully if u want to run two web api otherwise you can run one by one.
4. After successfully running you have to open angular client application folder and run command prompt or windows powershell 
on this specific folder.
05. Install node_modules folder by pressing "npm install"
06. After installing type on cmd " ng serve --open" and enjoy the School management application.


=================================================================
System Users : 06
	     01 : Admin
	     02 : Teacher
             03 : Clerk
	     04 : Parent
	     05 : Student 
             06 : anonymous user

===================================================================
Project Member : 
		: md. Ballal Hossain
		: md. Mehedi Hasan
		: Md. Monjurul Alam

===================================================================
Project Duration : 45 Days


	
